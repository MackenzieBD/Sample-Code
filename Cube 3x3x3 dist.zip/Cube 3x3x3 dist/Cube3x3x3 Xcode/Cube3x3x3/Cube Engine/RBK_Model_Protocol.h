//
//  RBK_Model_Protocol.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//
//  Subclasses must overide these methods

#ifndef RBK_Model_Protocol_h
#define RBK_Model_Protocol_h

#endif /* RBK_Model_Protocol_h */

@protocol RBK_Model_Protocol <NSObject>

-(NSData *)productOfAction: (NSData *)action andState: (NSData *)state;

-(NSData *)inverseOfState: (NSData *)state;

-(NSData *)stateForConfiguration: (NSString *)config;

-(NSString *)configurationForState: (NSData *)state;

@end

 
