//
//  CubieModel.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import "CubieModel.h"
#import <simd/simd.h>


@implementation CubieModel
{
    NSArray     *faceTurns;
    RBK_Turn    inverseTurn[RBK_TURN_MAX];
    RBK_Turn    conjugateOfTurnBySymtag[RBK_TURN_MAX][48];
    RBK_Cubicle positionOfCubieInState[20][48];
    int         orientationOfCubieInState[20][24];
}

-(instancetype)init
{
    self = [super init];
    
    if(self != nil)
    {
        [self initPositionTable];
        [self initOrientTable];
        [self initFaceTurns];
        [self initTurnConjugates];
    }
    
    return self;
}

-(void)dealloc
{
    [faceTurns release];
    [super dealloc];
}

#pragma mark    **Initiation Methods**

-(void)initFaceTurns
{
    NSMutableArray      *fTurns;
    RBK_Turn            turn;
    
    fTurns = [NSMutableArray array];
    
    // The base class defines the turns with configuration strings
    // and calls stateForConfiguration: This method is overriden in this
    // class to convert the configuration string to a CubieModel state.
    
    for(turn = 0 ; turn < RBK_TURN_MAX ; turn++ )
        [fTurns addObject: [super stateForTurn: turn]];
    
    faceTurns = [[NSArray alloc] initWithArray: fTurns];
    
    for(turn = 0 ; turn < RBK_TURN_MAX ; turn++ )
        inverseTurn[turn] = (RBK_Turn)[faceTurns indexOfObject: [self inverseOfState: [faceTurns objectAtIndex: turn]]];    
}

// Compute the orientation of a cubie after applying a rotation transform.
// This uses the Singmaster definition of flip for edge cubies rather than
// the more straightforward but less human readable definition based on
// the A2g parity.  This because the standard configuration string
// representation is defined with this in mind.

-(void)initOrientTable
{
    OSG_VECTOR_t     refAxis[12][3] =
    {
        { 0 , 1 , 0 },    // UF
        { 0 , 1 , 0 },    // UR
        { 0 , 1 , 0 },    // UB
        { 0 , 1 , 0 },    // UL
        { 0 ,-1 , 0 },    // DF
        { 0 ,-1 , 0 },    // DR
        { 0 ,-1 , 0 },    // DB
        { 0 ,-1 , 0 },    // DL
        { 0 , 0 , 1 },    // FR
        { 0 , 0 , 1 },    // FL
        { 0 , 0 ,-1 },    // BR
        { 0 , 0 ,-1 },    // BL
    };
    
    NSMutableArray      *refVector;
    OSG_SYMTAG          sym;
    NSData              *product;
    RBK_Cubie           cubie,
                        position;
    
    refVector = [NSMutableArray array];
    for(cubie = 0 ; cubie < 12 ; cubie++ )
        [refVector addObject: [NSData dataWithBytes: refAxis[cubie] length: sizeof(OSG_VECTOR_t [3])]];
    
    // *******EDGE CUBIES******
    
    // Does the cubie's reference axis line up with the cubical's reference axis?
    for( cubie = 0 ; cubie < 12 ; cubie++ )
        for( sym = 0 ; sym < 24 ; sym++ )
        {
            position = [self positionOfCubie: cubie inState: sym];
            product = [OhGroup productOfTag: sym
                                           vector: refVector[cubie]];
            
            if( [product isEqual: refVector[position]] )
                orientationOfCubieInState[cubie][sym] = RBK_ORIENT_NONE;
            else
                orientationOfCubieInState[cubie][sym] = RBK_ORIENT_FLIP;
        }
    
    //  *****CORNER CUBIES******
        
    NSString            *symmetry;
    NSArray             *groupD4;
    NSMutableArray      *cosetCW,
                        *cosetCCW;
    
    // The D4y symmetry elements map the y axis onto itself or the -y axis and afford 0 twist
    // The D4y  cosets afford a CW or CCW twist
    
    cosetCW = [NSMutableArray array];
    cosetCCW = [NSMutableArray array];
    
    groupD4 = [OhGroup subgroupNamed: @"D4y"];
    
    // generate the right cosets of D4y
    for(symmetry in groupD4)
    {
        // apply C3xyz: CW rotation
        sym = [OhGroup productOfActionTag: [symmetry intValue]
                                       stateTag: [OhGroup symtagForKey: @" y, z, x"] ];
        
        [cosetCW addObject: [NSString stringWithFormat: @"%d", sym] ];
        
        // apply CCW rotation
        sym = [OhGroup productOfActionTag: [symmetry intValue]
                                       stateTag: [OhGroup symtagForKey: @" z, x, y"] ];
        
        [cosetCCW addObject: [NSString stringWithFormat: @"%d", sym] ];
    }
    
    for(cubie = 12 ; cubie < 20 ; cubie++ )
    {
        for( symmetry in groupD4 )
        {
            sym = [symmetry intValue];
            orientationOfCubieInState[cubie][sym] = RBK_ORIENT_NONE;
        }
        
        for( symmetry in cosetCW )
        {
            sym = [symmetry intValue];
            switch(cubie)
            {
                // Positive axes
                case UFR:
                case UBL:
                case DBR:
                case DFL:
                    orientationOfCubieInState[cubie][sym] = RBK_ORIENT_CW;
                    break;
                    
                default:  //neg axes: twist is opposite
                    orientationOfCubieInState[cubie][sym] = RBK_ORIENT_CCW;
                    break;
            }
        }
        
        for( symmetry in cosetCCW )
        {
            sym = [symmetry intValue];
            switch(cubie)
            {
                // Positive axes
                case UFR:
                case UBL:
                case DBR:
                case DFL:
                    orientationOfCubieInState[cubie][sym] = RBK_ORIENT_CCW;
                    break;
                    
                default:  //neg axes: twist is opposite
                    orientationOfCubieInState[cubie][sym] = RBK_ORIENT_CW;
                    break;
            }
        }
    }
}

// Compute the action of the Oh symmetries on cubie positions

-(void)initPositionTable
{
    //Home positions of the cubies
    OSG_VECTOR_t     points[20][3] =
    {
        { 0 , 1 , 1 },    // UF
        { 1 , 1 , 0 },    // UR
        { 0 , 1 ,-1 },    // UB
        {-1 , 1 , 0 },    // UL
        { 0 ,-1 , 1 },    // DF
        { 1 ,-1 , 0 },    // DR
        { 0 ,-1 ,-1 },    // DB
        {-1 ,-1 , 0 },    // DL
        { 1 , 0 , 1 },    // FR
        {-1 , 0 , 1 },    // FL
        { 1 , 0 ,-1 },    // BR
        {-1 , 0 ,-1 },    // BL
        
        { 1 , 1 , 1 },    // UFR
        { 1 , 1 ,-1 },    // URB
        {-1 , 1 ,-1 },    // UBL
        {-1 , 1 , 1 },    // ULF
        { 1 ,-1 , 1 },    // DRF
        {-1 ,-1 , 1 },    // DFL
        {-1 ,-1 ,-1 },    // DLB
        { 1 ,-1 ,-1 },    // DBR
    };
    
    RBK_Cubie       cubie;
    NSUInteger      index;
    OSG_SYMTAG      symtag;
    NSData          *newPosition;
    NSMutableArray  *positions;
    
    positions = [NSMutableArray array];
    
    for(cubie = 0 ; cubie < 20 ; cubie++ )
        [positions addObject: [NSData dataWithBytes: points[cubie] length: sizeof(OSG_VECTOR_t [3])]];
    
    for(cubie = 0; cubie < 20 ; cubie++ )
        for(symtag = 0 ; symtag < 48 ; symtag++)
        {
            newPosition = [[self OhGroup] productOfTag: symtag
                                                      vector: [positions objectAtIndex: cubie ]];
            index = [positions indexOfObject: newPosition];
            
            positionOfCubieInState[cubie][symtag] = (RBK_Cubie)index;
        }
}

- (void)initTurnConjugates
{
    NSData      *state, *conjugate;
    RBK_Turn    turn, conj;
    OSG_SYMTAG  symtag;
    
    for( turn = 0 ; turn < RBK_TURN_MAX ; turn++ )
    {
        state = [self stateForTurn: turn];
        for( symtag = 0 ; symtag < 48 ; symtag++ )
        {
            conjugate = [self conjugateOfState: state bySymtag: symtag];
            conj = (RBK_Turn)[faceTurns indexOfObject: conjugate ];
            
            conjugateOfTurnBySymtag[turn][symtag] = conj;
        }
        
    
    }
}

#pragma mark        **End Initiations**


// Configuration Codes
//              flipped
//    @"UF",    @"FU",
//    @"UR",    @"RU",
//    @"UB",    @"BU",
//    @"UL",    @"LU",
//    @"DF",    @"FD",
//    @"DR",    @"RD",
//    @"DB",    @"BD",
//    @"DL",    @"LD",
//    @"FR",    @"RF",
//    @"FL",    @"LF",
//    @"BR",    @"RB",
//    @"BL",    @"LB",
//               CW          CCW
//    @"UFR",    @"FRU",    @"RUF",
//    @"URB",    @"RBU",    @"BUR",
//    @"UBL",    @"BLU",    @"LUB",
//    @"ULF",    @"LFU",    @"FUL",
//    @"DRF",    @"RFD",    @"FDR",
//    @"DFL",    @"FLD",    @"LDF",
//    @"DLB",    @"LBD",    @"BDL",
//    @"DBR",    @"BRD",    @"RDB",

- (NSString *)configurationForState:(NSData *)state
{
    NSString            *tokens[20],
                        *result;
    NSArray             *codes;
    RBK_Cubie           cubie, cubicle;
    const OSG_SYMTAG    *cubeRep;
    int                 orient,index;
    
    codes = [self configurationCodes];
    cubeRep = [state bytes];
    
    for( cubie = 0 ; cubie < 20 ; cubie++ )
    {
        cubicle = [self positionOfCubie: cubie inState: cubeRep[cubie] ];
        orient = [self orientationOfCubie: cubie inState: cubeRep[cubie] ];
        
        if(cubie < 12)
           index = 2 * cubie;
        else
            index = 24 + (cubie - 12) * 3;
        
        index += orient;
        
        tokens[cubicle] = [codes objectAtIndex: index];
    }
    result = [[NSArray arrayWithObjects: tokens count: 20] componentsJoinedByString: @" "];
    return result;
}


-(NSData *)conjugateOfPath: (NSData *)path
                  bySymtag: (OSG_SYMTAG)symtag
{
    NSMutableData       *newPath;
    NSUInteger          n,max;
    const RBK_Turn      *input;
    RBK_Turn            *output;
    
    max = [path length] / sizeof(RBK_Turn);
    newPath = [NSMutableData dataWithLength: sizeof(RBK_Turn [max])];
    
    input = [path bytes];
    output = [newPath mutableBytes];
    
    for( n = 0 ; n < max ; n++ )
        output[n] = [self conjugateOfTurn: input[n] bySymtag: symtag];
    
    return newPath;
}

// Accessor Method

-(RBK_Turn)conjugateOfTurn: (RBK_Turn)turn
                  bySymtag: (OSG_SYMTAG)symtag
{
    return conjugateOfTurnBySymtag[turn][symtag];
}

// Form the conjugate: m'g m

-(NSData *)conjugateOfState: (NSData *)state
                   bySymtag: (OSG_SYMTAG)symtag
{
    OSG_SYMTAG      inv,
                    sym[RBK_CUBIE_MAX],
                    iSym[RBK_CUBIE_MAX];
    NSData          *product;
    NSUInteger      n;
    
    inv = [OhGroup inverseOfTag: symtag];
    for( n = 0 ; n < RBK_CUBIE_MAX ; n++ )
    {
        sym[n] = symtag;
        iSym[n] = inv;
    }
     
    product = [self productOfAction: state
                           andState: [NSData dataWithBytes: sym length: sizeof(OSG_SYMTAG [RBK_CUBIE_MAX])]];
    
    product = [self productOfAction: [NSData dataWithBytes: iSym length: sizeof(OSG_SYMTAG [RBK_CUBIE_MAX])]
                           andState: product];
    
    return product;
}

-(NSData *)inverseOfPath:(NSData *)path
{
    NSInteger       s,d,max;
    const RBK_Turn  *source;
    RBK_Turn        *dest;
    NSMutableData   *result;
    
    max = [path length]/ sizeof(RBK_Turn);
    result = [NSMutableData dataWithLength: sizeof(RBK_Turn [max]) ];
    source = [path bytes];
    dest = [result mutableBytes];
    
    for(s = 0, d = max -1 ; s < max ; s++, d-- )
        dest[d] = [self inverseOfTurn: source[s] ];
    
    return result;
}

- (NSData *)inverseOfState:(NSData *)state
{
    OSG_SYMTAG      inverse[RBK_CUBIE_MAX];
    
    [self getInverse: inverse ofState:  [state bytes] ];
    
    return [NSData dataWithBytes: inverse length: sizeof(OSG_SYMTAG [RBK_CUBIE_MAX])];
}

-(void)getInverse: (OSG_SYMTAG *)inverseRep
          ofState: (const OSG_SYMTAG *)stateRep
{
    RBK_Cubie       cubie, cubicle;
    
    for( cubie = 0 ; cubie < RBK_CUBIE_MAX ; cubie++ )
    {
        cubicle = [self positionOfCubie:cubie inState: stateRep[cubie] ];
        inverseRep[cubicle] = [OhGroup inverseOfTag: stateRep[cubie] ];
    }
}

-(RBK_Turn)inverseOfTurn:(RBK_Turn)turn
{
    return inverseTurn[turn];
}

// Accessor Method
// Use this method rather than accessing the array
// directly for maintainability

-(int)orientationOfCubie: (RBK_Cubie)cubie
                 inState: (OSG_SYMTAG)state
{
    return orientationOfCubieInState[cubie][state];
}

// Hook.  Subclasses with solvers may override to suppy
// the generatator sequence

-(NSData *)pathForState:(NSData *)state
{
    return nil;
}

// Return the proxy (representative element) of the
// argument's symmetry equivalence class.  The
// size of the equivalence class and the conjugator
// to take the argument to the proxy

-(SymProxy)proxyOfState: (NSData *)stateData
              symmetries: (NSString *)symGroup
                 antiSym: (BOOL)useAntiSym
{
    SymProxy                result;
    NSData                  *inverseState;
    NSArray                 *subGroup;
    NSString                *item;
    const OSG_SYMTAG        *state,
                            *inverse;
    unsigned                n,
                            conj,
                            best,
                            slot,
                            pos,
                            symTag,
                            invTag,
                            symTags[2][96],
                            count1,
                            count2,
                            op,
                            pdt,
                            maxSize;
    
    if( (symGroup == nil) || [symGroup isEqualToString: @"Oh"] ) //default to Oh
    {
        for( n = 0 ; n < 96 ; n++ )
            symTags[0][n] = n;
        
        if( !useAntiSym )
            n = 48;
    }
    else
    {
        subGroup = [OhGroup subgroupNamed: symGroup];
        if( subGroup == nil )
        {
            NSLog( @"CubieModel: invalid subgroup name: %@", symGroup );
            subGroup = [OhGroup subgroupNamed: @"Oh"];
        }
        n = 0;
        for( item in subGroup )
        {
            symTag = [item intValue];
            symTags[0][n++] = symTag;
            if(useAntiSym)
                symTags[0][n++] = symTag + 48;
        }
    }
    count1 = maxSize = n;
    
    state = [stateData bytes];
    inverseState = [self inverseOfState: stateData ];
    inverse = [inverseState bytes];
    
    slot = 0;
    op = 0;
    pdt = 1;
    
    // Find the cubic group conjugator giving the lowest ranked conjugate via bytewise comparison
    // We start with all conjugations and winnow the list down eliminating the conjugators which
    // give greater than the minimum at each successive cubie position.  Typically for random states
    // the result is found after looking at only the first two or three cubies.
    do
    {
        count2 = 0;
        best = UINT_MAX;
        
        for( n = 0 ; n < count1 ; n++ )
        {
            symTag = symTags[op][n];
            if( symTag < 48 )
            {
                invTag = [OhGroup inverseOfTag: symTag];
                pos = [self positionOfCubie: slot inState: symTag];
                conj = [OhGroup productOfActionTag: state[ pos ] stateTag: symTag];
                conj = [OhGroup productOfActionTag: invTag stateTag: conj ];
            }
            else
            {
                conj = symTag - 48;
                invTag = [OhGroup inverseOfTag: conj];
                pos = [self positionOfCubie: slot inState: conj ];
                conj = [OhGroup productOfActionTag: inverse[ pos ] stateTag: conj];
                conj = [OhGroup productOfActionTag: invTag stateTag: conj];
                
            }
            
            if( conj < best )
            {
                count2 = 1;
                best = conj;
                symTags[pdt][0] = symTag;
            }
            else
                if( conj == best )
                    symTags[pdt][count2++] = symTag;
        }
        slot++;
        pdt ^= 1;
        op ^= 1;
        count1 = count2;
        
    }while( (slot < RBK_CUBIE_MAX) && (count2 > 1) ); //Stop when all slots are processed or when only one conjugator remains
    
    result.conjugator = symTags[op][0];
    
    if( symTags[op][0] < 48 )
        result.proxy =  [self conjugateOfState: stateData bySymtag: symTags[op][0] ];
    else
        result.proxy = [self conjugateOfState: inverseState bySymtag: symTags[op][0] - 48 ];
    
    result.size =  maxSize / count2;
    
    return result;
}

// Accessor Method
// Use this method rather than accessing the array
// directly for maintainability

-(RBK_Cubie)positionOfCubie: (RBK_Cubie)cubie
                    inState: (OSG_SYMTAG)state
{
    return positionOfCubieInState[cubie][state];
}

-(NSData *)productOfPath: (NSData *)path
                andState: (NSData  * _Nullable)state
{
    const RBK_Turn      *turns;
    NSInteger           n, max;
    
    if(state == nil )
        state = [self identityState];
    
    max = [path length] / sizeof( RBK_Turn );
    turns = [path bytes];
    
    for( n = 0 ; n < max ; n++ )
        state = [self productOfAction: [self stateForTurn: turns[n]]
                             andState: state];
    
    return state;
}

- (NSData *)productOfAction:(NSData *)action
                   andState:(NSData *)state
{
    const OSG_SYMTAG    *actionRep,
                        *stateRep;
     OSG_SYMTAG         product[RBK_CUBIE_MAX];
   
    actionRep = [action bytes];
    stateRep = [state bytes];
    
    [self getProductRep: product
            ofActionRep: actionRep
            andStateRep: stateRep];
    
    return [NSData dataWithBytes: product length: sizeof(OSG_SYMTAG [RBK_CUBIE_MAX])];
}

-(NSData *)productOfTurn: (RBK_Turn)turn
                andState: (NSData *)state
{
    return [self productOfAction: [self stateForTurn: turn]
                        andState: state];
}

// The CubieModel representation lists the Oh group transforms which will
// rotate the cubies from their home positions to their present positions
// and orientations.  As an action the representation lists the transforms
// to be applied to which ever cubie is in that position in the state.

-(void)getProductRep: (OSG_SYMTAG *)product
         ofActionRep: (const OSG_SYMTAG *)action
         andStateRep: (const OSG_SYMTAG *)state
{
    RBK_Cubie   cubie, cubicle;
    
    for(cubie = 0; cubie < RBK_CUBIE_MAX; cubie++)
    {
        cubicle = [self positionOfCubie: cubie inState: state[cubie] ];
        product[cubie] = [OhGroup productOfActionTag: action[cubicle]
                                            stateTag: state[cubie] ];
    }
}

-(NSData *)randomState
{
    return [self stateForConfiguration: [self randomConfiguration] ];
}


// Configuration Codes
//              flipped
//    @"UF",    @"FU",
//    @"UR",    @"RU",
//    @"UB",    @"BU",
//    @"UL",    @"LU",
//    @"DF",    @"FD",
//    @"DR",    @"RD",
//    @"DB",    @"BD",
//    @"DL",    @"LD",
//    @"FR",    @"RF",
//    @"FL",    @"LF",
//    @"BR",    @"RB",
//    @"BL",    @"LB",
//               CW          CCW
//    @"UFR",    @"FRU",    @"RUF",
//    @"URB",    @"RBU",    @"BUR",
//    @"UBL",    @"BLU",    @"LUB",
//    @"ULF",    @"LFU",    @"FUL",
//    @"DRF",    @"RFD",    @"FDR",
//    @"DFL",    @"FLD",    @"LDF",
//    @"DLB",    @"LBD",    @"BDL",
//    @"DBR",    @"BRD",    @"RDB",

- (NSData *)stateForConfiguration:(NSString *)config
{
    OSG_SYMTAG      state[RBK_CUBIE_MAX];
    RBK_Cubie       cubie, cubicle;
    int             orientation;
    NSArray         *codes, *tokens;
    
    if( [self isValidConfiguration: config] == NO)
    {
        [self report: [NSString stringWithFormat: @"\n ** BAD CONFIGURATION**\n%@\n", config ]];
        return nil;
    }
    
    codes = [self configurationCodes];
    tokens = [config componentsSeparatedByString: @" "];
    
    for(cubicle = 0 ; cubicle < 20 ; cubicle++ )
    {
        cubie = (RBK_Cubie)[codes indexOfObject: tokens[cubicle] ];
        if( cubie < 24 )
        {
            orientation = cubie % 2;
            cubie /= 2;
        }
        else
        {
            cubie -= 24;
            orientation = cubie % 3;
            cubie = 12 + (cubie / 3);
        }
        
        state[cubie] = [self symtagToPutCubie: cubie
                                    inCubicle: cubicle
                              withOrientation: orientation];
        
    }
    return [NSData dataWithBytes: state length: sizeof(OSG_SYMTAG [RBK_CUBIE_MAX] )];
}

-(NSData *)stateForPath: (NSData *)path
{
    return [self productOfPath: path andState: nil];
}

-(NSData *)stateForTurnString: (NSString *)turnString
{
    NSData  *path;
    
    path = [self pathForTurnString: turnString];
    
    return [self stateForPath: path ];
}

// Returns the group of Oh group elements for which conjugation
// with cubeState is invariant: m' * state * m = state.
// The result is an NSArray containing a list of
// OhSymmetryGroup keys.  ie @" x, y, z"

-(NSArray *)symmetryGroupOfState: (NSData *)state
{
    NSData              *conj;
    NSMutableArray      *result;
    OSG_SYMTAG          sym;
    
    result = [NSMutableArray array];
    for(sym = 0 ; sym < 48 ; sym++ )
    {
        conj = [self conjugateOfState: state bySymtag: sym];
        if( [conj isEqualToData: state] )
            [result addObject: [OhGroup keyForSymtag: sym] ];
    }
    return result;
}

-(OSG_SYMTAG)symtagToPutCubie: (RBK_Cubie)cubie
                    inCubicle: (RBK_Cubie)cubicle
              withOrientation: (int)orientation
{
    OSG_SYMTAG  sym;
    RBK_Cubie   position;
    int         orient;
    
    sym = -1;
    do
    {
        sym++;
        while( (position = [self positionOfCubie: cubie inState: sym] ) != cubicle )
            sym++;
        
        orient = [self orientationOfCubie: cubie inState: sym];
    }while( (orient != orientation) && (sym < 48 ) );
    
    return sym;
}

// accessor method

-(NSData *)stateForTurn:(RBK_Turn)turn
{
    return [faceTurns objectAtIndex: turn];
}

#pragma mark    **CubeEngineProtocol Methods**

- (void)execute:(NSDictionary *)parameters
{
    NSString        *prompt,
                    *input;
    
    input = [parameters objectForKey: CEP_PARAMETER];
    prompt = [parameters objectForKey: CEP_FUNCTION];
    
    if( [self Abort] == YES )
        [self setAbort: NO];
        
    
    if( [prompt isEqualToString: @"List Oh Symmetries"] )
    {
        [self report: @"\n"];
        [self report: prompt];
        [self dumpSymmetries];
        [self reportDone];
    }
    
    if( [prompt isEqualToString: @"Text to Configuration"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [self textToConfiguration: input];
        [self reportDone];
    }
    
    if( [prompt isEqualToString: @"States at Depth"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [NSThread detachNewThreadSelector: @selector(statesAtDepth:)
                                 toTarget: self
                               withObject: input];
    }
    
    if( [prompt isEqualToString: @"GAP Rubik Group Defs"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [self gapRubikDefs: input];
        [self reportDone];
    }
    
    if( [prompt isEqualToString: @"GAP for Symmetries"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [self gapForSymKeys: input];
        [self reportDone];
    }
    
    if( [prompt isEqualToString: @"GAP for Turn Sequences"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [self gapForTurns: input];
        [self reportDone];
    }
    
    if( [prompt isEqualToString: @"GAP for States"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [self gapForText: input];
        [self reportDone];
    }
    
    if( [prompt isEqualToString: @"PLL Analysis"])
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [NSThread detachNewThreadSelector: @selector(pllAnalysis:)
                                 toTarget: self
                               withObject: input];
    }
    
    if( [prompt isEqualToString: @"_DEVELOP"])
    {
        [self report: @"\n\n"];
        [self report: prompt];
        [NSThread detachNewThreadSelector: @selector(developer:)
                                 toTarget: self
                               withObject: input];
    }
}

- (NSArray *)functionArray
{
    return [NSArray arrayWithObjects:
            @"Text to Configuration",
            @"States at Depth",
            @"GAP for States",
            @"GAP for Turn Sequences",
            @"GAP for Symmetries",
            @"GAP Rubik Group Defs",
            @"List Oh Symmetries",
            @"PLL Analysis",
            @"_DEVELOP",
            nil];;
}

- (void)stop
{
    [self setAbort: YES];
}

#pragma mark    **Interface Methods**

-(void)dumpSymmetries
{
    NSArray     *dump;
    id          item;
    
    dump = [[self OhGroup] dump];
    
    for(item in dump)
        [self report: item];
}

 

-(void)gapRubikDefs: (NSString *)input
{
    NSString    *item;
    NSArray     *output = [NSArray arrayWithObjects:
        @"\n\n#",
        @"\n# Identity Facelet Permutation:",
        @"\n#",
        @"\n#  12  34  56 78  90  12   34  56 78  90 12  34 567   890  123  456  789  012  345  678",
        @"\n#  UF UR UB UL DF DR DB DL FR FL BR BL UFR URB UBL ULF DRF DFL DLB DBR",
        @"\n#",
        @"\n# Rubik Group Face Turns",
        @"\n#",
        @"\nR1 := (3,17,11,21)(4,18,12,22)(25,39,46,30)(26,37,47,28)(27,38,48,29); R2 := R1 * R1; R3 := R1 * R2;",
        @"\nU1 := (1,3,5,7)(2,4,6,8)(25,28,31,34)(26,29,32,35)(27,30,33,36); U2 := U1 * U1 ; U3 := U1 * U2;",
        @"\nF1 := (1,20,9,18)(2,19,10,17)(25,35,40,38)(26,36,41,39)(27,34,42,37);  F2 := F1 * F1;  F3 := F1 * F2;",
        @"\nL1 := (7,23,15,19)(8,24,16,20)(31,45,40,36)(32,43,41,34)(33,44,42,35);  L2 := L1 * L1;  L3 := L1 * L2;",
        @"\nD1 := (9,15,13,11)(10,16,14,12)(37,40,43,46)(38,41,44,47)(39,42,45,48);  D2 := D1 * D1;  D3 := D1 * D2;",
        @"\nB1 := (5,22,13,24)(6,21,14,23)(28,48,43,33)(29,46,44,31)(30,47,45,32);  B2 := B1 * B1;  B3 := B1 * B2;",
        @"\n#\n",
        nil];
    
    for( item in output )
        [self report: item];
}

-(void)gapForSymKeys: (NSString *)input
{
    NSString        *line,
                    *key,
                    *cycleString;
    NSArray         *lines;
    OSG_SYMTAG      symtag;
    NSRange         hit;
    
    lines = [input componentsSeparatedByString: @"\n"];
    
    for(line in lines)
    {
        hit = [line rangeOfString: @"key: @\""];
        if( hit.location != NSNotFound)
        {
            if((hit.location + hit.length + 8) <= [line length] )
            {
                key = [line substringWithRange: NSMakeRange( hit.location + hit.length, 8 )];
                symtag = [OhGroup symtagForKey: key];
                cycleString = [self cycleStringForSymtag: symtag];
                
                [self report: [NSString stringWithFormat: @"\n\n# (%@)    ", key]];
                [self report: [OhGroup schoenfliesForSymtag: symtag]];
                [self report: [NSString stringWithFormat: @"\nS%d := %@;",symtag,cycleString]];
                
            }
        }
    }
}

-(void)gapForText: (NSString *)input
{
    NSArray         *lines;
    NSString        *line,
                    *item,
                    *cycle;
    NSData          *state;
    RBK_CLEAN_TEXT  clean;
    NSInteger       n;
    NSRange         hit;
    
    hit = [input rangeOfString: @"Start:" options: NSCaseInsensitiveSearch];
    if( hit.location != NSNotFound)
        n = [[input substringFromIndex: hit.location + hit.length] intValue];
    else
        n = 1;
    
    lines = [input componentsSeparatedByString: @"\n"];
    for( line in lines )
    {
        clean = [self cleanTextInput: line];
        
        item = clean.config;
        if( [item length] == 0 )
        {
            item = clean.turns;
            if( item != nil )
            {
                if([item length] > 0)
                {
                    state = [self stateForTurnString: item];
                    item = [self configurationForState: state];
                }
            }
        }
        
        if([item length] > 0 )
        {
            cycle = [self cycleStringForConfiguration: item];
            [self report: [NSString stringWithFormat: @"\n\n# %@\n# Configuration: ", line]];
            [self report: item];
            [self report: [NSString stringWithFormat: @"\n g%ld := %@;", n++, cycle]];
        }
        
    }
}

-(void)gapForTurns: (NSString *)input
{
    NSString            *line,
                        *turnString,
                        *gapProduct;
    NSData              *path;
    NSArray             *lines;
    RBK_CLEAN_TEXT      clean;
    NSInteger           n, c, max;
    const RBK_Turn      *p;
    RBK_Turn            turn;
    NSRange             hit;
    
    hit = [input rangeOfString: @"start:" options: NSCaseInsensitiveSearch];
    if( hit.location != NSNotFound)
        c = [[input substringFromIndex: hit.location + hit.length] intValue];
    else
        c = 1;
    
    lines = [input componentsSeparatedByString: @"\n"];
    for( line in lines )
    {
        clean = [self cleanTextInput: line];
        turnString = clean.turns;
        if( turnString != nil )
        {
            path = [self pathForTurnString: turnString];
            p = [path bytes];
            max = [path length] / sizeof(RBK_Turn);
            
            if( max > 0)
            {
                [self report: [NSString stringWithFormat: @"\n\n# Sequence: %@",turnString]];
                gapProduct = [NSString stringWithFormat: @"\ng%ld := ", c++];
                for( n = max - 1 ; n >= 0 ; n--)
                {
                    turn = p[n];
                    switch(turn)
                    {
                        case R1:
                            gapProduct = [gapProduct stringByAppendingString: @"R1 * "];
                            break;
                        case R2:
                            gapProduct = [gapProduct stringByAppendingString: @"R2 * "];
                            break;
                        case R3:
                            gapProduct = [gapProduct stringByAppendingString: @"R3 * "];
                            break;
                        
                        case U1:
                            gapProduct = [gapProduct stringByAppendingString: @"U1 * "];
                            break;
                        case U2:
                            gapProduct = [gapProduct stringByAppendingString: @"U2 * "];
                            break;
                        case U3:
                            gapProduct = [gapProduct stringByAppendingString: @"U3 * "];
                            break;
                    
                        case F1:
                            gapProduct = [gapProduct stringByAppendingString: @"F1 * "];
                            break;
                        case F2:
                            gapProduct = [gapProduct stringByAppendingString: @"F2 * "];
                            break;
                        case F3:
                            gapProduct = [gapProduct stringByAppendingString: @"F3 * "];
                            break;
                    
                        case L1:
                            gapProduct = [gapProduct stringByAppendingString: @"L1 * "];
                            break;
                        case L2:
                            gapProduct = [gapProduct stringByAppendingString: @"L2 * "];
                            break;
                        case L3:
                            gapProduct = [gapProduct stringByAppendingString: @"L3 * "];
                            break;
                    
                        case D1:
                            gapProduct = [gapProduct stringByAppendingString: @"D1 * "];
                            break;
                        case D2:
                            gapProduct = [gapProduct stringByAppendingString: @"D2 * "];
                            break;
                        case D3:
                            gapProduct = [gapProduct stringByAppendingString: @"D3 * "];
                            break;
                    
                        case B1:
                            gapProduct = [gapProduct stringByAppendingString: @"B1 * "];
                            break;
                        case B2:
                            gapProduct = [gapProduct stringByAppendingString: @"B2 * "];
                            break;
                        case B3:
                            gapProduct = [gapProduct stringByAppendingString: @"B3 * "];
                            break;
                            
                        default:
                            break;
                                
                    }
                }
                gapProduct = [gapProduct substringToIndex: [gapProduct length] - 3];
                gapProduct = [gapProduct stringByAppendingString: @";"];
                [self report: gapProduct];
            }
        }
        
    }
}


// Generate the 288 up face position permutations.  Reduce by C4 symmetry and U turn
// degeneracy.  Match to the states published on speedsolving.com
 

-(void)pllAnalysis: (NSString *)input
{
    NSArray             *c4,
                        *symClass,
                        *nameKeys;
    NSDictionary        *pllNames;
    NSSet               *class;
    NSString            *name,
                        *gentr,
                        *soln,
                        *cycl;
    NSMutableSet        *new,
                        *products,
                        *group,
                        *expClass;
    NSData              *item,
                        *old,
                        *pdt;
    NSUInteger          n;
    
    @autoreleasepool
    {
        //PLL permutations from speedsolving.com
        
        pllNames = [NSDictionary dictionaryWithObjectsAndKeys:
                   @"Aa",    [self stateForTurnString: @"R' F R' B2 R F' R' B2 R2"],
                   @"Ab",    [self stateForTurnString: @"R B' R F2 R' B R F2 R2"],
                   @"E",     [self stateForTurnString: @"D R' D2 F' D L D' F D2 R D' F' L' F"],
                   @"F",     [self stateForTurnString: @"R' U R U' R2 F' U' F U R F R' F' R2 U'"],
                   @"Ga",    [self stateForTurnString: @"R U2 R' U' F' R U R2 U' R' F R U R2 U2 R'"],
                   @"Gb",    [self stateForTurnString: @"R' U' R U D' R2 U R' U R U' R U' R2 D"],
                   @"Gc",    [self stateForTurnString: @"L' U' L U L U' F' L' U' L' U L F U' L U2 L'"],
                   @"Gd",    [self stateForTurnString: @"R U2 R' U B' R' U' R U R B U R' U' R' U R"],
                   @"H",     [self stateForTurnString: @"L R U2 L' R' F' B' U2 F B"],
                   @"Ja",    [self stateForTurnString: @"U R U R' U' R' F R2 U' R' U2 R U R' F' R U R' U' R' F R F'"],
                   @"Jb",    [self stateForTurnString: @"R U R' F' R U R' U' R' F R2 U' R' U'"],
                   @"Na",    [self stateForTurnString: @"R U R' U R U R' F' R U R' U' R' F R2 U' R' U2 R U' R'"],
                   @"Nb",    [self stateForTurnString: @"B R' U' R U R B' R2 B' U R U R' U' B R"],
                   @"Ra",    [self stateForTurnString: @"R U2 R' U2 R B' R' U' R U R B R2 U"],
                   @"Rb",    [self stateForTurnString: @"R' U2 R U2 R' F R U R' U' R' F' R2"],
                   @"T",     [self stateForTurnString: @"R U R' U' R' F R2 U' R' U' R U R' F'"],
                   @"Ua",    [self stateForTurnString: @"R2 U' R' U' R U R U R U' R"],
                   @"Ub",    [self stateForTurnString: @"R' U R' U' R' U' R' U R U R2"],
                   @"V",     [self stateForTurnString: @"R' U R' U' B' R' B2 U' B' U B' R B R"],
                   @"Y",     [self stateForTurnString: @"R' U' R U' L R U2 R' U' R U2 L' U R2 U R"],
                   @"Z",     [self stateForTurnString: @"R' U' R2 U R U R' U' R U R U' R U' R'"],
                   nil];
        
        nameKeys = [pllNames allKeys];
        
        group = [NSMutableSet setWithObjects:
                 [self stateForTurn: U1],
                 [nameKeys objectAtIndex: 0],   // Aa
                 [nameKeys objectAtIndex: 9],   // Ja
                  nil ];
        
        new = [NSMutableSet setWithSet: group];
        products = [NSMutableSet setWithSet: group];
        
        // Group Closure
        
        while( [new count] > 0)
        {
            for( item in new )
            {
                for( old in group )
                {
                    pdt = [self productOfAction: item andState: old];
                    [products addObject: pdt];
                    
                    pdt = [self productOfAction: old andState: item];
                    [products addObject: pdt];
                }
            }
            [new setSet: products];
            [new minusSet: group];
            [group setSet: products];
            
        }
        

        [self report: @"\n\nSymmetry Reduce PLL"];
        
        [self report: @"\n\nTab delimited text. Copy and paste to a spreadsheet\n"];
        
        // Symmetry Reduce by C4
        expClass = [NSMutableSet set];
        [new removeAllObjects];
        
        c4 = [OhGroup subgroupNamed: @"C4y" ];
        
        // Partition the PLL permutations into symmetry eq classes
        while( [group count] > 0 )
        {
            [products removeAllObjects];
            item = [group anyObject];
            
            for( cycl in c4 )
            {
                [products addObject: [self conjugateOfState: item bySymtag: [cycl intValue]]];
            }
            
            [group minusSet: products];
            
            [new setSet: products];
            
            // States differing by turns of the Up face are deemed equivalent
            for( item in products )
            {
                [new addObject: [self productOfTurn: U1 andState: item ]];
                [new addObject: [self productOfTurn: U2 andState: item ]];
                [new addObject: [self productOfTurn: U3 andState: item ]];
            }
            
            [expClass addObject: [NSSet setWithSet: new] ];
        }
        
        // Pick a representative element from each equivalence class
        
        [new removeAllObjects];
        
        for( class in expClass )
        {
            symClass = [class allObjects];
            
            // Prioritize states with the fewest changes in the UBL corner
            
            symClass = [symClass sortedArrayUsingComparator: ^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2)
                        {
                
                            const OSG_SYMTAG     *p1, *p2;
                            NSUInteger          n,c1,c2;
                            
                            p1 = [obj1 bytes];
                            p2 = [obj2 bytes];
                            
                            if( (p1[UBL] == 0) && (p2[UBL] == 0) )
                            {
                                if( (p1[UL] == 0) && (p1[UB] == 0))
                                    return NSOrderedAscending;
                                
                                if( (p2[UL] == 0) && (p2[UB] == 0))
                                    return NSOrderedDescending;
                                
                                if( p1[UL] == 0 )
                                    return NSOrderedAscending;
                                
                                if( p2[UL] == 0 )
                                    return NSOrderedDescending;
                                
                                if( p1[UB] == 0 )
                                    return NSOrderedAscending;
                                
                                if( p2[UB] == 0 )
                                    return NSOrderedDescending;
                            }
                            else
                            {
                                if( p1[UBL] == 0)
                                    return NSOrderedAscending;
                                if( p2[UBL] == 0 )
                                    return NSOrderedDescending;
                            }
                            
                            c1 = c2 = 0;
                            for( n = 0 ; n < 20 ; n++ )
                            {
                                if( p1[n] == 0 )
                                    c1++;
                                if( p2[n] == 0 )
                                    c2++;
                            }
                                
                            if( c1 > c2 )
                                return NSOrderedAscending;
                            if( c2 > c1 )
                                return NSOrderedDescending;
                               
                            return NSOrderedSame;
                        }];
            
            pdt = [symClass objectAtIndex: 0];
            
            if( ![pdt isEqualToData: [self identityState]] )
            {
                for( item in nameKeys)
                {
                    if( [class containsObject: [self inverseOfState: item]] )
                        break;
                }
                name = [pllNames objectForKey: item];
                item = [self pathForState: pdt];
                
                gentr = [self turnStringForPath: item];
                
                item = [self pathForState: [self inverseOfState: pdt] ];
                
                soln = [self turnStringForPath: item];
                
                cycl = [self singmasterCyclesForState: [self inverseOfState: pdt]];
                
                // Output as tab delimited text
                [new addObject: [NSString stringWithFormat: @"%@\t%@\t%@\t%@\n",name,gentr,soln,cycl] ];
            }
            
        }
        
        [self report: @"\n\tName\tGenerator\tSolution\tCycle Notation\n"];
        symClass = [[new allObjects] sortedArrayUsingSelector: @selector(compare:)];
        
        n = 1;
        for( name in symClass)
            [self report: [NSString stringWithFormat: @"\n%2ld\t%@", n++, name]];
        
        [self reportDone];
    }
}

-(NSString *)singmasterCyclesForState: (NSData *)state
{
    NSArray             *tokens;
    NSString            *cycleString,
                        *result,
                        *value;
    uint8               perm[20],
                        invPerm[20];
    RBK_Cubie            cubie;
    NSUInteger          start, end;
    NSRange             search,scope;
    const OSG_SYMTAG    *rep;
    BOOL                done,
                        inCycle;
    
    if( [state isEqual: [self identityState]])
        return @"()";
    
    tokens = [RBK_IDENTITY componentsSeparatedByString: @" "];
    
    rep = [state bytes];
    for( cubie = 0 ; cubie < 20 ; cubie++ )
        invPerm[cubie] = (uint8)[self positionOfCubie: cubie inState: rep[cubie] ];
    
    for( cubie = 0 ; cubie < 20 ; cubie++ )
        perm[ invPerm[cubie] ] = cubie;
    
    cycleString = [self cycleStringForPermutation: perm length: 20 ];
    
    if( [cycleString isEqualToString: @"()"] )
        return cycleString;
    
    start = 0;
    done = NO;
    result = @"";
    
    do
    {
        scope = NSMakeRange( start , [cycleString length] - start );
        search = [cycleString rangeOfString: @"("
                                    options: NSLiteralSearch
                                      range: scope];
        start = search.location + 1;
        
        if( search.location == NSNotFound)
            done = YES;
        else
        {
            scope = NSMakeRange( start , [cycleString length] - start );
            search = [cycleString rangeOfString: @")"
                                        options: NSLiteralSearch
                                          range: scope ];
            end = search.location;
            
            inCycle = YES;
            value = [cycleString substringFromIndex: start];
            cubie = [value intValue] - 1;
            result = [result stringByAppendingFormat: @"(%@", [tokens objectAtIndex: cubie ]];
            while( inCycle )
            {
                scope = NSMakeRange( start , [cycleString length] - start );
                search = [cycleString rangeOfString: @","
                                            options: NSLiteralSearch
                                              range: scope ];
                
                if( (search.location == NSNotFound ) || (search.location > end ) )
                {
                    inCycle = NO;
                    result = [result stringByAppendingString: @")"];
                }
                else
                {
                    start = search.location + 1;
                    value = [cycleString substringFromIndex: start];
                    cubie = [value intValue] - 1;
                    result = [result stringByAppendingFormat: @", %@", [tokens objectAtIndex: cubie ]];
                }
            }
        }
        
    }while( !done );
    
    return result;
}

-(void)statesAtDepth: (NSString *)input
{
    NSNumberFormatter   *formatter;
    NSString            *field;
    NSMutableSet        *set[3];
    NSData              *state,
                        *product;
    SymProxy            proxy;
    RBK_Turn            turn;
    NSRange             hit;
    NSInteger           maxTurn,
                        maxDepth;
    NSInteger           loop,
                        count,
                        dCount,
                        depth,
                        new,
                        current,
                        prev,
                        swap;
    
    @autoreleasepool
    {
        formatter = [[NSNumberFormatter alloc] init];
        [formatter autorelease];
        [formatter setNumberStyle: NSNumberFormatterDecimalStyle];
        [formatter setPaddingCharacter: @" "];
        [formatter setFormatWidth: 14];                 // 10,000,000,000
        
        hit = [input rangeOfString: @"ftm" options: NSCaseInsensitiveSearch];
        if( hit.location == NSNotFound )
        {
            maxTurn = RBK_qTURN_MAX;
            maxDepth = 8;
        }
        else
        {
            maxTurn = RBK_TURN_MAX;
            maxDepth = 7;
        }
        
        hit = [input rangeOfString: @"Depth:" options: NSCaseInsensitiveSearch];
        if( hit.location !=  NSNotFound )
            maxDepth = [[input substringFromIndex: hit.location + hit.length] intValue ];
        
        if( (maxDepth > 8) && (maxTurn == RBK_TURN_MAX) )
            maxDepth = 8;
        if( (maxDepth > 10) && (maxTurn == RBK_qTURN_MAX) )
            maxDepth = 10;
        
        
        
        prev = 0;
        current = 1;
        new = 2;
        
        set[prev] = [NSMutableSet setWithObject: [self identityState]];
        set[current] = [NSMutableSet setWithObject: [self identityState]];
        set[new] = [NSMutableSet set];
        
        [self report: @"\n\nDepth    Classes      Elements"];
        
        for(depth = 1  ; (depth <= maxDepth ) && ![self Abort] ; depth++ )
        {
            dCount = 0;
            loop = 0;
            for(state in set[current])
            {
                @autoreleasepool
                {
                    if( [self Abort] )
                        break;
                    
                    loop++;
                    if( loop % 1000 == 0)
                    {
                        [self reportProgress: 90.0 * (double)loop / [set[current] count]
                                       label: @" "];
                    }
                    for( turn = 0 ; turn < maxTurn ; turn++ )
                    {
                        product = [self productOfAction: [self stateForTurn: turn]
                                               andState: state];
                        
                        proxy = [self proxyOfState: product
                                        symmetries: @"Oh"
                                           antiSym: YES ];
                        
                        count = [set[prev] count];
                        [set[prev] addObject: proxy.proxy];
                        
                        if( count != [set[prev] count] )
                        {
                            [set[new] addObject: proxy.proxy];
                            dCount += proxy.size;
                        }
                        
     //  when using antisymmetry it is necessary to both left and right multiply

                        product = [self productOfAction: state
                                               andState: [self stateForTurn: turn]];

                        proxy = [self proxyOfState: product
                                        symmetries: @"Oh"
                                           antiSym: YES ];

                        count = [set[prev] count];
                        [set[prev] addObject: proxy.proxy];
                        if( count < [set[prev] count] )
                        {
                            [set[new] addObject: proxy.proxy];
                            dCount += proxy.size;
                        }
                    }
                }
            }
            if( ![self Abort] )
            {
                [self report: [NSString stringWithFormat: @"\n%2ld", depth]];
                field = [formatter stringFromNumber: [NSNumber numberWithInteger: [set[new] count]]];
                [self report: field];
                field = [formatter stringFromNumber: [NSNumber numberWithInteger: dCount]];
                [self report: field];
            }
             
            swap = prev;
            prev = current;
            current = new;
            new = swap;
             [set[new] removeAllObjects];
            [set[prev] unionSet: set[current] ];
        }
    }

    [self reportDone];

    
}

-(void)symmetryConjugateOfTurnSequence: (NSString *)input
{
    NSRange         hit;
    NSString        *key,
                    *turnString,
                    *result;
    NSData          *conj;
    OSG_SYMTAG      sym;
    RBK_CLEAN_TEXT  parse;
    
    hit = [input rangeOfString: @"\"" options: NSLiteralSearch];
    if( hit.location == NSNotFound )
    {
        [self report: @"\nUnable to read symmetry"];
        return;
    }
    
    key = [input substringFromIndex: hit.location + 1 ];
    if( [key length] < 8 )
    {
        [self report: @"\nUnable to read symmetry"];
        return;
    }

    key = [key substringToIndex: 8];
    sym = [OhGroup symtagForKey: key];
    
    parse = [self cleanTextInput: input];
    turnString = parse.turns;
    if( turnString == nil )
    {
        [self report: @"\nUnable to find a turn sequence"];
        return;
    }
    conj = [self conjugateOfPath: [self pathForTurnString: turnString]
                        bySymtag: sym];
    result = [self turnStringForPath: conj];
    
    [self report: @"\n\nSymmetry: "];
    [self report: [OhGroup schoenfliesForSymtag: sym] ];
    [self report: @"\nSequence: "];
    [self report: turnString];
    [self report: @"\nConjugate: "];
    [self report: result];   
}


-(void)textToConfiguration: (NSString *)input
{
    NSData          *item;
    RBK_CLEAN_TEXT  clean;
    NSArray         *lines;
    NSString        *line,
                    *config,
                    *turns;
    
    lines = [input componentsSeparatedByString: @"\n"];
    
    for(line in lines)
    {
        
        clean = [self cleanTextInput: line];
        config = clean.config;
        turns = clean.turns;
        
        if( [config isEqualToString: @""] )
        {
            if( [turns length] > 0 )
            {
                item = [self stateForTurnString: turns];
                config = [self configurationForState: item];
            }
                
        }
        
        if( [config length] > 0 )
        {
            [self report: @"\n\nInput: "];
            [self report: line];
            [self report: [NSString stringWithFormat: @"\nConfiguration: %@", config]];
        }
    }
    [self reportDone];
}

- (void)report: (id)comment
{
    NSDictionary    *info;

    info = [NSDictionary dictionaryWithObject: comment
                                       forKey: SB_REPORT];
    
    [[NSNotificationCenter defaultCenter] postNotificationName: SB_REPORT
                                                        object: self
                                                      userInfo: info];
    
}

- (void)reportDone
{
    [[NSNotificationCenter defaultCenter] postNotificationName: SB_FUNCTION_DONE
                                                        object: self];
    
    [self reportProgress: 0.0
                   label: @"      "];
}

- (void)reportProgress: (double)percent
                 label: (NSString *)label
{
    NSNumber                *progress;
    NSDictionary            *info;
    
    progress = [NSNumber numberWithDouble: percent];

    if( label == nil )
        info = [NSDictionary dictionaryWithObject: progress forKey: SB_PROGRESS];
    else
        info = [NSDictionary dictionaryWithObjectsAndKeys:
                progress,       SB_PROGRESS,
                label,          SB_PROGRESS_LABEL,
                nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName: SB_PROGRESS
                                                        object: self
                                                      userInfo: info];
}


#pragma  mark ***Developer Tests***

#define CEC_TEST    -1

-(void)developer: (NSString *)input
{
    @autoreleasepool
    {
        switch (CEC_TEST)
        {
            case 1:
                [self test1: input];
                break;
            case 2:
                [self test2: input];
                break;
            case 3:
                [self test3: input];
                break;
                
            default:
                [self report: @"\nNo test active"];
                break;
        }
    }
    [self reportDone];
}

-(void)test1: (NSString *)input
{
}


// Cross Check Group

-(void)test2: (NSString *)input
{
    NSString        *crossGenerators[2] =  { @"R D F R D R U R U D' F' D' F' U' F' R' U' F'",
                                            @"R F U R F R B R B F' U' F' U' B' U' R' B' U'"},
                    *checkGenerators[2] =  { @"D2 U' R B2 D' R' B F' L R' B U R2 B' D U2",
                                            @"U2 L2 R2 U D' R2 L2 D' U'"};
    NSSet           *crossGroup,
                    *checkGroup;
    NSMutableSet    *crossCheckGroup;
    NSMutableSet    *reduced;
    NSData          *item,
                    *path;
    SymProxy        proxy;
    
    // Gosh, isn't Block syntax fun?
    
    NSSet *(^closeGroup) (NSSet *) =
    ^ NSSet * (NSSet *generators)
    {
        NSMutableSet    *group, *new, *products;
        NSData          *item1, *item2;
        
        group = [NSMutableSet setWithSet: generators];
        new = [NSMutableSet setWithSet: generators];
        products = [NSMutableSet set];
        
        // Recursively form products
        
        while( [new count] > 0 )
        {
            for(item2 in new )
            {
                for( item1 in group )
                {
                    [products addObject: [self productOfAction: item2 andState: item1 ]];
                    [products addObject: [self productOfAction: item1 andState: item2 ]];
                }
            }
            [new setSet: products];
            [new minusSet: group];
            [group unionSet: products];
            [products removeAllObjects];
        }
        return group;
    };
    
    crossGroup = [NSSet setWithObjects:
                  [self  stateForTurnString: crossGenerators[0]],
                  [self stateForTurnString: crossGenerators[1]],
                  nil];
    crossGroup = closeGroup( crossGroup );
    
    checkGroup = [NSSet setWithObjects:
                  [self  stateForTurnString: checkGenerators[0]],
                  [self stateForTurnString: checkGenerators[1]],
                  nil];
    checkGroup = closeGroup(checkGroup);
    
    
    crossCheckGroup = [NSMutableSet setWithSet: crossGroup];
    [crossCheckGroup  unionSet: checkGroup];
    [crossCheckGroup setSet: closeGroup( crossCheckGroup )];
    
    reduced = [NSMutableSet set];
    
    for( item in crossCheckGroup)
    {
        proxy = [self proxyOfState: item
                        symmetries: @"O"
                           antiSym: NO];
        [reduced addObject: proxy.proxy];
    }
    
    for(item in reduced)
    {
        path = [self pathForState: item];
        [self report: @"\n"];
        [self report: [self turnStringForPath: path]];
    }
}

// test Oh Group subgroups
-(void)test3: (NSString *)input
{
    OSG_SYMTAG      sym;
    NSArray         *subgroup;
    NSString        *item;
    
    subgroup = [OhGroup subgroupNamed: input];
    if( subgroup != nil )
    {
        [self report: [NSString stringWithFormat: @"\n\nSubgroup: %@\n", input]];
        for( item in subgroup )
        {
            sym = [item intValue];
            [self report: @"\n"];
            [self report: [OhGroup schoenfliesForSymtag: sym]];            
        }
    }
}



@end
