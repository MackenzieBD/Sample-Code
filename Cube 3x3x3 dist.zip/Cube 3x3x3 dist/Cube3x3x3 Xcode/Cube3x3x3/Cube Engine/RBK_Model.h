//
//  RBK_Model.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import <Foundation/Foundation.h>
#import "RBK_Model_Protocol.h"
#import "RBK_Model_Defs.h"
#import "OhSymmetryGroup.h"

NS_ASSUME_NONNULL_BEGIN

@interface RBK_Model : NSObject <RBK_Model_Protocol>
{
    OhSymmetryGroup     *OhGroup;
}

@property (retain) OhSymmetryGroup *OhGroup;

@property (assign) BOOL Abort;

-(NSArray *)configurationCodes;

-(RBK_CLEAN_TEXT)cleanTextInput: (NSString *)dirty;

-(NSString *)configurationForCycleString: (NSString *)cycleString;

-(NSString *)cycleStringForConfiguration: (NSString *)config;

-(NSString *)cycleStringForSymtag: (OSG_SYMTAG)symtag;

-(NSString *)cycleStringForPermutation: (const uint8 *)perm length: (NSUInteger)max;

-(NSData *)pathForTurnString: (NSString *)turnString;

-(NSString *)randomConfiguration;

-(NSData *)stateForTurn: (RBK_Turn)turn;

-(NSString *)tokenForTurn: (RBK_Turn)turn;

-(RBK_Turn)turnForToken: (NSString *)token;

-(NSString *)turnStringForPath: (NSData *)path;

-(NSData *)identityState;

-(BOOL)isValidConfiguration: (NSString *)config;

@end

NS_ASSUME_NONNULL_END
