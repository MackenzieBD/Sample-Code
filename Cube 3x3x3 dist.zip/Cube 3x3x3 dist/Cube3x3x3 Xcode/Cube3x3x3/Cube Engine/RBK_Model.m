//
//  RBK_Model.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//
//  Base Class for Rubik's Cube Models

#import "RBK_Model.h"


@implementation RBK_Model

-(void)dealloc
{
    [OhGroup release];
    
    [super dealloc];
}

@synthesize OhGroup;

-(instancetype)init
{
    self = [super init];
    
    if( self != nil )
    {
        OhSymmetryGroup    *sym;
        
        sym = [[OhSymmetryGroup alloc] init];
        [self setOhGroup: sym];
        [sym release];
    }    
    return self;
}

#pragma mark     **Protocol Methods**

// Subclasses must overide with methods appropriate to their cube representation

- (NSData *)productOfAction:(NSData *)action andState:(NSData *)state
{
    return nil;
}

- (NSData *)inverseOfState:(NSData *)state
{
    return nil;
}

-(NSData *)stateForConfiguration: (NSString *)configuration
{
    return nil;
}

- (NSString *)configurationForState:(NSData *)state
{
    return nil;
}

#pragma mark   **End Protocol Methods**

// Parse User input. This method tries to pull out a configuration string
// or a turn sequence. The result is returned in an NSDictionary.
// The Key for any a turn sequence string is @"TURNS" and for a configuration @"CONFIG"

-(RBK_CLEAN_TEXT)cleanTextInput: (NSString *)dirty
{
    NSMutableString     *working;
    NSArray             *tokens,
                        *configCodes,
                        *turnCodes;
    NSMutableArray      *turnTokens,
                        *configTokens;
    BOOL                done;
    NSString            *s1,*s2;
    NSInteger           start,
                        end;
    NSRange             hit1,
                        hit2,
                        sub;
    NSInteger           i,n;
    
    working = [NSMutableString stringWithString: dirty];
    
    hit1 = [working rangeOfString: @"random" options: NSCaseInsensitiveSearch];
    if( hit1.location != NSNotFound )
        [working replaceCharactersInRange: hit1 withString: [self randomConfiguration]];
    
    // Convert cycle strings
    
    hit1 = [working rangeOfString: @"("];
    if( hit1.location != NSNotFound )
    {
        start = hit1.location;
        do
        {
            end = hit1.location;
            hit1 = [working rangeOfString: @")"
                                  options: NSLiteralSearch
                                    range: NSMakeRange( hit1.location + 1,  [working length] - hit1.location - 1) ];
        }while(hit1.location != NSNotFound);
        hit2 = NSMakeRange( start ,  end - start + 1);
        s1 = [working substringWithRange: hit2 ];
        s2 = [self configurationForCycleString: s1];
        
        if( s2 != nil )
        {
            s2 = [@" " stringByAppendingString: s2];
            s2 = [s2 stringByAppendingString: @" "];
            [working replaceCharactersInRange: hit2 withString: s2];
        }
    }

    // expand parentheses
    done = NO;
    start = 0;
    while( !done )
    {
        hit1 = [working rangeOfString: @"("
                             options: NSLiteralSearch
                               range: NSMakeRange( start ,  [working length] - start)];
               
        if(hit1.location == NSNotFound)
            done = YES;
        else
        {
            hit2 = [working rangeOfString: @")"
                                 options: NSLiteralSearch
                                   range: NSMakeRange( hit1.location , [working length] - hit1.location)];
            
            if( hit1.location != NSNotFound )
            {
                s1 = [working substringFromIndex: hit2.location + 1];
                n = [s1 intValue];
                if(n > 0)
                {
                    [working replaceCharactersInRange: NSMakeRange( hit1.location, 1)
                                           withString: @" "];
                    [working replaceCharactersInRange: NSMakeRange( hit2.location, 1)
                                           withString: @" "];
                    sub = NSMakeRange( hit1.location, hit2.location - hit1.location +1 );
                    s1 = [working substringWithRange: sub];
                    s2 = @"";
                    for( i = 0 ; i < n ; i++ )
                        s2 = [s2 stringByAppendingString: s1];
                    
                    [working replaceCharactersInRange: sub
                                           withString: s2];
                    start = hit1.location + 1;
                }
                else
                    done = YES;
            }
            else
                done = YES;
            
        }
    }
    
    [working insertString: @" " atIndex: 0];
    [working appendString: @" "];
    
    s1 = @"()[]{}\n\r\t•,.:;";
    do
    {
        s2 = [NSString stringWithString: working];
         
         for( n = 0 ; n < [s1 length] ; n++ )
             [working replaceOccurrencesOfString: [s1 substringWithRange: NSMakeRange( n , 1 )]
                                    withString: @" "
                                       options: NSLiteralSearch
                                         range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"’"
                               withString:@"'"
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length])];
        
        [working replaceOccurrencesOfString: @"`"
                               withString:@"'"
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length])];
        
        [working replaceOccurrencesOfString: @"‘"
                               withString:@"'"
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length])];
         
         
         [working replaceOccurrencesOfString: @" R- "
                                withString: @" R' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" L- "
                                withString: @" L' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" U- "
                                withString: @" U' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" D- "
                                withString: @" D' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" F- "
                                withString: @" F' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" B- "
                                withString: @" B' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" R+ "
                                withString: @" R "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" L+ "
                                withString: @" L "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" U+ "
                                withString: @" U "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" D+ "
                                withString: @" D "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" F+ "
                                withString: @" F "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" B+ "
                                withString: @" B "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Rs "
                                withString: @" R' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Ls "
                                withString: @" L "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Us "
                                withString: @" U' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Ds "
                                withString: @" D "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Fs "
                                withString: @" F' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Bs "
                                withString: @" B "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Rr "
                                withString: @" R "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Lr "
                                withString: @" L' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Ur "
                                withString: @" U "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Dr "
                                withString: @" D' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Fr "
                                withString: @" F "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
         
         [working replaceOccurrencesOfString: @" Br "
                                withString: @" B' "
                                   options: NSLiteralSearch
                                     range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" R1 "
                               withString: @" R "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" R3 "
                               withString: @" R' "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" L1 "
                               withString: @" L "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" L3 "
                               withString: @" L' "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" U1 "
                               withString: @" U "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" U3 "
                               withString: @" U' "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" D1 "
                               withString: @" D "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" D3 "
                               withString: @" D' "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" F1 "
                               withString: @" F "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" F3 "
                               withString: @" F' "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" B1 "
                               withString: @" B "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @" B3 "
                               withString: @" B' "
                                  options: NSLiteralSearch
                                    range: NSMakeRange( 0 , [working length] )];
       
    }while( ![s2 isEqualToString: working] );
    
    tokens = [working componentsSeparatedByString: @" "];
    turnTokens = [NSMutableArray array];
    configTokens = [NSMutableArray array];
    configCodes = [self configurationCodes];
    turnCodes = [RBK_TOKEN_STRING componentsSeparatedByString: @" "];
    
    for( s1 in tokens )
    {
        i = [configCodes indexOfObject: s1];
        if( i != NSNotFound )
           [configTokens addObject: s1];
        
        i = [turnCodes indexOfObject: s1 ];
        if( i != NSNotFound )
           [turnTokens addObject: s1];
    }
    
    s1 = [configTokens componentsJoinedByString: @" "];
    if( ![self isValidConfiguration: s1] )
        s1 = @"";
    s2 = [turnTokens componentsJoinedByString: @" "];
    
    [working setString: s2];
    
    do
    {
        s2 = [NSString stringWithString: working];
        
        [working replaceOccurrencesOfString: @"R R"
           withString: @"R2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"R' R'"
           withString: @"R2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"U U"
           withString: @"U2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"U' U'"
           withString: @"U2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"F F"
           withString: @"F2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"F' F'"
           withString: @"F2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"L' L'"
           withString: @"L2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"L L"
           withString: @"L2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"D D"
           withString: @"D2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"D' D'"
           withString: @"D2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"B B"
           withString: @"B2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
        [working replaceOccurrencesOfString: @"B' B'"
           withString: @"B2"
              options: NSLiteralSearch
                range: NSMakeRange( 0 , [working length] )];
        
    }while( ![s2 isEqualToString: working] );
    
    RBK_CLEAN_TEXT text;
    
    text.config = s1;
    text.turns = s2;
    return text;
}

//  Michael Reid cleverly designed the Standard Configuration
//  cube representation to simply encode the orientation.
//  Codes in first column are unflipped/untwisted no
//  matter in what position they appear.  Codes in the
//  second column show cubies with flipped/CW orientation.
//  Codes in the third column show cubies with CCW orientation.

-(NSArray *)configurationCodes
{
    return [NSArray arrayWithObjects:
//           E        flip
            @"UF",    @"FU",
            @"UR",    @"RU",
            @"UB",    @"BU",
            @"UL",    @"LU",
            @"DF",    @"FD",
            @"DR",    @"RD",
            @"DB",    @"BD",
            @"DL",    @"LD",
            @"FR",    @"RF",
            @"FL",    @"LF",
            @"BR",    @"RB",
            @"BL",    @"LB",
//            E          CW         CCW
            @"UFR",    @"FRU",    @"RUF",
            @"URB",    @"RBU",    @"BUR",
            @"UBL",    @"BLU",    @"LUB",
            @"ULF",    @"LFU",    @"FUL",
            @"DRF",    @"RFD",    @"FDR",
            @"DFL",    @"FLD",    @"LDF",
            @"DLB",    @"LBD",    @"BDL",
            @"DBR",    @"BRD",    @"RDB",
            nil];
}

-(NSString *)configurationForCycleString: (NSString *)cycleString
{
    NSString            *identity,
                        *config;
    NSMutableArray      *tokens;
    unichar             buffer[48];
    NSData              *perm;
    const uint8         *p;
    NSUInteger          n;
    
    identity =  [RBK_IDENTITY stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    perm = [self permutationForCycleString: cycleString length: 48];
    
    if( perm == nil )
        return nil;
    
    p = [perm bytes];
    
    for( n = 0 ; n < 48 ; n++ )
        buffer[n] = [identity characterAtIndex: p[n] ];
    
    tokens = [NSMutableArray array];
    for( n = 0 ; n < 24 ; n += 2 )
        [tokens addObject: [NSString stringWithCharacters: &buffer[n] length: 2]];
    for( n = 24 ; n < 48 ; n += 3 )
        [tokens addObject: [NSString stringWithCharacters: &buffer[n] length: 3]];
    
    config = [tokens componentsJoinedByString: @" "];
    
    if( [self isValidConfiguration: config] == YES )
        return config;
    else
        return nil;
}

-(NSString *)cycleStringForConfiguration: (NSString *)config
{
    uint8           rep[48];
    NSArray         *codes;
    RBK_Cubicle     cubicle;
    NSArray         *configCodes;
    NSUInteger      slot,
                    orient,
                    facelet;
    
    codes = [config componentsSeparatedByString: @" "];
    configCodes = [self configurationCodes];
    
    for( cubicle = 0 ; cubicle < 12 ; cubicle++ )
    {
        slot = 2 * cubicle;
        facelet = [configCodes indexOfObject: [codes objectAtIndex: cubicle]];
        
        if( facelet == NSNotFound)
            return nil;
        
        orient = facelet % 2;
        facelet -= orient;
        
        if( orient == 0 )
        {
            rep[ slot ] = facelet;
            rep[ slot + 1] = facelet + 1;
        }
        else
        {
            rep[ slot ] = facelet + 1;
            rep[ slot + 1 ] = facelet;
        }
    }
    
    for( cubicle = 12 ; cubicle < 20 ; cubicle++ )
    {
        slot = 3 * cubicle - 12;
        facelet = [configCodes indexOfObject: [codes objectAtIndex: cubicle]];
        
        if( facelet == NSNotFound)
            return nil;
        
        orient = facelet % 3;
        facelet -= orient;
        
        switch( orient )
        {
            case 0:
                rep[ slot ] = facelet;
                rep[ slot + 1] = facelet + 1;
                rep[ slot + 2] = facelet + 2;
                break;
                
            case 1:
                rep[ slot ] = facelet + 1;
                rep[ slot + 1] = facelet + 2;
                rep[ slot + 2] = facelet;
                break;
                
            case 2:
                rep[ slot ] = facelet + 2;
                rep[ slot + 1] = facelet;
                rep[ slot + 2] = facelet + 1;
                break;
        }
    }
    
    return [self cycleStringForPermutation: rep length: 48 ];
}

// Compose a canonical cycle string suitable for GAP for the input.
// The input may be zero based or 1 based

-(NSString *)cycleStringForPermutation: (const uint8 *)perm length: (NSUInteger)max
{
    NSMutableString         *result;
    uint8                   *working,
                            *flags;
    BOOL                    isZeroBased = NO,
                            done = NO;
    NSInteger               n, base, next;
    
    result = [NSMutableString string];
    working = [[NSMutableData dataWithLength: sizeof(uint8 [max])] mutableBytes];
    flags = [[NSMutableData dataWithLength: sizeof(uint8 [max])] mutableBytes];
    
    for( n = 0 ; n < max ; n++ )
    {
        working[n] = perm[n];
        flags[n] = 1;
        if(perm[n] == 0)
            isZeroBased = YES;
    }
    
    if( !isZeroBased )
        for( n = 0 ; n < max ; n++ )
            working[n] = working[n] - 1;
    
    // Is this a well formed permutation?
    for( next = 0 ; (next < max ) && !done ; next++ )
    {
        done = YES;
        n = 0;
        while( done && (n < max) )
            if( working[n++] == (uint8)next )
                done = NO;
    }
    
    if( done )
    {
        NSMutableSet    *set1, *set2;
        set1 = [NSMutableSet set];
        set2 = [NSMutableSet set];
        for( n = 0 ; n < max ; n++ )
        {
            [set1 addObject: [NSString stringWithFormat: @"%ld", n ]];
            [set2 addObject: [NSString stringWithFormat: @"%d", working[n]]];
        }
        if( ![set1 isEqualToSet: set2] )
        {
            [set1 minusSet: set2];
            return @"Invalid Permutation";
        }
    }
    
    while( !done )
    {
        n = 0;
        
        while( (n < max) && (flags[n] == 0) )
            n++;
        
        if( n == max )
            done = YES;
        else
        {
            base = n;
            next = working[n];
            flags[n] = 0;
            
            if( base != next )
            {
                [result appendFormat: @"(%ld" , base + 1 ];  // output is for 1 based perm
                
                while( base != next )
                {
                    flags[next] = 0;
                    [result appendFormat: @",%ld", next + 1 ];
                    next = working[next];
                }
                [result appendString: @")"];
            }
            
        }
    }
    
    if( [result length] == 0)
        [result setString: @"()"];
    
    return result;
}

// Returns a permutation giving the action of the passed
// symmetry on the positions of the facelets as a
// canonical cycle string.

-(NSString *)cycleStringForSymtag: (OSG_SYMTAG)symtag
{
    NSMutableArray  *vectors;
    uint8_t         index,
                    perm[48];
    OSG_VECTOR_t    vector[3];
    NSData          *newVector;
    NSUInteger      facelet, cubie;
    NSString        *ident;
    unichar         c;
    
    //Home positions of the cubies
    OSG_VECTOR_t     centers[20][3] =
    {
        { 0 , 1 , 1 },    // UF
        { 1 , 1 , 0 },    // UR
        { 0 , 1 ,-1 },    // UB
        {-1 , 1 , 0 },    // UL
        { 0 ,-1 , 1 },    // DF
        { 1 ,-1 , 0 },    // DR
        { 0 ,-1 ,-1 },    // DB
        {-1 ,-1 , 0 },    // DL
        { 1 , 0 , 1 },    // FR
        {-1 , 0 , 1 },    // FL
        { 1 , 0 ,-1 },    // BR
        {-1 , 0 ,-1 },    // BL
        
        { 1 , 1 , 1 },    // UFR
        { 1 , 1 ,-1 },    // URB
        {-1 , 1 ,-1 },    // UBL
        {-1 , 1 , 1 },    // ULF
        { 1 ,-1 , 1 },    // DRF
        {-1 ,-1 , 1 },    // DFL
        {-1 ,-1 ,-1 },    // DLB
        { 1 ,-1 ,-1 },    // DBR
    };
    
    vectors = [NSMutableArray array];
    ident = [RBK_IDENTITY stringByReplacingOccurrencesOfString: @" "
                                                    withString: @""];
    
    for(facelet = 0 ; facelet < 48 ; facelet++ )
    {
        if( facelet < 24 )
            cubie = facelet / 2;
        else
            cubie = 12 + (facelet - 24) / 3;
        
        vector[0] = centers[cubie][0];
        vector[1] = centers[cubie][1];
        vector[2] = centers[cubie][2];
        
        c = [ident characterAtIndex: facelet ];
        switch (c)
        {
            case 'R':
                vector[0] += 1;
                break;
                
            case 'L':
                vector[0] -= 1;
                break;
                
            case 'U':
                vector[1] += 1;
                break;
                
            case 'D':
                vector[1] -= 1;
                break;
                
            case 'F':
                vector[2] += 1;
                break;
                
            case 'B':
                vector[2] -= 1;
                break;
                
            default:
                break;
        }
        [vectors addObject: [NSData dataWithBytes: vector length: sizeof(OSG_VECTOR_t [3])]];
    }
    
    for( facelet = 0 ; facelet < 48 ; facelet++)
    {
        newVector = [OhGroup productOfTag: symtag
                                         vector: [vectors objectAtIndex: facelet]];
        
        index = [vectors indexOfObject: newVector];
        
        perm[index] = facelet;
    }
    return  [self cycleStringForPermutation: perm length: 48];
}

-(NSData *)identityState
{
    return [self stateForConfiguration: RBK_IDENTITY];
}

// Check that each cubie appears once and only once
// Check orientation and position parities

-(BOOL)isValidConfiguration:(NSString *)config
{
    int         perm[20],
                orient[20],
                count[20];
    NSArray     *codes,
                *tokens;
    NSInteger   i,n,p,index;
    NSString    *token;
    
    codes = [self configurationCodes];
    tokens = [config componentsSeparatedByString: @" "];
    if( [tokens count] != 20 )
        return NO;
    
    for( n = 0 ; n < 20 ; n++ )
        perm[n] = orient[n] = count[n] = 0;
    
    // init the position permutation and orientation list
    for( n = 0 ; n < 20 ; n++ )
    {
        token = [tokens objectAtIndex: n];
        index = [codes indexOfObject: token];
        if( index == NSNotFound )
            return NO;
        if( index < 24 )
        {
            perm[n] = (int)index / 2;
            orient[n] = index % 2;
            count[perm[n]]++;
        }
        else
        {
            perm[n] = 12 + ((int)index - 24) / 3;
            orient[n] = index % 3;
            count[perm[n]]++;
        }
    }
    
    for( n = 0 , index = 0 ; index < 12 ; index++ )
    {
        n ^= orient[index];
        if( count[index] != 1 )
            return NO;
    }
    if( n != 0 )
        return NO; //Bad flip
    
    for( ; index < 20 ; index++ )
    {
        n += orient[index];
        if( count[index] != 1 )
            return NO;
    }
    n %= 3;
    if( n != 0 )
        return NO; //Bad twist
    
    // Count inversions for position parity
    for( p = 0 , i = 0 ; i < 19 ; i++ )
        for( n = i + 1 ; n < 20 ; n ++ )
            if( perm[i] > perm[n] )
                p ^= 1;
    
    if(p != 0)
        return NO; //Bad position parity
    
    return YES;
}

// returns nil if turnString is not clean

-(NSData *)pathForTurnString:(NSString *)turnString
{
    NSArray             *tokens;
    NSString            *token;
    NSSet               *valid;
    NSMutableData       *result;
    RBK_Turn            *turn;
    NSInteger           n;
    
    tokens = [turnString componentsSeparatedByString: @" "];
    valid = [NSSet setWithArray: [RBK_TOKEN_STRING componentsSeparatedByString: @" "] ];
    
    if( ![[NSSet setWithArray: tokens] isSubsetOfSet: valid] )
        return nil;
    
    result = [NSMutableData dataWithLength: sizeof(RBK_Turn [[tokens count]] )] ;
    turn = [result mutableBytes];
    
    n = 0;
    for( token in tokens )
        turn[n++] = [self turnForToken: token];
    
    return result;
}


// Convert a 1 based GAP canonical cycle string to a zero based perm as a
// uint8 C array

-(NSData *)permutationForCycleString: (NSString *)cycleString length: (NSInteger)length
{
    NSMutableData       *result;
    uint8               *perm,
                        base,
                        value;
    NSArray             *cycles;
    NSArray             *values;
    NSMutableString     *working;
    NSString            *item;
    NSRange             range;
    NSInteger           n,
                        slot;
    
    working = [NSMutableString stringWithString: cycleString];
    result = [NSMutableData dataWithLength: sizeof(uint8 [length])];
    perm = [result mutableBytes];
    
    for(n = 0 ; n < length ; n++)
        perm[n] = n;
    
    cycles = [working componentsSeparatedByString: @"("];
    
    for( item in cycles )
    {
        range = [item rangeOfString: @")"];
        if( range.location != NSNotFound)
        {
            item = [item substringToIndex: range.location];
            values = [item componentsSeparatedByString: @","];
            
            base = [[values objectAtIndex: 0 ] integerValue] - 1;
            if( base >= length )
                return nil;
            value = base;
            for( n = 0 ; n < [values count] - 1 ; n++ )
            {
                slot = [[values objectAtIndex: n] integerValue] - 1;
                value = [[values objectAtIndex: n+1] integerValue] - 1;
                if( (slot >= length) || (value >= length ))
                    return nil;
                perm[slot] = value;
            }
            perm[value] = base;
        }
    }

    return result;
    
}

// Return a random permutation of the Singmaster/Reid configuration string:
// @"UF UR UB UL DF DR DB DL FR FL BR BL UFR URB UBL ULF DRF DFL DLB DBR"

-(NSString *)randomConfiguration
{
    uint8               edgePerm[12],
                        cornerPerm[8],
                        flip[12],
                        twist[8];
    uint64              edgeIndex,
                        cornerIndex,
                        flipIndex,
                        twistIndex;
    NSInteger           i,n,m,p;
    NSMutableArray      *list;
    NSArray             *codes;
    NSMutableArray      *configuration;
    
    flipIndex = [self randomModulo: 2048];            // 2^11 flip arrangements;
    twistIndex = [self randomModulo: 2187];           // 3^7 twist arrangements;
    
    edgeIndex = [self randomModulo: 479001600]; // 12! edge permutations
    cornerIndex = [self randomModulo: 40320];  // 8! corner permutations
    
    // Unpack the position permutations
    // Sliding radix encoding
    
    list = [NSMutableArray arrayWithObjects: @"0", @"1", @"2", @"3", @"4", @"5", @"6", @"7", @"8", @"9", @"10", @"11",nil];
    for(i = 0, n = 12; i < 12 ; i++ , n--)
    {
        p = edgeIndex % n;
        edgePerm[i] = [[list objectAtIndex: p] intValue];
        [list removeObjectAtIndex: p];
        edgeIndex /= n;
    }
    
    list = [NSMutableArray arrayWithObjects: @"0", @"1", @"2", @"3", @"4", @"5", @"6", @"7",nil];
    for(i = 0, n = 8; i < 8 ; i++ , n--)
    {
        p = cornerIndex % n;
        cornerPerm[i] = [[list objectAtIndex: p] intValue];
        [list removeObjectAtIndex: p];
        cornerIndex /= n;
    }
    
    // Count inversions
    for( p = 0 , i = 0 ; i < 11 ; i++ )
        for( n = i + 1 ; n < 12 ; n ++ )
            if( edgePerm[i] > edgePerm[n] )
                p ^= 1;
    m = p;
    for( p = 0 , i = 0 ; i < 7 ; i++ )
        for( n = i + 1 ; n < 8 ; n ++ )
            if( cornerPerm[i] > cornerPerm[n] )
                p ^= 1;
    
//   is parity odd?
    if( (p + m) == 1 )
    {
        //swap two cubies
        i = edgePerm[0];
        edgePerm[0] = edgePerm[1];
        edgePerm[1] = i;
    }
    
    // unpack the orientations
    
    flip[11] = 0;
    for( i = 0 ; i < 11 ; i++ )
    {
        flip[i] = flipIndex & 1;
        flipIndex /= 2;
        flip[11] ^= flip[i];
    }
    
    twist[7] = 0;
    for( i = 0 ; i < 7 ; i++ )
    {
        twist[i] = twistIndex % 3;
        twistIndex /= 3;
        twist[7] += twist[i];
    }
    twist[7] = (21 - twist[7]) % 3;
    
    // permute the facelet permutation
    codes = [self configurationCodes];
    
    configuration = [NSMutableArray arrayWithCapacity: 20];
    for( i = 0 ; i < 12 ; i++ )
        [configuration addObject: [codes objectAtIndex: 2 * edgePerm[i] + flip[i] ]];
    
    for( i = 0 ; i < 8 ; i++ )
        [configuration addObject: [codes objectAtIndex: 24 + 3 * cornerPerm[i] + twist[i] ]];
    
    return [configuration componentsJoinedByString: @" "];
}


// Return a crytographically secure random number
-(uint64)random64
{
    uint64_t    value = 0;
    uint8       randomByte;
    int         i, err;
    
   for (i = 0 ; i < sizeof(value); i++)
    {
        value <<= 8;
        err = SecRandomCopyBytes( kSecRandomDefault ,  1 ,  &randomByte );
        value |= randomByte;
    }
    
    return value;
}


// Return a random number in the range of 0 to mod-1.
// Modulo bias fixed.
// Consider: random8 gives numbers 0 to 255
// modulo 10 yields random 0 to 9 for the ranges
// 0 to 9
// 10 to 19
// …
// 240 to 49
// but 0 to 5 for the range 250 to 255, biasing those numbers
// so reject that range

-(uint64)randomModulo: (uint64)mod
{
    uint64_t    value,
                max;
    
    max = UINT64_MAX % mod;
    max = UINT64_MAX - max - 1;
    
    do
    {
        value = [self random64];
    }while( value >= max );
    
    return value % mod;
}

-(NSData *)stateForTurn: (RBK_Turn)turn
{
    NSString    *config;
    
    switch (turn)
    {
        case R1:
            config = @"UF FR UB UL DF BR DB DL DR FL UR BL FDR FRU UBL ULF BRD DFL DLB BUR";
            break;
        case R2:
            config = @"UF DR UB UL DF UR DB DL BR FL FR BL DBR DRF UBL ULF URB DFL DLB UFR";
            break;
        case R3:
            config = @"UF BR UB UL DF FR DB DL UR FL DR BL BUR BRD UBL ULF FRU DFL DLB FDR";
            break;
            
        case U1:
            config = @"UR UB UL UF DF DR DB DL FR FL BR BL URB UBL ULF UFR DRF DFL DLB DBR";
            break;
        case U2:
            config = @"UB UL UF UR DF DR DB DL FR FL BR BL UBL ULF UFR URB DRF DFL DLB DBR";
            break;
        case U3:
            config = @"UL UF UR UB DF DR DB DL FR FL BR BL ULF UFR URB UBL DRF DFL DLB DBR";
            break;
            
        case F1:
            config = @"LF UR UB UL RF DR DB DL FU FD BR BL LFU URB UBL LDF RUF RFD DLB DBR";
            break;
        case F2:
            config = @"DF UR UB UL UF DR DB DL FL FR BR BL DFL URB UBL DRF ULF UFR DLB DBR";
            break;
        case F3:
            config = @"RF UR UB UL LF DR DB DL FD FU BR BL RFD URB UBL RUF LDF LFU DLB DBR";
            break;
            
        case L1:
            config = @"UF UR UB BL DF DR DB FL FR UL BR DL UFR URB BDL BLU DRF FUL FLD DBR";
            break;
        case L2:
            config = @"UF UR UB DL DF DR DB UL FR BL BR FL UFR URB DFL DLB DRF UBL ULF DBR";
            break;
        case L3:
            config = @"UF UR UB FL DF DR DB BL FR DL BR UL UFR URB FUL FLD DRF BDL BLU DBR";
            break;
            
        case D1:
            config = @"UF UR UB UL DL DF DR DB FR FL BR BL UFR URB UBL ULF DFL DLB DBR DRF";
            break;
        case D2:
            config = @"UF UR UB UL DB DL DF DR FR FL BR BL UFR URB UBL ULF DLB DBR DRF DFL";
            break;
        case D3:
            config = @"UF UR UB UL DR DB DL DF FR FL BR BL UFR URB UBL ULF DBR DRF DFL DLB";
            break;
            
        case B1:
            config = @"UF UR RB UL DF DR LB DL FR FL BD BU UFR RDB RBU ULF DRF DFL LUB LBD";
            break;
        case B2:
            config = @"UF UR DB UL DF DR UB DL FR FL BL BR UFR DLB DBR ULF DRF DFL URB UBL";
            break;
        case B3:
            config = @"UF UR LB UL DF DR RB DL FR FL BU BD UFR LUB LBD ULF DRF DFL RDB RBU";
            break;
            
        default:
            config = nil;
            break;
    }
    
    return [self stateForConfiguration: config ];
}

-(NSString *)tokenForTurn: (RBK_Turn)turn
{
    NSString    *token;
    
    switch (turn)
    {
        case R1:
            token = @"R";
            break;
            
        case R2:
            token = @"R2";
            break;
            
        case R3:
            token = @"R'";
            break;
            
        case U1:
            token = @"U";
            break;
            
        case U2:
            token = @"U2";
            break;
            
        case U3:
            token = @"U'";
            break;
    
        case F1:
            token = @"F";
            break;
            
        case F2:
            token = @"F2";
            break;
            
        case F3:
            token = @"F'";
            break;
    
        case L1:
            token = @"L";
            break;
            
        case L2:
            token = @"L2";
            break;
            
        case L3:
            token = @"L'";
            break;
    
        case D1:
            token = @"D";
            break;
            
        case D2:
            token = @"D2";
            break;
            
        case D3:
            token = @"D'";
            break;
    
        case B1:
            token = @"B";
            break;
            
        case B2:
            token = @"B2";
            break;
            
        case B3:
            token = @"B'";
            break;
                    
        default:
            token = nil;
            break;
    }
    
    return token;
}

-(RBK_Turn)turnForToken: (NSString *)token
{
    NSString    *tokenString = RBK_TOKEN_STRING;
    NSArray     *tokens;
    NSUInteger  i;
    
    tokens = [tokenString componentsSeparatedByString: @" "];
    
    i = [tokens indexOfObject: token];
    
    if( i == NSNotFound )
        return RBK_TURN_MAX;
    else
        return (RBK_Turn)i;
}

-(NSString *)turnStringForPath:(NSData *)path
{
    NSString        *result = @"";
    RBK_CLEAN_TEXT  clean;
    const RBK_Turn  *turn;
    NSString        *item;
    NSUInteger      n,max;
    
    max = [path length] / sizeof(RBK_Turn);
    turn = [path bytes];
    
    for( n = 0 ; n < max ; n++)
    {
        item = [self tokenForTurn: turn[n] ];
        result = [result stringByAppendingFormat: @"%@ ", item ];
    }
    
    clean = [self cleanTextInput: result];
    
    return clean.turns;        
}
@end
