//
//  SolverDefs.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/15/21.
//

#ifndef SolverDefs_h
#define SolverDefs_h
#import "RBK_Model_Defs.h"

#define Q_TURN_METRIC

#ifdef Q_TURN_METRIC

#define CMS_TURN_MAX 12
#define CMS_GENERATORS  {R1,R3,U1,U3,F1,F3,L1,L3,D1,D3,B1,B3,CMS_TURN_MAX}


#define CMS_CUBIES_N    8
#define CMS_EDGE_N      4
#define CMS_CORNER_N    4
#define CMS_EDGE_MAX    ( 24 * 22 * 20 * 18 )
#define CMS_CORNER_MAX  ( 24 * 21 * 18 * 15 )
#define CMS_INDEX_MAX   ( CMS_EDGE_MAX * CMS_CORNER_MAX )

#define CMS_CUBIES      { UF, UR, UB, UL, UFR, URB, UBL, ULF }

#define CMS_REDUCE_GROUP    @"C4vy"
#define CMS_SYMMETRIES      8

#define CMS_PRUNE_GROUP     @"S6xyz"


typedef struct CMS_CLASS_INFO
{
    unsigned    size, stab;
}CMS_CLASS_INFO;

typedef struct CMS_EDGE_MOVE
{
    uint32      faceMove[RBK_TURN_MAX],
                symMove[CMS_SYMMETRIES];
}CMS_EDGE_MOVE;

typedef struct CMS_CORNER_MOVE
{
    uint32      repElement,
                faceTurn[RBK_TURN_MAX];
    uint8       sym[RBK_TURN_MAX],
                stabilizer;
}CMS_CORNER_MOVE;

#define CMS_SOLUTION        1

#endif



#endif /* SolverDefs_h */
