//
//  CubieModelSolver.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/14/21.
//

#import "CubieModel.h"
#import "GroupModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CubieModelSolver : CubieModel <GroupModel>

@end

NS_ASSUME_NONNULL_END
