//
//  CubieModelSolver.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/14/21.
//

#import "CubieModelSolver.h"
#import "SolverDefs.h"
#import "PathIterator.h"




@implementation CubieModelSolver
{
    NSLock              *lockInitTables;
    NSLock              *solverLock;
    NSLock              *progressLock;
    NSLock              *solutionLock;
    NSArray             *CMS_generators;
    PathIterator        *theIterator;
    
    unsigned            maxPruneDepth,
                        cornerTableSize,
                        reduceGroup[48],
                        pruneSymmetries,
                        pruneGroup[48];

    OSG_SYMTAG          goalState[20];
    
    NSMutableArray      *stabilizers,
                        *problemStates;
    NSData              *cornerMoveTable,
                        *edgeMoveTable,
                        *depthTable;
    
    const uint8         (*prune)[CMS_EDGE_MAX / 2];
    CMS_CORNER_MOVE     *cornerMove;
    CMS_EDGE_MOVE       *edgeMove;
    
    RBK_Cubie           idaCubies[CMS_CUBIES_N];
    
    dispatch_queue_t    myDispatchQueue;
    
    NSData              *problemState,
                        *solution;
    NSArray             *turnSet;
    RBK_Turn            turns[12];
    NSUInteger          turnsMax;
    
    
    BOOL                tablesAreValid,
                        reportSolutions;
}

- (void)dealloc
{
    [CMS_generators release];
    [theIterator release];
    [lockInitTables release];
    [solverLock release];
    [progressLock release];
    [turnSet release];
    [problemState release];
    [solutionLock release];
    dispatch_release( myDispatchQueue);
    
    [super dealloc];
}

-(instancetype)init
{
    self = [super init];
    
    if(self != nil)
    {
        NSArray         *group;
        int             n;
        RBK_Cubie       _idaCubies[CMS_CUBIES_N] = CMS_CUBIES;
        
        lockInitTables = [[NSLock alloc] init];
        solverLock = [[NSLock alloc] init];
        progressLock = [[NSLock alloc] init];
        
        
        myDispatchQueue = dispatch_queue_create( "IDA SEARCH QUEUE" ,  DISPATCH_QUEUE_CONCURRENT);
        
        dispatch_retain( myDispatchQueue);
        
        CMS_generators = [[NSArray alloc] initWithArray: [self generators] ];
        
        
        n = 0;
        stabilizers = [[NSMutableArray alloc] initWithObjects: [NSData dataWithBytes: &n length: sizeof( unsigned) ], nil];
        for( n = 0 ; n < CMS_CUBIES_N ; n++ )
            idaCubies[n] = _idaCubies[n];
        
        group = [OhGroup subgroupNamed: CMS_REDUCE_GROUP];
        for( n = 0 ; n < CMS_SYMMETRIES ; n++ )
            reduceGroup[n] = [[group objectAtIndex: n] intValue];
        
        group = [OhGroup subgroupNamed: CMS_PRUNE_GROUP];
        pruneSymmetries = (unsigned)[group count];
        for( n = 0 ; n < pruneSymmetries ; n++ )
            pruneGroup[n] = [[group objectAtIndex: n] intValue];
        
        tablesAreValid = NO;
        [self loadTables];
    }
    
    return self;
}

// Calculate and record the actions of the generators on the configurations
// of the Up face corner cubies.  This table is reduced by conjugation
// with the C4v symmetry group.  This reduces the size of this table
// and the pruning table nearly eight fold.  What is listed is the represetative
// element of the symmetry equvalence class to which a turn takes the representative element of
// a second class along with the symmetry conjugator required to take the actual
// product to the representative element of its class.  Confused yet?

-(void)initCornerTable
{
    RBK_Cubie           cubie,
                        cubicle;
    uint32              turn,
                        count,
                        group,
                        index,
                        classIndex;
    CMS_CORNER_MOVE     *moves;
    int                 i,
                        symTag;
    CMS_CLASS_INFO      info;
    NSMutableData       *moveData;
    OSG_SYMTAG          state[20], product[20], reduced[20];
    const OSG_SYMTAG    *op;
    
    
    
    count = CMS_CORNER_MAX / ( CMS_SYMMETRIES - 1 );
    moveData = [NSMutableData dataWithLength: sizeof( CMS_CORNER_MOVE [count] ) ];
    
    cornerMoveTable = [moveData retain];
    moves = (void *)[moveData mutableBytes];
    
    [[self identityState] getBytes: state length: sizeof(OSG_SYMTAG [20])];
    [[self identityState] getBytes: product length: sizeof(OSG_SYMTAG [20])];
    [[self identityState] getBytes: reduced length: sizeof(OSG_SYMTAG [20])];
    
    group = count = 0;
    // Count the equivalence classes
    for( index = 0 ; index < CMS_CORNER_MAX ; index++ )
    {
        
        [self getOpRep: state forCornerIndex: index ];
        
        // record the representative element for the equivalence classes
        // The indexing scheme and rep. element selection is cleverly designed
        // such that the lowest indexed class member is the representative
        // element.  Thus this routine lists the representative elements
        // in ascending numerical order
        
        info = [self sizeOfEqClassForStateRep: state];
        if( info.size )                                    // 0 is returned if state is not the class rep
        {
            moves[count].repElement = index;
            moves[count++].stabilizer = info.stab;
            group += info.size;
        }
        
    }
    
    cornerTableSize = count;
    [moveData setLength: sizeof( CMS_CORNER_MOVE [count] ) ];
    cornerMove = (void *)[moveData bytes];
    
    // apply the face turns to the representative elements
    
    for( index = 0 ; index < cornerTableSize ; index++ )
    {
        
        [self getOpRep: state forCornerIndex: moves[index].repElement ];

        
        for( turn = 0 ; turn < [CMS_generators count] ; turn++ )
        {
            op = [[CMS_generators objectAtIndex: turn] bytes];
            for( i = CMS_EDGE_N ; i < CMS_CUBIES_N ; i++ )
            {
                cubie = idaCubies[ i];
                cubicle = [self positionOfCubie: cubie inState: state[cubie]];
                product[cubie] = [OhGroup productOfActionTag: op[ cubicle ]
                                                    stateTag: state[cubie] ];
            }
            
            symTag = [self getReducedOpRep: reduced ofRep: product];
            classIndex = (unsigned)[self cornerIndexForOpRep: reduced];
            classIndex = (unsigned)[self classIndexForIndex: classIndex];
            
            // record the product and the associated transform
            moves[index].faceTurn[turn] = classIndex;
            moves[index].sym[turn] = symTag;
        }
    }
}

// Calculate the actions of the generators on all the Up face edge cubie
// configurations

-(void)initEdgeTable
{
    NSMutableData           *table;
    CMS_EDGE_MOVE           *moves;
    uint32                  index, op, prod;
    OSG_SYMTAG              state[20],product[20];
    
    table = [NSMutableData dataWithLength: sizeof(CMS_EDGE_MOVE [CMS_EDGE_MAX]) ];
    [edgeMoveTable release];
    edgeMoveTable = [table retain];
    moves = [table mutableBytes];
    edgeMove = (void *)moves;
    
    [[self identityState] getBytes: state length: sizeof(OSG_SYMTAG [20]) ];
    [[self identityState] getBytes: product length: sizeof(OSG_SYMTAG [20]) ];
    
    for( index = 0 ; index < CMS_EDGE_MAX ; index++ )
    {
        [self getOpRep: state forEdgeIndex: index];
        
        for( op = 0 ; op < [CMS_generators count] ; op++ )
        {
            [self getSubProductRep: product
                     ofOperatorRep: [[CMS_generators objectAtIndex: op ] bytes]
                       andStateRep: state];
            
            prod = (unsigned)[self edgeIndexForOpRep: product];
            moves[index].faceMove[op] = prod;
        }
        
        for( op = 0 ; op < CMS_SYMMETRIES ; op++ )
        {
            [self getSubConjugateRep: product
                          ofStateRep: state
                            bySymTag: reduceGroup[op] ];
            
            prod = (unsigned)[self edgeIndexForOpRep: product];
            moves[index].symMove[op] = prod;
        }
    }
}

// Calculate and record the depth of the cosets of the fixed Up
// face group.  ie how many turns is required to take a member
// of a coset to the parent group

-(void)initPruneTable
{
    NSNumberFormatter   *formatter;
    NSNumber            *number;
    NSString            *numStr;
    NSMutableString     *item;
    NSMutableData       *table;
    uint8               (*depths)[CMS_EDGE_MAX / 2];
    uint32              edgeIndex, cornerIndex,
                        e, c,
                        eCorner, eEdge;
    uint64              count, total;
    NSData              *stab;
    const unsigned      *sym;
    BOOL                done;
    unsigned            depth,
                        turn,
                        n, m;
    
    formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle: NSNumberFormatterDecimalStyle];
    [formatter setPaddingCharacter: @" "];
    [formatter setFormatWidth: 14];                 // 10,000,000,000
    
    table = [NSMutableData dataWithLength: sizeof(uint8 [cornerTableSize][CMS_EDGE_MAX / 2 ] )];
    depthTable = [table retain];
    depths = [table mutableBytes];
    prune = (void *)depths;
    
    for( cornerIndex = 0 ; cornerIndex < cornerTableSize ; cornerIndex++ )
        for( edgeIndex = 0 ; edgeIndex < CMS_EDGE_MAX / 2 ; edgeIndex++ )
            depths[cornerIndex][edgeIndex] = 0xff;
    
    eEdge = (unsigned)[self edgeIndexForOpRep: [[self identityState] bytes]];
    eCorner = (unsigned)[self cornerIndexForOpRep: [[self identityState] bytes]];
    eCorner = [self classIndexForIndex: eCorner];
    
    [self setOpDepth: 0 forCornerIndex: eCorner edgeIndex: eEdge table: depths];
    depth = 0;
    total = 0;
    do
    {
        [self reportProgress: 0
                       label: [NSString stringWithFormat: @"Depth %d",depth]];
        
        count = 0;
        done = YES;
        for( cornerIndex = 0 ; cornerIndex < cornerTableSize ; cornerIndex++ )
        {
            [self reportProgress: 90.0 * cornerIndex / cornerTableSize
                           label: [NSString stringWithFormat: @"Depth %d",depth] ];
            
            for( edgeIndex = 0 ; (edgeIndex < CMS_EDGE_MAX) && ![self Abort] ; edgeIndex++ )
            {
                if( [self depthOfOpCornerIndex: cornerIndex edgeIndex: edgeIndex] == depth )
                {
                    count++;
                    for( turn = 0 ; turn < [CMS_generators count] ; turn++ )
                    {
                        c = cornerMove[cornerIndex].faceTurn[turn];
                        n = cornerMove[cornerIndex].sym[turn];
                        
                        e = edgeMove[edgeIndex].faceMove[turn];
                        e = edgeMove[e].symMove[ n ];
                        
                        if( [self depthOfOpCornerIndex: c edgeIndex: e ] == 0xf )
                        {
                            done = NO;
                            [self setOpDepth: depth + 1 forCornerIndex: c edgeIndex: e table: depths];
                            
                            if( (m = cornerMove[c].stabilizer) )
                            {
                                stab = [stabilizers objectAtIndex: m ];
                                sym = [stab bytes];
                                
                                m = (unsigned)[stab length] / sizeof( unsigned );
                                for( n = 1 ; n < m ; n++ )
                                    [self setOpDepth: depth + 1
                                      forCornerIndex: c
                                           edgeIndex: edgeMove[e].symMove[ sym[n] ]
                                               table: depths];
                                
                            }
                        }
                    }
                }
            }
        }
        
        number = [NSNumber numberWithUnsignedInteger: count];
        numStr = [formatter stringFromNumber: number];
        item = [NSMutableString stringWithFormat:
                @"\nDepth: %2d count:              ",depth ];
        
        [item replaceCharactersInRange: NSMakeRange( [item length]-[numStr length], [numStr length])
                            withString: numStr];
        [self report: item ];
        
        total += count;
        depth++;
        
    }while( !done && ![self Abort] );
    
    [self reportProgress: 0.0
                   label: @" "];
    
    if( [self Abort] )
    {
        [depthTable release];
        depthTable = nil;
    }
    
    number = [NSNumber numberWithUnsignedInteger: total];
    item = [NSMutableString stringWithFormat: @"\nTotal: %@", [formatter stringFromNumber: number] ];
    [self report: item];
    
    maxPruneDepth = depth - 1;
//    [self reportProgress: 0.0];
    
    [formatter release];
}

-(void)initTables
{
    [lockInitTables lock];
    if( tablesAreValid )
    {
        [lockInitTables unlock];
        return;
    }
    
    [self report: @"\n\nInitializing the Pruning Table"];
    [self report: @"\n\nThe pruning table takes up 1.6 gBytes and will"];
    [self report: @"\nrequire as much as 30 min to complete.  It will"];
    [self report: @"\nbe saved to the user's home directory and be "];
    [self report: @"\nloaded from disk subsequently.  One may click "];
    [self report: @"\nthe Abort button to halt this process.\n\n"];
    
    [self report: @"\nInitializing the move tables"];
    
    [self initCornerTable];
    if( [self Abort] == TRUE )
    {
        [lockInitTables unlock];
        return;
    }
    
    [self initEdgeTable ];
    if( [self Abort] == TRUE )
    {
        [lockInitTables unlock];
        return;
    }
    
    [self report: @"\nMove tables complete\nInitializing the coset depth table"];
    
    [self initPruneTable];
    if( [self Abort] == TRUE )
    {
        [lockInitTables unlock];
        return;
    }

    [self saveTables];

    [self report: @"\nPruning table complete"];

    tablesAreValid = YES;
    
    [lockInitTables unlock];
}

// Look up the class index for the corner index argument.
// This method will hang if index is not the representative element
// of its symmetry equivalence class

-(uint32)classIndexForIndex: (uint32)index
{
    uint32        top, middle, bottom;
    
    bottom = 0;
    top = cornerTableSize;
    middle = ( top + bottom ) / 2;
    while( index != cornerMove[middle].repElement )
    {
        if( index < cornerMove[middle].repElement )
            top = middle;
        else
            bottom = middle;
        
        middle = ( top + bottom ) / 2;
    }
    
    return middle;
}

// map the configuration of the Up face corners contiguously
// onto the integers

-(uint64)cornerIndexForOpRep: (const OSG_SYMTAG *)state
{
    RBK_Cubie   *cubie;
    uint64      index = 0;
    int         i,n,m,
                pos[12],
                val[12];
    
    
    cubie = idaCubies + CMS_EDGE_N;
    
    for( n = 0 ; n < CMS_CORNER_N ; n++ )
        val[n] = state[ cubie[n] ];
    
    for( n = 0 ; n < (CMS_CORNER_N - 1) ; n++ )
        pos[n] = [self positionOfCubie: cubie[n] inState: val[n]];

    // convert the cubie states to an index to allowed states
    
    for( i = 1 ; i < CMS_CORNER_N ; i++ )
        for( n = 0 ; n <= state[ cubie[i] ] ; n++ )
            for( m = 0 ; m < i ; m++ )
                if( [self positionOfCubie: cubie[i] inState: n ] == pos[m] ) //skip occupied positions
                    val[i]--;
    
    //pack the radix values for the cubies into an integer
    
    for( n = 24 , i = 0 ; i < CMS_CORNER_N ; i++ , n -= 3 )
        index = n * index + val[i];
    
    return index;
    
}

// Accessor method for the prune table

-(uint8)depthOfOpCornerIndex: (uint32)corner edgeIndex: (uint32)edge
{
    if( edge & 1 )
        return prune[corner][edge/2] / 16;
    else
        return prune[corner][edge/2] % 16;
}


// map the configuration of the Up face edges contiguously
// onto the integers

-(uint64)edgeIndexForOpRep: (const OSG_SYMTAG *)state
{
    RBK_Cubie       *cubie;
    uint64          index = 0;
    int             i,n,m,
                    pos[12],
                    val[12];
    
    cubie = idaCubies;
    
    for( n = 0 ; n < CMS_EDGE_N ; n++ )
        val[n] = state[ cubie[n] ];
    
    for( n = 0 ; n < (CMS_EDGE_N - 1) ; n++ )
        pos[n] = [self positionOfCubie: cubie[n] inState: val[n] ];
    
    // convert the cubie states to an index to allowed states
    
    for( i = 1 ; i < CMS_EDGE_N ; i++ )
        for( n = 0 ; n <= state[ cubie[i] ] ; n++ )
            for( m = 0 ; m < i ; m++ )
                if( [self positionOfCubie: cubie[i] inState: n ] == pos[m] ) //skip occupied positions
                    val[i]--;
    
    //pack the radix values for the cubies into an integer
    
    for( n = 24 , i = 0 ; i < CMS_EDGE_N ; i++ , n -= 2 )
        index = n * index + val[i];
    
    return index;
}

- (NSArray *)generators
{
    RBK_Turn        turns[] = CMS_GENERATORS;
    NSMutableArray  *gen;
    NSUInteger      n;
    
    gen = [NSMutableArray array];
    n = 0;
    while(turns[n] != CMS_TURN_MAX )
        [gen addObject: [self stateForTurn: turns[n++]]];
    
    return gen;
}

// Set the state of the Up face corner cubies as encoded in the index

-(void)getOpRep: (OSG_SYMTAG *)state forCornerIndex: (uint64)index
{
    RBK_Cubie    *corners = idaCubies + CMS_EDGE_N;
    int            i,j,n,m,
    pos[12];
    
    for( n = 27 - 3 * CMS_CORNER_N , i = CMS_CORNER_N - 1 ; i >= 0 ; i-- , n += 3 )
    {
        state[ corners[i] ] = index % n;
        index /= n;
    }
    
    // convert the cubie's state index into a state
    
    for( i = 0 ; i < CMS_CORNER_N ; i++ )
    {
        m = corners[i];
        for( n = 0 ; n <= state[m] ; n++ )
            for( j = 0 ; j < i ; j++ )
                if( pos[j] == [self positionOfCubie: m inState: n] )
                    state[m]++;
        
        pos[i] = [self positionOfCubie: m inState: state[m] ];
    }
    
}

// set the states of the Up face edge cubies to that encoded in index

-(void)getOpRep: (OSG_SYMTAG *)state forEdgeIndex: (uint64)index
{
    RBK_Cubie       *edges = idaCubies;
    int             i,j,n,m,
                    pos[12];
    
    // unpack the edge indexes
    for( n = 26 - 2 * CMS_EDGE_N , i = CMS_EDGE_N - 1 ; i >= 0 ; i-- , n += 2 )
    {
        state[ edges[i] ] = index % n;
        index /= n;
    }
    
    // convert the cubies' state indexes into a state
    
    for( i = 0 ; i < CMS_EDGE_N ; i++ )
    {
        m = edges[i];
        for( n = 0 ; n <= state[m] ; n++ )
        {
            for( j = 0 ; j < i ; j++ )
                if( pos[j] == [self positionOfCubie: m inState: n ] )
                    state[m]++;
        }
        
        pos[i] = [self positionOfCubie: m inState: state[m] ];
    }
    
}

// The method returns the index in reduce group for the symTag necessary to transform state into reduced

-(unsigned)getReducedOpRep: (OSG_SYMTAG *)reduced ofRep: (const OSG_SYMTAG *)state
{
    RBK_Cubie           cubie, cubicle;
    unsigned            n,
                        symmetries,
                        conj,
                        best,
                        slot,
                        symTag,
                        invTag,
                        symTags[2][96],
                        count1,
                        count2,
                        op,
                        pdt;
    
    symmetries = CMS_SYMMETRIES;
    
    for( n = 0 ; n < symmetries ; n++ )
        symTags[0][n] = reduceGroup[n];
    
    slot = CMS_EDGE_N;
    count1 = symmetries;
    op = 0;
    pdt = 1;
    
    // This routine is identical to that of the preceding method with minor changes.
    // On exit one has a list of symmetry elements which will transform the argument
    // to the representative element.  The topmost transform is then applied to the
    // argument and the result returned in the buffer pointed to by the first argument.
    do
    {
        cubie = idaCubies[slot];
        count2 = 0;
        best = UINT_MAX;
        
        for( n = 0 ; n < count1 ; n++ )
        {
            symTag = symTags[op][n];
            invTag = [OhGroup inverseOfTag: symTag];
            cubicle = [self positionOfCubie: cubie inState: symTag ];
            
            conj = [OhGroup productOfActionTag: state[ cubicle ]
                                           stateTag: symTag];
            
            conj = [OhGroup productOfActionTag: invTag
                                           stateTag: conj ];
            
            if( conj < best )
            {
                count2 = 1;
                best = conj;
                symTags[pdt][0] = symTag;
            }
            else
                if( conj == best )
                    symTags[pdt][count2++] = symTag;
        }
        slot++;
        pdt ^= 1;
        op ^= 1;
        count1 = count2;
        
    }while( (slot < CMS_CUBIES_N) && (count2 > 1) ); //Stop when all slots are processed or when only one conjugator remains
    
    symTag = symTags[op][0];
    
    [self getSubConjugateRep: reduced
                  ofStateRep: state
                    bySymTag: symTag ];
    
    n = 0;
    while( reduceGroup[n] != symTag )
        n++;
    
    
    return n;
}

-(void)getSubConjugateRep: (OSG_SYMTAG *)conjugate
               ofStateRep: (const OSG_SYMTAG *)state
                 bySymTag: (unsigned)symTag
{
    int             n;
    RBK_Cubie       cubie;
    OSG_SYMTAG      p;
    unsigned        inv;
    
    inv = [OhGroup inverseOfTag: symTag];
    
    
    for( n = 0 ; n < CMS_CUBIES_N ; n++ )
    {
        cubie = idaCubies[n];
        
        p = [OhGroup productOfActionTag: state[ [self positionOfCubie: cubie inState: symTag ] ]
                                    stateTag: symTag];
        
        conjugate[cubie] = [OhGroup productOfActionTag: inv
                                                   stateTag: p ];
    }
}


-(void)getSubProductRep: (OSG_SYMTAG *)product
          ofOperatorRep: (const OSG_SYMTAG *)operator
            andStateRep: (const OSG_SYMTAG *)state
{
    int             n;
    RBK_Cubie       cubie;
    
    for( n = 0 ; n < CMS_CUBIES_N ; n++ )
    {
        cubie = idaCubies[n];
        product[cubie] = [OhGroup productOfActionTag: operator[ [self positionOfCubie: cubie inState: state[cubie] ] ]
                                            stateTag: state[cubie] ];
    }
}


-(NSString *)pathToDatabase
{
    NSString    *path, *fileName;
    
    path = [NSHomeDirectory() stringByAppendingPathComponent: @"Library/Application Support"];

#ifdef Q_TURN_METRIC
    fileName = @"CMS_TablesQTM";
#else
    filename = @"CMS_TablesFTM";
#endif
    
    
    return [path stringByAppendingPathComponent: fileName];
    
}



-(NSData *)pathForState:(NSData *)state
{
    reportSolutions = NO;
    
    [self setSolution: nil ];
    
    [self pathForCubeState: state];
    
    while( [self getSolution] == nil)
        [NSThread sleepForTimeInterval: 0.1 ];
    
    return [self getSolution];
}

-(void)loadTables
{
    [NSThread detachNewThreadSelector: @selector(loadTables:)
                             toTarget: self
                           withObject: nil];
}
-(void)loadTables: (id)none
{
    NSData          *fileData;
    NSString        *path;
    NSDictionary    *archive;
    
    @autoreleasepool
    {
        [lockInitTables lock];
        
        path = [self pathToDatabase ];
        
        if( [[NSFileManager defaultManager] fileExistsAtPath: path ])
        {
            fileData = [NSData dataWithContentsOfFile: path];
            
            if( fileData == nil )
                tablesAreValid = NO;
            else
            {
                archive = [NSKeyedUnarchiver unarchivedDictionaryWithKeysOfClass: [NSString class]
                                                                  objectsOfClass: [NSData class]
                                                                        fromData: fileData
                                                                           error: nil];
                
                
                if( archive == nil )
                    tablesAreValid = NO;
                else
                {
                    cornerMoveTable = [archive objectForKey: @"Corner Move Table"];
                    [cornerMoveTable retain];
                    cornerMove = (CMS_CORNER_MOVE *)[cornerMoveTable bytes];
                    
                    cornerTableSize = (int)[cornerMoveTable length] / sizeof(CMS_CORNER_MOVE);
                    
                    edgeMoveTable = [archive objectForKey: @"Edge Move Table"];
                    [edgeMoveTable retain];
                    edgeMove = (CMS_EDGE_MOVE *)[edgeMoveTable bytes];
                    
                    depthTable = [archive objectForKey: @"Depth Table"];
                    [depthTable retain];
                    prune = [depthTable bytes];
                    
                    tablesAreValid = YES;
                }
            }
        }
        
        theIterator = [[PathIterator alloc] initWithGroupModel: self];
        [lockInitTables unlock];
    }
}

-(void)saveTables
{
    NSDictionary    *tables;
    NSData          *archive;
    NSString        *path;
    
    path = [self pathToDatabase];
    
    tables = [NSDictionary dictionaryWithObjectsAndKeys:
              cornerMoveTable,      @"Corner Move Table",
              edgeMoveTable,        @"Edge Move Table",
              depthTable,           @"Depth Table",
              nil];
    
    archive = [NSKeyedArchiver archivedDataWithRootObject: tables
                                    requiringSecureCoding: YES
                                                    error: nil];
    [archive writeToFile: path
              atomically: YES];
    
    [self report: [NSString stringWithFormat: @"\nSolver tables saved to: \n  %@", path ]];
}

// Accessor method for the pruning table

-(void)setOpDepth: (uint8)depth
   forCornerIndex: (uint32)corner
        edgeIndex: (uint32)edge
            table: (uint8 (*)[CMS_EDGE_MAX / 2])table
{
    if(depth > 15)
        return;
    
    if( edge & 1 )
        table[corner][edge / 2] = (table[corner][edge/2] & 0xf) + 16 * depth;
    else
        table[corner][edge / 2] = (table[corner][edge/2] & 0xf0) + depth;
}

// The method returns the size of the equivalence clase of the argument
// or zero if the argument is not the representative element of its
// equivalence class.

-(CMS_CLASS_INFO)sizeOfEqClassForStateRep: (const OSG_SYMTAG *)state
{
    CMS_CLASS_INFO      info;
    NSData              *stab;
    RBK_Cubie           cubie, cubicle;
    unsigned            n,
                        symmetries,
                        conj,
                        best,
                        slot,
                        symTag,
                        invTag,
                        symTags[2][96],
                        count1,
                        count2,
                        op,
                        pdt;
    
    symmetries = CMS_SYMMETRIES;
    
    for( n = 0 ; n < symmetries ; n++ )
        symTags[0][n] = reduceGroup[n];
    
    
    slot = CMS_EDGE_N;
    count1 = symmetries;
    op = 0;
    pdt = 1;
    
    // perform a cubie by cubie conjugation of the argument with the list symmetry elements.  If at any point
    // a conjugation transforms the state of the cubie to one numerically less than its starting state
    // the argument is not the rep. element of its equivalence class.  If at any point a conjugation
    // changes the state of the cubie in question, that symmetry element can be eliminated from the
    // list--it is not a symmetry of the argument.  For representative elements, on exit one has a
    // list of symmetries which convert the argument into itself.  The size of the equivalence class
    // is equal to the total number of symmetries divided by the number of symmetries shown by the
    // argument.
    
    do
    {
        cubie = idaCubies[slot];
        count2 = 0;
        best = UINT_MAX;
        
        for( n = 0 ; n < count1 ; n++ )
        {
            symTag =  symTags[op][n];
            
            invTag = [OhGroup inverseOfTag: symTag];
            cubicle = [self positionOfCubie: cubie inState: symTag];
            
            conj = [OhGroup productOfActionTag: state[ cubicle ]
                                           stateTag: symTag];
            
            conj = [OhGroup productOfActionTag: invTag
                                           stateTag: conj ];
            
            if( conj < best )
            {
                count2 = 1;
                best = conj;
                symTags[pdt][0] = symTag;
            }
            else
                if( conj == best )
                    symTags[pdt][count2++] = symTag;
        }
        slot++;
        pdt ^= 1;
        op ^= 1;
        count1 = count2;
        
    }while( (slot < CMS_CUBIES_N) && (count2 > 1) && (symTags[op][0] == 0) ); //Stop when all slots are processed or when only one conjugator remains
    
    if( symTags[op][0] )
        info.size = 0;
    else
    {
        for( n = 0 ; n < count2 ; n++ )
        {
            slot = 0;
            while( reduceGroup[slot] != symTags[op][n] )
                slot++;
            symTags[op][n] = slot;
        }
        info.size = symmetries / count2;
        stab = [[NSData alloc] initWithBytes: symTags[op] length: sizeof(unsigned [count2] )];
        if( ![stabilizers containsObject: stab] )
            [stabilizers addObject: stab];
        info.stab = (unsigned)[stabilizers indexOfObject: stab];
        [stab release];
    }
    
    return info;
}

#pragma mark    **CubeEngineProtocol Methods**

- (void)execute:(NSDictionary *)parameters
{
    NSString        *prompt,
                    *input;
    BOOL            caught = NO;
    
    input = [parameters objectForKey: CEP_PARAMETER];
    prompt = [parameters objectForKey: CEP_FUNCTION];
    
    if( [self Abort] )
        [self setAbort: NO];
    
    
    if( [prompt isEqualToString: @"Solution for States"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        reportSolutions = YES;
        [NSThread detachNewThreadSelector: @selector(solveStates:)
                                 toTarget: self
                               withObject: input];
        caught = YES;
    }
    
    if( [prompt isEqualToString: @"Generator for States"] )
    {
        [self report: @"\n\n"];
        [self report: prompt];
        reportSolutions = NO;
        [NSThread detachNewThreadSelector: @selector(solveStates:)
                                 toTarget: self
                               withObject: input];
        caught = YES;
    }
    
    if( !caught )
        [super execute: parameters];
    
}

- (NSArray *)functionArray
{
    NSArray     *myFunctions;
    
    myFunctions = [NSArray arrayWithObjects:
                   @"Solution for States",
                   @"Generator for States",
                   nil];
    
    return [myFunctions arrayByAddingObjectsFromArray: [super functionArray] ];
}


#pragma mark **** UI Functions ****


//  Solve States
//
//  Solve a list of states, each on a separate line.  The input may be as
//  Standard Configuration Strings, a turn sequence or Random.  Random solves
//  a randomly generated cube state.
//

-(void)solveStates: (NSString *)input
{
    NSArray         *lines;
    NSString        *line,
                    *text,
                    *config;
    RBK_CLEAN_TEXT  clean;
    NSInteger       ftm,qtm;
    NSData          *state;
    NSDate          *startTime;
    
    @autoreleasepool
    {
        if( !tablesAreValid )
        {
            [self initTables];
            [self reportDone];
            return;
        }
        
        lines = [input componentsSeparatedByString: @"\n"];
        
        for( line in lines)
        {
            if( [self Abort] )
                break;
            
            state = nil;
            clean = [self cleanTextInput: line ];
            
            text = clean.config;
            if( [text isEqualToString: RBK_IDENTITY ])
                text = @"";
            
            if( [text length] > 0 )
                state = [self stateForConfiguration: text];
            else
            {
                text = clean.turns;
                if( [text length] > 0)
                    state = [self stateForTurnString: text];
            }
            if( state != nil )
            {
                config = [self configurationForState: state];
                [self report: [NSString stringWithFormat: @"\n\nInput: %@\nParsed as: %@\nConfiguration: %@", line, text, config ] ];
                [self setSolution: nil];
                startTime = [NSDate date];
                
               [self pathForCubeState: state];
                
                do
                {
                    [NSThread sleepForTimeInterval: 0.01];
                }while(( [self getSolution] == nil) && ![self Abort]);
                
                if( [self getSolution] != nil )
                {
                    qtm = [[self getSolution] length]/ sizeof(RBK_Turn);
                    clean = [self cleanTextInput: [self turnStringForPath: [self getSolution] ] ];
                    text = clean.turns;
                    ftm = [[text componentsSeparatedByString: @" "] count];
                    
                    if( reportSolutions )
                        [self report: [NSString stringWithFormat: @"\nSolution: %@  %ldq  %ldf", text, qtm , ftm ]];
                    else
                        [self report: [NSString stringWithFormat: @"\nGenerator: %@  %ldq  %ldf", text, qtm , ftm ]];

                    text = [self stringForTimeInterval: -[startTime timeIntervalSinceNow]];
                    [self report: [NSString stringWithFormat: @"\ntime: %@", text ] ];
                    [NSThread sleepForTimeInterval: 0.01];
                }
            }
            
        }
    }
    [self reportProgress: 0.0 label: @"  " ];
    [self reportDone];
}

#define DO_TEST -1

-(void)developer: (NSString *)input
{
    @autoreleasepool
    {
        switch( DO_TEST )
        {
            case 1:
                [self profileSolver: input];
                break;
                
            case 2:
                [self countIteratorNodes];
                break;
                
            default:
                [super developer: input];
                break;
        }
        
        
        [self reportDone];
    }
}

// Solve a set of random states, gather and report statistics
//
// Options:
//   Count: ####        The number of trials, defaults to 100
//
// Expected distribution (Rokicki 3,000,000 trials)
// depth    dist

// 14          5     0.00%
// 15         34     0.00%
// 16        323     0.01%
// 17       2798     0.09%
// 18      25377     0.85%
// 19     206335     6.88%
// 20     993235    33.11%
// 21    1289020    42.97%
// 22     481228    16.04%
// 23       1645     0.05%
//  N    3000000
// av     20.663

- (void)profileSolver: (NSString *) input
{
    typedef struct record
    {
        NSUInteger      depth;
        NSTimeInterval  time;
    }record;
    
    NSUInteger      n, t, max, p, mn, mx,
                    trials = 100;
    NSDate          *start;
    NSTimeInterval  dTime;
    double          aveT, aveD , percent;
    NSMutableData   *records;
    record          item;
    const record    *items;
    NSData          *state;
    NSRange         hit;
    BOOL            fudge;
    
    @autoreleasepool
    {
        records = [NSMutableData data];
        
        hit = [input rangeOfString: @"count:" options: NSCaseInsensitiveSearch];
        
        if(hit.location != NSNotFound)
        {
            if( (hit.location + 6) < [input length] )
            {
                trials = [[input substringFromIndex: hit.location + 6] intValue];
                if( trials == 0 )
                    trials = 100;
            }
        }
        
        hit = [input rangeOfString: @"0=1" options: NSLiteralSearch];
        if( hit.location == NSNotFound)
            fudge = NO;
        else
            fudge = YES;
        
        start = [NSDate date];
        [self setAbort: NO];
        
        [self report: [NSString stringWithFormat: @"\n\nSolver Profile: %ld trials\n", trials] ];
        
        p = 0;
        for( t = 0 ; (t < trials) && ![self Abort] ; t++ )
        {
            state = [self randomState];
            if( fudge )
            {
                while( p != [self qTurnParityOfState: state] )
                {
                    state = [self randomState];

                };
                p ^= 1;
            }

            dTime = [start timeIntervalSinceNow];
            [self pathForCubeState: state];
            
            while( ([self getSolution] == nil) && ![self Abort] )
                sleep(1);
            
            item.time = dTime - [start timeIntervalSinceNow];
            
            state = [[[self getSolution] retain] autorelease];
            [self setSolution: nil ];
            
            item.depth = [state length] / sizeof(RBK_Turn);
                          
            [records appendBytes: &item length: sizeof(record) ];
            
            if( (t%10) == 0)
                [self report: [NSString stringWithFormat: @"\n%6ld  ", t]];
                          
            [self report: [NSString stringWithFormat: @"%3ld", item.depth ] ];
        }
        
        max = [records length] / sizeof(record);
        items = [records bytes];
        
        aveD = aveT = 0.0;
        mn = 100;
        mx = 0;
        for(t = 0 ; t < max ; t++ )
        {
            if( mn > items[t].depth)
                mn = items[t].depth;
            if( mx < items[t].depth)
                mx = items[t].depth;
                
            aveD += (items[t].depth - aveD) / (t + 1.0);
            aveT += (items[t].time - aveT) / (t + 1.0);
        }
        
        [self report: [NSString stringWithFormat: @"\n\nAverage Time: %0.3f", aveT ]];
        [self report: [NSString stringWithFormat: @"\nAverage Depth: %0.3f\n", aveD ]];
        
        for( p = mn ; p <= mx ; p++)
        {
            t = 0;
            for( n = 0 ; n < max ; n++ )
            {
                if( items[n].depth == p)
                    t++;
            }
            percent = 100.0 * t / trials;
            [self report: [NSString stringWithFormat: @"\nDepth %2ld\tCount:%4ld  %0.2f%%",p,t,percent]];
        }
    }
    [self reportDone];
}

-(void)countIteratorNodes
{
    NSMutableData       *iterator;
    Path_Iterator_Move  move;
    NSInteger           loop,depth, count[20];
    BOOL                working, trim;
    float               branch;
    
    @autoreleasepool
    {
        count[0] = 1;
        for( depth = 1 ; (depth < 12) && ![self Abort] ; depth++)
        {
            iterator = [theIterator newIterator];
            move = [theIterator nextMoveForIterator: iterator
                                               trim: NO ];
            count[depth] = 0;
            loop = 0;
            working = YES;
            while( working && ![self Abort] )
            {
                if( move.depth == depth)
                {
                    trim = YES;
                    count[depth]++;
                }
                else
                    trim = NO;
                
                move = [theIterator nextMoveForIterator: iterator
                                                   trim: trim];
                
                if( loop++ == 10000)
                {
                    [self reportProgress: [theIterator progressForIterator: iterator]
                                   label: [NSString stringWithFormat: @"Depth %ld", depth] ];
                    loop = 0;
                }
                
                if(move.depth == 0 )
                    working = NO;
            }
            
            if(![self Abort])
            {
                branch = (float)count[depth] / (float)count[depth - 1];
                [self report:
                 [NSString stringWithFormat: @"\n depth: %ld  count: %12ld  Branch: %0.3f",depth,count[depth], branch]];
            }
        }
        [self reportProgress: 0.0 label: @""];
    }
}

#pragma  mark ********* IDA Cube Solver ********

-(void)pathForCubeState: (NSData *)state
{
    
    if( [state isEqualToData: [self identityState]] )
    {
        [solution release];
        [self setSolution: [NSData data] ];
        return;
    }

    if( !reportSolutions )
        state = [self inverseOfState: state];
    
    [solverLock lock];
    
    //Symmetry reduce the allowed turns
    [turnSet release];
    turnSet = [self turnSetForState: state  maxTurn: (int)[CMS_generators count ] ];
    [turnSet retain];
    
    turnsMax = (int)[turnSet count];
    
    [problemState release];
    problemState = [state retain];
    
    [self manageIDASearch: nil];
}

// This method interfaces with the solveTreeBranch
// search threads.  It keeps track of the active
// threads and the overall progress.  When a solution
// is found it sets the instance variable, solution, to
// it and shuts down the search.  When a depth is
// thoughly searched without a solution it initiates
// the search to a greater depth.
//
// returns YES if the calling thread should shut down
// or NO if it should continue


-(BOOL)manageIDASearch: (NSDictionary *)info
{
    static BOOL         solutionFound;
    static NSUInteger   targetDepth;
    static BOOL         branchDone[CMS_TURN_MAX];
    static double       progress[CMS_TURN_MAX];
    
    int             n,m;
    RBK_Turn        turn;
    NSNumber        *number;
    double          sum;
    NSString        *string;
    BOOL            done;
    NSData          *item;
    
    [progressLock lock];
    
    if( info == nil)
    {
        // Initiate the IDA search
        
        solutionFound = NO;
        targetDepth = [self qTurnParityOfState: problemState];
        
        for(n = 0 ; n < CMS_TURN_MAX ; n++ )
        {
            progress[n] = 0.0;
            branchDone[n] = YES;
        }
        
        m = 0;
        for(item in turnSet)
        {
            n = (int)[CMS_generators indexOfObject: item];
            branchDone[n] = NO;
            turns[m++] = n;
        }
        
        [self searchTreeToDepth: targetDepth];
        [progressLock unlock];
        return  YES;
    }
    
    number = [info objectForKey: @"TURN"];
    turn = [number intValue];
    
    string = [info objectForKey: @"IS_DONE"];
    if( string != nil )
        branchDone[turn] = YES;
    
    item = [info objectForKey: @"SOLUTION"];
    if( item != nil )
    {
        solutionFound = YES;
        [self setSolution: item];
    }
    
    number = [info objectForKey: @"PROGRESS"];
    if( number != nil )
    {
        progress[turn] = [number doubleValue];
        for( n = 0, sum = 0 ; n < [CMS_generators count] ; n++ )
            sum += progress[n];
        
        [self reportProgress: 90 * sum / ( turnsMax * 100 )
                       label: [NSString stringWithFormat: @"Depth %ld", targetDepth] ];
    }
    
    done = YES;
    n = 0;
    while( (n < [CMS_generators count]) && done )
        done = branchDone[n++];
    
    // Have all branches completed?
    if( done )
    {
        if( solutionFound  || [self Abort] )
        {
            //Shut Down the search
            
            [solverLock unlock];
            [progressLock unlock];
            [self reportProgress: 0.0 label: nil ];
            return YES;
        }
        else
        {
            // Initiate a search at a greater depth
            
            for(n = 0 ; n < [CMS_generators count] ; n++ )
            {
                progress[n] = 0.0;
                branchDone[n] = YES;
            }
            
            for(item in turnSet)
            {
                n = (int)[CMS_generators indexOfObject: item];
                branchDone[n] = NO;
            }
            
            targetDepth += 2;
            [progressLock unlock];
            [self searchTreeToDepth: targetDepth];
            return YES;
        }
        
    }
    else
    {
        [progressLock unlock];
        return solutionFound;
    }
}

// Multitasked search of the move tree.  All main branches searched concurrently.
// Performs an IDA search for a solution of problemState to targetDepth

- (void)searchTreeToDepth: (NSUInteger)theDepth
{
    int                 n;
    struct
    {
        NSUInteger      depth;
        RBK_Turn        turn;
    }param;
    
    param.depth = theDepth;
    
    // load up the processor cores
    
    for ( n = 0 ; n < turnsMax; n++)
    {
        param.turn = turns[n];
        
        dispatch_async( myDispatchQueue, ^( void )
        {
            NSDictionary            *info;
            NSMutableData           *iterator;
            const OSG_SYMTAG        *conjugate;
            OSG_SYMTAG              reduced[20];
            NSInteger               loopCount;
            NSData                  *state;
            RBK_Turn                firstTurn;
            unsigned                index,
                                    sym1,
                                    conjTurn,
                                    depth,
                                    target;
            Path_Iterator_Move      nextTurn;
            int                     i,m,n,delta;
            bool                    working,
                                    trim;
            struct
            {
                uint8       sym;
                uint32      cornerIndex,
                            edgeIndex;
            }stack[30][48];

            firstTurn = param.turn;
            target = (unsigned)param.depth;
            state = problemState;
            nextTurn.action = firstTurn;
            nextTurn.depth = 1;

            iterator = [theIterator iteratorForBranch: firstTurn ];

            //Encode symmetry conjugate cubie sets homologous to the cubie set used to construct the pruning table

            [[self identityState] getBytes: reduced length: sizeof(OSG_SYMTAG [20])];
            for( i = 0 ; i < pruneSymmetries ; i++ )
            {

                conjugate = [[self conjugateOfState: state bySymtag: pruneGroup[i] ] bytes];

                n = [self getReducedOpRep: reduced ofRep: conjugate];

                stack[0][i].sym = [OhGroup productOfActionTag: pruneGroup[i]
                                                     stateTag: reduceGroup[ n ] ];

                stack[0][i].cornerIndex = [self classIndexForIndex: (uint32)[self cornerIndexForOpRep: reduced]];

                stack[0][i].edgeIndex = (uint32)[self edgeIndexForOpRep: conjugate];
                stack[0][i].edgeIndex = edgeMove[ stack[0][i].edgeIndex ].symMove[n];
            }


            depth = 1;
            working = YES;
            delta = 2;

            loopCount = 0;
            // Search the tree
            while( working && ![self Abort] )
            {
                @autoreleasepool
                {

                    //compute the next node by looking up the next state in the move tables
                    i = depth - 1;
                    n = (int)nextTurn.action;

                    for( m = 0 ; m < pruneSymmetries ; m++ )                    //do for each sym conjugate
                    {

                        conjTurn = [self conjugateOfTurn: n bySymtag: stack[i][m].sym ];

                        index = stack[i][m].cornerIndex;
                        stack[depth][m].cornerIndex= cornerMove[ index ].faceTurn[ conjTurn];
                        sym1 = cornerMove[ index ].sym[ conjTurn];

                        stack[depth][m].sym = [OhGroup productOfActionTag: stack[i][m].sym
                                                                 stateTag: reduceGroup[sym1] ];

                        stack[depth][m].edgeIndex = edgeMove[ edgeMove[ stack[i][m].edgeIndex ].faceMove[ conjTurn ] ].symMove[ sym1 ];

                    }

                    trim = NO;

                    //Does the pruning table allow us to lop off this branch?

                    n = target - (int)depth;
                    for( i = 0 ; i < pruneSymmetries ; i++ )
                    {
                        if( [self depthOfOpCornerIndex: stack[depth][i].cornerIndex
                                             edgeIndex: stack[depth][i].edgeIndex ] > n )
                        {
                            trim = YES;
                            break;
                        }
                    }

                    if( n == 0 )
                    {
                        if( trim )
                        {
                            if( target == 0 )
                            {
                                target = delta;
                                trim = NO;
                            }
                        }
                        else    // Solution found
                        {
                            working = NO;
                            info = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithInt: firstTurn],                @"TURN",
                                    [theIterator currentPathForIterator: iterator],     @"SOLUTION",
                                    nil];

                            [self manageIDASearch: info];
                        }
                    }

                    nextTurn = [theIterator nextMoveForIterator: iterator trim: trim];
                    depth = nextTurn.depth;

                    if( (depth == 1) || (depth == 0) ) //The tree branch for the turn is explored to the target depth
                    {
                        working = NO;
                    }

                    if( loopCount++ == 10000 )
                    {
                        info = [NSDictionary dictionaryWithObjectsAndKeys:
                                [NSNumber numberWithInt: firstTurn],                                        @"TURN",
                                [NSNumber numberWithDouble: [theIterator progressForBranchItr: iterator]],  @"PROGRESS",
                                nil];

                        if( [self manageIDASearch: info] == YES)
                            working = NO;

                        loopCount = 1;
                    }
                }
            }

            info = [NSDictionary dictionaryWithObjectsAndKeys:
                    [NSNumber numberWithInt: firstTurn],        @"TURN",
                    @"YES",                                     @"IS_DONE",
                    nil];

            [self manageIDASearch: info];
        });
    }
}

// Thread safe accessors for the solution instance variable

-(void)setSolution: (NSData *)new
{
    [solutionLock lock];
    [new retain];
    [solution release];
    solution = new;
    [solutionLock unlock];
}

-(NSData *)getSolution
{
    NSData  *result;
    [solutionLock lock];
    result = solution;
    [solutionLock unlock];
    
    return result;
}

-(NSString *)stringForTimeInterval: (NSTimeInterval)sec
{
    int             day,hour,min;
    NSMutableString *eTime;
    
    min = sec / 60;
    sec -= (60.0 * min);
    hour = min / 60;
    day = hour / 24;
    
    hour %= 24;
    min %= 60;
    
    eTime = [NSMutableString string];
    
    if( day )
        [eTime appendFormat: @"%d:", day ];
    
    if( day || hour )
        [eTime appendFormat: @"%02d:",hour];
    
    if( day || hour || min )
        [eTime appendFormat: @"%02d:",min];
    
    [eTime appendFormat: @"%05.2f", sec];
    
    return  eTime;
}

// Symmetry reduce the turns by the symmetry
// of the state argument.  During a solution
// search only these turns need be considered
// as the first move.  The complement turns
// will give a solution at the same depth as
// their symmetry conjugates.

-(NSArray *)turnSetForState: (NSData *)state maxTurn: (int)maxTurn
{
    int                     n;
    NSArray                 *group;
    NSMutableArray          *result;
    NSString                *symElement;
    OSG_SYMTAG              symTag;
    NSData                  *turn,
                            *conj;

    group = [self symmetryGroupOfState: state];
    result = [NSMutableArray arrayWithArray: CMS_generators];
    if( [group count] <= 48 )
    {
        for( n = 0 ; n < maxTurn ; n++ )
        {
            turn = [CMS_generators objectAtIndex: n ];
            if( [result containsObject: turn] )
            {
                for( symElement in group )
                {
                    symTag = [OhGroup symtagForKey: symElement];
                    if( symTag < 24 ) //we want only rotational conjugates
                    {
                        conj = [self conjugateOfState: turn bySymtag: symTag];
                        
                        if( ![conj isEqualToData: turn] )
                            [result removeObject: conj];
                    }
                }
            }
        }
    }
    
    return result;
}

// Computes the parity of the edge cubie position permutation
// Odd parities require an odd number of qTurns to solve

-(int)qTurnParityOfState: (NSData *)state
{
    const OSG_SYMTAG    *rep;
    int                 i,n,p,perm[12];
    
    rep = [state bytes];
    
    for( i = 0 ; i < 12 ; i++)
        perm[i] = [self positionOfCubie: i inState: rep[i] ];
    
    for( p = 0 , i = 0 ; i < 11 ; i++ )
        for( n = i + 1 ; n < 12 ; n ++ )
            if( perm[i] > perm[n] )
                p ^= 1;
    return p;
}
@end
