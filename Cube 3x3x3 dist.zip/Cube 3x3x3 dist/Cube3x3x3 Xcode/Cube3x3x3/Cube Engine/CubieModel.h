//
//  CubieModel.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import "RBK_Model.h"
#import "CubeEngineProtocol.h"

typedef struct
{
    NSData          * _Nonnull proxy;
    NSUInteger      size;
    OSG_SYMTAG      conjugator;
}SymProxy;

NS_ASSUME_NONNULL_BEGIN

@interface CubieModel : RBK_Model <CubeEngineProtocol>

- (void)report: (id)comment;

- (void)reportDone;

- (void)reportProgress: (double)percent
                 label: (NSString * _Nullable)label;

-(void)developer: (NSString *)input;

-(RBK_Turn)conjugateOfTurn: (RBK_Turn)turn
                  bySymtag: (OSG_SYMTAG)symtag;

-(NSData *)conjugateOfPath: (NSData *)path
                  bySymtag: (OSG_SYMTAG)symtag;

-(NSData *)conjugateOfState: (NSData *)state
                   bySymtag: (OSG_SYMTAG)symtag;

-(NSData *)inverseOfPath:(NSData *)path;

-(RBK_Turn)inverseOfTurn: (RBK_Turn)turn;

-(NSData *)pathForState: (NSData *)state;

-(RBK_Cubie)positionOfCubie: (RBK_Cubie)cubie
                    inState: (OSG_SYMTAG)state;

-(SymProxy)proxyOfState: (NSData *)state
             symmetries: (NSString *)symGroup
                antiSym: (BOOL)useAntiSymmetry;

-(int)orientationOfCubie: (RBK_Cubie)cubie
                 inState: (OSG_SYMTAG)state;

-(NSData *)productOfPath: (NSData *)path
                andState: ( NSData  * _Nullable )state;

-(NSData *)randomState;

-(NSData *)stateForPath: (NSData *)path;

-(NSData *)stateForTurnString: (NSString *)turnString;

-(NSArray *)symmetryGroupOfState: (NSData *)state;
@end

NS_ASSUME_NONNULL_END
