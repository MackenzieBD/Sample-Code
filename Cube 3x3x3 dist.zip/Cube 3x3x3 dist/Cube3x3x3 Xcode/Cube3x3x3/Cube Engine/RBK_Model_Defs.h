//
//  RBK_Model_Defs.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
// 20

#ifndef RBK_Model_Defs_h
#define RBK_Model_Defs_h

#define RBK_IDENTITY    @"UF UR UB UL DF DR DB DL FR FL BR BL UFR URB UBL ULF DRF DFL DLB DBR"

typedef enum
{
    UF, UR, UB, UL, DF, DR, DB, DL, FR, FL, BR, BL, UFR, URB, UBL, ULF, DRF, DFL, DLB, DBR,
    RBK_CUBIE_MAX
}RBK_Cubie;

#define RBK_Cubicle RBK_Cubie

// A list of the valid tokens used in standard turn sequences
#define RBK_TOKEN_STRING    @"R R' U U' F F' L L' D D' B B' R2 U2 F2 L2 D2 B2"


// Enumerate the above tokens
typedef enum
{
    R1,R3,U1,U3,F1,F3,L1,L3,D1,D3,B1,B3,R2,U2,F2,L2,D2,B2,
    RBK_TURN_MAX
}RBK_Turn;

#define RBK_qTURN_MAX R2

#define RBK_ORIENT_NONE     0
#define RBK_ORIENT_FLIP     1
#define RBK_ORIENT_CW       1
#define RBK_ORIENT_CCW      2

typedef struct
{
    NSString    *config,
                *turns;
}RBK_CLEAN_TEXT;


#endif

