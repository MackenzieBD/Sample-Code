//
//  PathIterator.m
//
//  Created by Bruce D MacKenzie on 11/17/13.
//  Copyright (c) 2013 Bruce MacKenzie. All rights reserved.
//

#import "PathIterator.h"


// depth 0 to PI_LIMIT - 1

#define  PI_LIMIT 6

enum    enum_type {anEnum};

typedef enum enum_type enum_type;

@implementation PathIterator

-(void)dealloc
{
    [pathTable release];
    [pathTableLock  release];
    
    [super dealloc];
}

-(id)init
{
    return [self initWithGroupModel: self];
}



-(id)initWithGroupModel: (id <GroupModel> )theModel
{
    return [self initWithGroupModel: theModel
                         generators: [theModel generators]];
}



-(id)initWithGroupModel: (id <GroupModel>)theModel
             generators: (NSArray *)generators;
{
    NSMutableSet        *allStates = nil;
    NSMutableArray      *swap,
                        *current = nil,
                        *next = nil;
    NSInteger           depth;
    NSUInteger          count = 0;
    NSData              *state,
                        *newState;
    NSUInteger          action,
                        actionMax,
                        index,
                        pIndex,
                        cIndex;
    BOOL                isSibling;
    Path_Iterator_Entry *parentNode,
                        *childNode,
                        *linkNode;
    NSUInteger          key[2];
    NSMutableData       *root[PI_LIMIT];
    
    self = [super init];
    
    if( self )
    {
        // Perform a breadth first expansion and produce a linked list of
        // puzzle moves to the distinct states out to depth 6.
        actionMax = [generators count];
        
        depth = 0;
        while( depth < PI_LIMIT )
        {
            if( depth == 0 )
            {
                allStates = [NSMutableSet setWithObject: [theModel identityState] ];
                next = [NSMutableArray arrayWithObject: [theModel identityState] ];
                current = [NSMutableArray array];
                
                root[0] = [[NSMutableData alloc] initWithLength: sizeof( Path_Iterator_Entry )];
                parentNode = [root[0] mutableBytes];
                pathRoot[0] = parentNode;
                parentNode[0].hasSib = NO;
                parentNode[0].action = UINT8_MAX;
                parentNode[0].child = 0;
                count = 1;
            }
            else
            {
                parentNode = [root[depth-1] mutableBytes];
                
                root[depth] = [[NSMutableData alloc] initWithLength: actionMax * [current count] * sizeof( Path_Iterator_Entry )];
                childNode = [root[depth] mutableBytes];
                pathRoot[depth] = childNode;
                
                // Apply the generators to the states of the present depth
                
                cIndex = 0;
                for( pIndex = 0 ; pIndex < [current count] ; pIndex++ )
                {
                    @autoreleasepool
                    {
                        state = [current objectAtIndex: pIndex];
                        isSibling = NO;
                        for( action = 0 ; action < actionMax ; action++ )
                        {
                            newState = [theModel productOfAction: [generators objectAtIndex: action]
                                                        andState: state ];
                            
                            [allStates addObject: newState];
                            if( count != [allStates count] ) // NSSet filters out duplicate members
                            {
                                count++;
                                [next addObject: newState];
                                
                                childNode[cIndex].action = action;
                                childNode[cIndex].child = -1;
                                childNode[cIndex].hasSib = NO;
                                if( isSibling )
                                {
                                    childNode[cIndex-1].hasSib = YES;
                                }
                                else
                                {
                                    parentNode[pIndex].child = (sint32)cIndex;
                                    isSibling = YES;
                                }
                                cIndex++;
                            }
                        }
                    }
                }
                [root[depth] setLength: sizeof(Path_Iterator_Entry [cIndex])];
            }
            swap = current;
            current = next;
            next = swap;
            [next removeAllObjects];
            depth++;
        }
        pathTable = [[NSArray alloc] initWithObjects: root count: PI_LIMIT];
        
        // Link the depth 6 nodes to the appropriate depth 3 node
        
        [current removeAllObjects];
        parentNode = [root[1] mutableBytes];
        childNode = [root[2] mutableBytes];
        
        for( pIndex = 0 ; pIndex < [generators count] ; pIndex++ )
        {
            key[0] = parentNode[pIndex].action;
            cIndex = parentNode[pIndex].child;
            do
            {
                key[1] = childNode[cIndex].action;
                [current addObject: [NSData dataWithBytes: key length: sizeof(NSUInteger [2])]];
            }while( childNode[cIndex++].hasSib );
        }
        
        count = [root[PI_LIMIT - 2] length] / sizeof(Path_Iterator_Entry);
        parentNode = [root[PI_LIMIT - 2] mutableBytes];
        childNode = [root[PI_LIMIT - 1] mutableBytes];
        linkNode = [root[2] mutableBytes];
        
        for( pIndex = 0 ; pIndex < count ; pIndex++ )
        {
            if( parentNode[pIndex].child != - 1 )
            {
                key[0] = parentNode[pIndex].action;
                cIndex = parentNode[pIndex].child;
                do
                {
                    key[1] = childNode[cIndex].action;
                    index = [current indexOfObject: [NSData dataWithBytes: key length: sizeof(NSUInteger [2] )]];
                    childNode[cIndex].child = linkNode[index].child;
                }while( childNode[cIndex++].hasSib);
            }
        }
        
        for( index = 0 ; index < PI_LIMIT ; index++ )
            maxIndex[index] = [[pathTable objectAtIndex: index] length] / sizeof( Path_Iterator_Entry );
        
        for( index = 3 , pIndex = PI_LIMIT ; pIndex < PATH_ITERATOR_MAX_DEPTH + 1 ; index++ , pIndex++ )
        {
            pathRoot[pIndex] = pathRoot[index];
            maxIndex[pIndex] = maxIndex[index];
        }
    }
    
    [self initMoveRange];
    
    return  self;
}

-(void)initMoveRange
{
    NSMutableData               *itr,
                                *range;
    const Path_Iterator_Path    *path;
    Path_Iterator_Move          move;
    BOOL                        trim;
    unsigned                    index,
                                *start;
    
    itr = [self newIterator];
    path = [itr bytes];
    index = (unsigned)maxIndex[1];
    range = [NSMutableData dataWithLength: sizeof(unsigned [index + 1])];
    start = [range mutableBytes];
    
    trim = NO;
    index = -1;
    do
    {
        move = [self nextMoveForIterator: itr trim: trim ];
        
        if( move.depth == 5)
        {
            trim = YES;
            if( path->index[1] != index )
            {
                index = path->index[1];
                start[index] = path->index[5];
            }
        }
        else
            trim = NO;
        
        if( move.depth == 0)
            start[index + 1] = path->index[5];
        
    } while (move.depth != 0);
    
    depth5 = [range retain];
    depth5Start = [depth5 bytes];
    
}

// Trim = YES Terminate this branch: proceed to a sibling branch
// Trim = NO  Proceed out the current tree branch

-(Path_Iterator_Move)nextMoveForIterator: (NSMutableData *)it
                                    trim: (BOOL)trim
{
    Path_Iterator_Move          result;
    Path_Iterator_Path          *tPath;
    uint32                      index;
    const Path_Iterator_Entry   *entry;
    
    result.depth = 0;
    
    tPath = [it mutableBytes];
    
    if( trim == NO )
    {
        index = tPath->index[ tPath->depth];
        entry = pathRoot[tPath->depth];
        
        if( entry[index].child == -1) // terminal node?
        {
            trim = YES;
        }
        else
        {
            index = entry[index].child;
            tPath->depth++;
            tPath->index[ tPath->depth ] = index;
            entry = pathRoot[tPath->depth];
            
            result.depth = tPath->depth;
            result.action = entry[index].action;
        }
    }
    
    while(trim)
    {
        trim = NO;
        result.depth = tPath->depth;
        
        if( tPath->depth > 0)
        {
            index = tPath->index[ tPath->depth ];
            entry = pathRoot[tPath->depth];
            
            if( entry[index].hasSib)
            {
                index++;
                tPath->index[ tPath->depth ] = index;
                result.depth = tPath->depth;
                result.action = entry[index].action;
            }
            else
            {
                tPath->depth--;
                trim = YES;
            }
        }
    }
    
    return result;
}

-(NSData *)currentPathForIterator: (NSMutableData *)pathData
{
    NSUInteger                  n;
    const Path_Iterator_Path    *p;
    NSMutableData               *result;
    enum_type                   *m;
    
    p = [pathData bytes];
    
    if(p->depth == 0)
    {
        return [NSData data];
    }
    
    result = [NSMutableData dataWithLength: sizeof( enum_type [p->depth] ) ];
    m = [result mutableBytes];
    
    for( n = 1 ; n <= p->depth ; n++ )
        m[n-1] = pathRoot[n][ p->index[n] ].action;
    
    return result;
}

-(NSMutableData *)iteratorForBranch: (unsigned)firstMove
{
    Path_Iterator_Path      path;
    
    path.index[1] = firstMove;
    path.firstTurn = firstMove;
    path.depth = 1;
    
    return [NSMutableData dataWithBytes: &path
                                 length: sizeof( Path_Iterator_Path)];
}

-(NSMutableData *)newIterator
{
    return [NSMutableData dataWithLength: sizeof( Path_Iterator_Path )];
}

-(double)progressForIterator: (NSData *)itr
{
    const Path_Iterator_Path   *p;
    
    p = [itr bytes];
    
    return 100.0 * (double)p->index[4] / maxIndex[4];
}

-(double)progressForBranchItr: (NSData *)itr
{
    const Path_Iterator_Path   *p;
    unsigned                   move;
    double                     start;
    
    p = [itr bytes];
    
    move = p->index[1];
    start = depth5Start[move];
    
    return 100.0 * ((double)p->index[5] - start)/ (depth5Start[move+1] - start);
}

-(NSData *)productOfAction: (NSData *)action andState: (NSData *)state
{
    return [NSData data];
}

-(NSArray *)generators
{
    return [NSArray array];
}

-(NSData *)identityState
{
    return [NSData data];
}


-(NSString *)description
{
    NSString        *result = @"\nPath Table\ndepth    count";
    int             n;    
    
    for( n = 0 ; n < PI_LIMIT ; n++ )
        result = [result stringByAppendingFormat: @"\n%2d%12ld",n,maxIndex[n]];
    
    return result;
    
}
@end
