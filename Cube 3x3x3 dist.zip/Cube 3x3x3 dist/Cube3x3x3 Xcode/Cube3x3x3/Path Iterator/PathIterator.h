//
//  PathIterator.h
//
//  Created by Bruce D MacKenzie on 11/17/13.
//  Copyright (c) 2013 Bruce MacKenzie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GroupModel.h"

#define PATH_ITERATOR_MAX_DEPTH 40

struct Path_Iterator_Entry
{
	uint8	action;
	sint32	child;
    BOOL    hasSib;
};

typedef struct Path_Iterator_Entry Path_Iterator_Entry;

struct Path_Iterator_Move
{
	NSUInteger	action;
	unsigned	depth;
};

typedef struct Path_Iterator_Move Path_Iterator_Move;

struct Path_Iterator_Path
{
	unsigned	index[PATH_ITERATOR_MAX_DEPTH],
                depth,
                firstTurn;
};

typedef struct Path_Iterator_Path Path_Iterator_Path;

@interface PathIterator : NSObject <GroupModel>
{
    
	NSLock                      *pathTableLock;
	NSArray                     *pathTable;
	const Path_Iterator_Entry	*pathRoot[PATH_ITERATOR_MAX_DEPTH + 1];
    NSUInteger                  maxIndex[PATH_ITERATOR_MAX_DEPTH + 1];
    
    NSData                      *depth5;
    const unsigned              *depth5Start;
}


-(id)initWithGroupModel: (id <GroupModel>)theModel;

-(id)initWithGroupModel: (id <GroupModel>)theModel
             generators: (NSArray *)generators;

-(Path_Iterator_Move)nextMoveForIterator: (NSMutableData *)itr
                                    trim: (BOOL)trim;

-(NSData *)currentPathForIterator: (NSMutableData *)itr;

-(NSMutableData *)newIterator;

-(NSMutableData *)iteratorForBranch: (unsigned)firstMove;

-(double)progressForIterator: (NSData *)itr;

-(double)progressForBranchItr: (NSData *)itr;

@end
