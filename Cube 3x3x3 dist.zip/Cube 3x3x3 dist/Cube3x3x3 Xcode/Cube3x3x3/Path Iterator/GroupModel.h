//
//  GroupModel.h
//
//  Created by Bruce D MacKenzie on 11/17/13.
//  Copyright (c) 2013 Bruce MacKenzie. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol GroupModel <NSObject>

-(NSData *)productOfAction: (NSData *)action andState: (NSData *)state;

-(NSArray *)generators;

-(NSData *)identityState;


@end
