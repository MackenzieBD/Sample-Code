//
//  main.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
