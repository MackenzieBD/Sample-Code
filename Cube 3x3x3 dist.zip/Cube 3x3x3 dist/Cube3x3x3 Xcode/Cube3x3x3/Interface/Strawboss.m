//
//  Strawboss.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import "Strawboss.h"
#import "CubieModelSolver.h"
#import "CubeEngineProtocol.h"

@interface Strawboss ()
{
    id<CubeEngineProtocol>  theEngine;
    NSTimer                 *taskTimer;
    NSLock                  *queueLock;
    NSMutableArray          *queue;
    NSNumber                *progress;
    NSString                *progressLabel;
    BOOL                    engineReady;
}

@property (strong) IBOutlet NSWindow *window;

@end

@implementation Strawboss


@synthesize executeButton;
@synthesize functionMenu;
@synthesize parametersTextView;
@synthesize resultsTextView;
@synthesize progressIndicator;

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver: self];
    [theEngine release];
    [queue release];
    [super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    [progressIndicator setHidden: YES];
    theEngine = [[CubieModelSolver alloc] init];
    queue = [[NSMutableArray alloc] init];
    queueLock = [[NSLock alloc] init];
    
    [[self executeButton] setTitle: @"GO"];
    progressLabel = [[NSString alloc] initWithString: @" "];
    progress = [[NSNumber alloc] initWithDouble: 0.0];
    
    taskTimer = [NSTimer scheduledTimerWithTimeInterval: 0.1
                                                 target: self
                                               selector: @selector( upkeep: )
                                               userInfo: nil
                                                repeats: YES];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(registerComment:)
                                                 name: SB_REPORT
                                               object: nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(functionDone:)
                                                 name: SB_FUNCTION_DONE
                                               object: nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(registerProgress:)
                                                 name: SB_PROGRESS
                                               object: nil];
    
    engineReady = YES;
    
    [[self functionMenu] removeAllItems];
    [[self functionMenu] addItemsWithTitles:
     [[theEngine functionArray] sortedArrayUsingSelector: @selector(compare:)]];
    
}


- (void)applicationWillTerminate:(NSNotification *)aNotification
{
    // Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app
{
    return YES;
}

-(IBAction)execute:(id)sender
{
    NSDictionary    *info;
    if([[sender title] isEqualToString: @"GO"] )
    {
        [sender setTitle: @"ABORT"];
        engineReady = NO;
        info = [NSDictionary dictionaryWithObjectsAndKeys:
                [[self functionMenu] titleOfSelectedItem],      CEP_FUNCTION,
                [[self parametersTextView] string],             CEP_PARAMETER,
                nil];
        
        [theEngine execute: info];
    }
    else
    {
        [theEngine stop];
    }
}

-(void)functionDone: (NSNotification *)note
{
    engineReady = YES;
}

- (id)nextComment
{
    id      comment = nil;
    
    [queueLock lock];
    if( [queue count] > 0 )
    {
        comment = [queue objectAtIndex: 0];
        [[comment retain] autorelease];
        [queue removeObjectAtIndex: 0];
    }
    [queueLock unlock];
    
    return  comment;
}

- (void)registerComment: (NSNotification *)note
{
    id              comment;
    NSDictionary    *info;
    
    info = [note userInfo];
    comment = [info objectForKey: SB_REPORT];
    [queueLock lock];
    [queue addObject: comment];
    [queueLock unlock];
}

-(void)registerProgress: (NSNotification *)note
{
    [queueLock lock];
    
    [progress release];
    [progressLabel release];
    progress = [[[note userInfo] objectForKey: SB_PROGRESS] retain];
    progressLabel = [[[note userInfo] objectForKey: SB_PROGRESS_LABEL] retain];
    
    [queueLock unlock];
}

-(void)upkeep: (NSTimer *)timer
{
    id      comment;
    
    while( (comment = [self nextComment]) != nil)
        [self writeToOutput: comment];
    
    if(engineReady && [[executeButton title] isEqualToString: @"ABORT"])
       [[self executeButton] setTitle: @"GO"];
    
    
    if( progress != nil )
    {
        [queueLock lock];
        
        [[self progressIndicator]  setDoubleValue: [progress doubleValue] ];
        if( progressLabel != nil )
        {
            [[self progressItem] setLabel: progressLabel];
        }
        [progress release];
        progress = nil;
        [progressLabel release];
        progressLabel = nil;
        
        if( [[self progressIndicator] isHidden] )
        {
            if( [[self progressIndicator] doubleValue] > 0.001 )
                [[self progressIndicator] setHidden: NO ];
        }
        else
        {
            if( [[self progressIndicator] doubleValue] < 0.001  )
                [[self progressIndicator] setHidden: YES];
        }
        
        
        [queueLock unlock];
    }
    
}

-(void)writeToOutput: (id)comment
{
    NSMutableString     *results;
    NSDictionary        *attributes;
    
    attributes = [[self resultsTextView] typingAttributes];
    
    if([comment isKindOfClass: [NSString class]])
    {
        results = [[[self resultsTextView] textStorage] mutableString];
        [results appendString: comment];
    }
    else
    {
        if( [comment isKindOfClass: [NSAttributedString class]] )
        {
            [[[self resultsTextView] textStorage] appendAttributedString: comment];
        }
        else
        {
            if( [comment isKindOfClass: [NSObject class]] )
            {
                results = [[[self resultsTextView] textStorage] mutableString];
                [results appendString: [comment description]];
            }
        }
    }
    
    results = [[[self resultsTextView] textStorage] mutableString];
    [[self resultsTextView] scrollRangeToVisible: NSMakeRange( [results length] - 1,  1 ) ];
    [[self resultsTextView] setTypingAttributes: attributes];
}

@end
