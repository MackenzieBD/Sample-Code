//
//  Strawboss.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import <Cocoa/Cocoa.h>

@interface Strawboss : NSObject <NSApplicationDelegate>
{
    NSPopUpButton       *functionMenu;
    NSButton            *executeButton;
    NSTextView          *parametersTextView;
    NSTextView          *resultsTextView;
}

@property (assign) IBOutlet NSPopUpButton *functionMenu;
@property (assign) IBOutlet NSButton *executeButton;
@property (assign) IBOutlet NSTextView *parametersTextView;
@property (assign) IBOutlet NSTextView *resultsTextView;
@property (assign) IBOutlet NSProgressIndicator *progressIndicator;
@property (assign) IBOutlet NSToolbarItem *progressItem;


@end

