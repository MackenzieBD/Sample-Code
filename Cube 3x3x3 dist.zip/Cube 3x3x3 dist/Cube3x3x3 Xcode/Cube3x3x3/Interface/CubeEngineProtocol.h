//
//  CubeEngineProtocol.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/9/21.
//

#ifndef CubeEngineProtocol_h
#define CubeEngineProtocol_h

#import "StrawBossNotification.h"

#define CEP_FUNCTION @"CEP FUNCTION PROMPT"
#define CEP_PARAMETER @"CEP PARAMETER STRING"

@protocol CubeEngineProtocol <NSObject>

- (void) execute: (NSDictionary *)parameters;

- (NSArray *)functionArray;

- (void)stop;

@end

#endif /* CubeEngineProtocol_h */
