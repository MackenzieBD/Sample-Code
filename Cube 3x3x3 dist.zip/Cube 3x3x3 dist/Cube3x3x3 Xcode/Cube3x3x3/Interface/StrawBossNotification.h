//
//  StrawBossNotification.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/10/21.
//

#ifndef StrawBossNotification_h
#define StrawBossNotification_h

#define SB_PROGRESS @"SB PROGRESS"
#define SB_PROGRESS_LABEL @"LABEL"

#define SB_REPORT @"SB REPORT"

#define SB_FUNCTION_DONE @"SB FUNCTION COMPLETE"

#endif /* StrawBossNotification_h */
