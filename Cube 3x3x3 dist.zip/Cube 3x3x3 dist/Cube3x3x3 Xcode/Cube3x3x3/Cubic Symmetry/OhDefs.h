//
//  OhDefs.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/9/21.
//

#ifndef OhDefs_h
#define OhDefs_h
#import <simd/simd.h>

struct OSG_DEF
{
    NSString    *permutationString,
                *base,
                *superScript,
                *subScript;
};
typedef  struct OSG_DEF OSG_DEF;

typedef struct
{
    float           angle; //CCW
    simd_float3     axis;
}OSG_ROTATION;

typedef uint8 OSG_SYMTAG;

typedef NSInteger OSG_VECTOR_t;

#endif /* OhDefs_h */

