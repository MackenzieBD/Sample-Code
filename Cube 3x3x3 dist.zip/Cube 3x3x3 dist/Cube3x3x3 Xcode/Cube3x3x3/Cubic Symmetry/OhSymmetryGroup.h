//
//  OhSymmetryGroup.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import <Foundation/Foundation.h>
#import <simd/simd.h>
#import "OhDefs.h"


NS_ASSUME_NONNULL_BEGIN

@interface OhSymmetryGroup : NSObject

-(NSArray *)dump;

-(OSG_SYMTAG)productOfActionTag: (OSG_SYMTAG)action
                       stateTag: (OSG_SYMTAG)state;

-(OSG_SYMTAG)inverseOfTag: (OSG_SYMTAG)state;

-(NSData *)productOfTag: (OSG_SYMTAG)tag
                 vector: (NSData *)vector;

-(NSArray *)subgroupFromGenerators: (NSArray *)generators;

-(NSArray *)subgroupNamed: (NSString *)name;

-(OSG_SYMTAG)symtagForKey: (NSString *)key;

-(NSString *)keyForSymtag: (OSG_SYMTAG)tag;

-(matrix_float4x4)GLMatrixForSymTag: (OSG_SYMTAG)tag;

-(matrix_float4x4)MetalMatrixForSymtag: (OSG_SYMTAG)tag;

-(NSAttributedString *)schoenfliesForSymtag: (OSG_SYMTAG)tag;

-(OSG_ROTATION)GLRotationForSymtag: (OSG_SYMTAG)tag;

-(OSG_ROTATION)MetalRotationForSymtag: (OSG_SYMTAG)tag;

@end

NS_ASSUME_NONNULL_END
