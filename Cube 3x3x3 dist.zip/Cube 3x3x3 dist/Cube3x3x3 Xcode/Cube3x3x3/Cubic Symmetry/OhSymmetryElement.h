//
//  OhSymmetryElement.h
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/9/21.
//

#import <Cocoa/Cocoa.h>
#import "OhDefs.h"

NS_ASSUME_NONNULL_BEGIN

@interface OhSymmetryElement : NSObject 

-(instancetype)initWithDefinition: (OSG_DEF)def;

-(NSData *)matrixRep;

-(NSString *)key;

-(OSG_ROTATION)rotation;

-(NSAttributedString *)schoenflies;

@end

NS_ASSUME_NONNULL_END
