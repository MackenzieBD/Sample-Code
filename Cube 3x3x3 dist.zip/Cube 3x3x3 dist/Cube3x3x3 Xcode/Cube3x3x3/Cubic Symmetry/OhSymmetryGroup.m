//
//  OhSymmetryGroup.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/8/21.
//

#import "OhSymmetryGroup.h"
#import "OhSymmetryElement.h"

@implementation OhSymmetryGroup
{
    NSArray         *keys,
                    *matrixes,
                    *schoenflies;
    OSG_SYMTAG      productTable[48][48],
                    inverseTable[48];
    OSG_ROTATION    rotation[48];
}

- (void)dealloc
{
    [keys release];
    [matrixes release];
    [schoenflies release];
        
    [super dealloc];
}

-(instancetype)init
{
    OSG_SYMTAG          n;
    
    self = [super init];
    
    if( self != nil )
    {
        OSG_DEF             def;
        OhSymmetryElement   *item;
        NSMutableArray      *_keys,
                            *_matrixes,
                            *_schoenflies;
        
        _keys = [NSMutableArray array];
        _matrixes = [NSMutableArray array];
        _schoenflies = [NSMutableArray array];
        
        
        for( n = 0 ; n < 48 ; n++ )
        {
            def = [self definitionForSymTag: n];
            item = [[OhSymmetryElement alloc] initWithDefinition: def];
            [_keys addObject: [item key]];
            [_matrixes addObject: [item matrixRep]];
            [_schoenflies addObject: [item schoenflies] ];
            rotation[n] = [item rotation];
            [item release];
        }
        
        keys = [[NSArray alloc] initWithArray: _keys];
        matrixes = [[NSArray alloc] initWithArray: _matrixes ];
        schoenflies = [[NSArray alloc] initWithArray: _schoenflies ];
                
        [self initTables];
    }
    
    for(n = 0 ; n < 48 ; n++)
    [self GLMatrixForSymTag: n];
    
    return self;
}

-(OSG_DEF)definitionForSymTag: (OSG_SYMTAG)symtag
{
    static OSG_DEF  definition[48] =
    {
        {
            @" x, y, z",
            @"E",
            @"",
            @""
        },
        {
            @" x,-y,-z",
            @"C",
            @"",
            @"2x"
        },
        {
            @"-x, y,-z",
            @"C",
            @"",
            @"2y"
        },
        {
            @"-x,-y, z",
            @"C",
            @"",
            @"2z"
        },
        {
            @" y, z, x",
            @"C",
            @"",
            @"3xyz"
        },
        {
            @" z, x, y",
            @"C",
            @"2",
            @"3xyz"
        },
        {
            @" y,-z,-x",
            @"C",
            @"",
            @"3x'y'z"
        },
        {
            @"-z, x,-y",
            @"C",
            @"2",
            @"3x'y'z"
        },
        {
            @"-y,-z, x",
            @"C",
            @"",
            @"3x'yz'"
        },
        {
            @" z,-x,-y",
            @"C",
            @"2",
            @"3x'yz'"
        },
        {
            @"-y, z,-x",
            @"C",
            @"",
            @"3xy'z'"
        },
        {
            @"-z,-x, y",
            @"C",
            @"2",
            @"3xy'z'"
        },
        {
            @" x, z,-y",
            @"C",
            @"",
            @"4x"
        },
        {
            @" x,-z, y",
            @"C",
            @"3",
            @"4x"
        },
        {
            @"-z, y, x",
            @"C",
            @"",
            @"4y"
        },
        {
            @" z, y,-x",
            @"C",
            @"3",
            @"4y"
        },
        {
            @" y,-x, z",
            @"C",
            @"",
            @"4z"
        },
        {
            @"-y, x, z",
            @"C",
            @"3",
            @"4z"
        },
        {
            @" y, x,-z",
            @"C",
            @"",
            @"2xy"
        },
        {
            @" z,-y, x",
            @"C",
            @"",
            @"2xz"
        },
        {
            @"-x, z, y",
            @"C",
            @"",
            @"2yz"
        },
        {
            @"-x,-z,-y",
            @"C",
            @"",
            @"2yz'"
        },
        {
            @"-y,-x,-z",
            @"C",
            @"",
            @"2xy'"
        },
        {
            @"-z,-y,-x",
            @"C",
            @"",
            @"2xz'"
        },
        {
            @" x, z, y",
            @"\u03c3",
            @"",
            @"d_yz"
        },
        {
            @" x,-z,-y",
            @"\u03c3",
            @"",
            @"d_yz'"
        },
        {
            @" y, x, z",
            @"\u03c3",
            @"",
            @"d_xy"
        },
        {
            @" z, y, x",
            @"\u03c3",
            @"",
            @"d_xz"
        },
        {
            @"-y,-x, z",
            @"\u03c3",
            @"",
            @"d_xy'"
        },
        {
            @"-z, y,-x",
            @"\u03c3",
            @"",
            @"d_xz'"
        },
        {
            @"-x, z,-y",
            @"S",
            @"",
            @"4x"
        },
        {
            @"-x,-z, y",
            @"S",
            @"3",
            @"4x"
        },
        {
            @"-z,-y, x",
            @"S",
            @"",
            @"4y"
        },
        {
            @" z,-y,-x",
            @"S",
            @"3",
            @"4y"
        },
        {
            @" y,-x,-z",
            @"S",
            @"",
            @"4z"
        },
        {
            @"-y, x,-z",
            @"S",
            @"3",
            @"4z"
        },
        {
            @"-x,-y,-z",
            @"i",
            @"",
            @""
        },
        {
            @"-x, y, z",
            @"\u03c3",
            @"",
            @"h_x"
        },
        {
            @" x,-y, z",
            @"\u03c3",
            @"",
            @"h_y"
        },
        {
            @" x, y,-z",
            @"\u03c3",
            @"",
            @"h_z"
        },
        {
            @"-z,-x,-y",
            @"S",
            @"",
            @"6xyz"
        },
        {
            @"-y,-z,-x",
            @"S",
            @"5",
            @"6xyz"
        },
        {
            @" z, x,-y",
            @"S",
            @"",
            @"6xy'z'"
        },
        {
            @" y,-z, x",
            @"S",
            @"5",
            @"6xy'z'"
        },
        {
            @"-z, x, y",
            @"S",
            @"",
            @"6x'yz"
        },
        {
            @" y, z,-x",
            @"S",
            @"5",
            @"6x'yz"
        },
        {
            @" z,-x, y",
            @"S",
            @"",
            @"6x'y'z"
        },
        {
            @"-y, z, x",
            @"S",
            @"5",
            @"6x'y'z"
        }
    };
    
    return definition[symtag];
}

-(NSArray *)dump
{
    NSMutableArray      *result;
    int                 n;
    
    result = [NSMutableArray array];
    for( n = 0 ; n < 48 ; n++ )
    {
        [result addObject: [NSString stringWithFormat: @"\n\nSymtag: %2d\n", n]];
        [result addObjectsFromArray: [self dumpSymtag: n]];
    }
    return result;
}

-(NSArray *)dumpSymtag: (OSG_SYMTAG)tag;
{
    NSArray             *result;
    NSString            *keyString,
                        *matrixString;
    const OSG_VECTOR_t  (*rep)[3];
    NSInteger           row;
    
    keyString = [NSString stringWithFormat: @"\nkey: @\"%@\"", [keys objectAtIndex: tag] ];
    matrixString = @"\nMatrix Representation T1u";
    
    rep = [[matrixes objectAtIndex: tag] bytes];
    for(row = 0 ; row < 3 ; row++)
        matrixString = [matrixString stringByAppendingFormat:
                        @"\n\t|%2ld,%2ld,%2ld|",rep[row][0],rep[row][1],rep[row][2]];
    
    result = [NSArray arrayWithObjects: [schoenflies objectAtIndex: tag], keyString, matrixString, nil];
    
    return result;
}

-(matrix_float4x4)GLMatrixForSymTag: (OSG_SYMTAG)tag
{
    simd_float4x4           colMajor;
    simd_float3             colVector[3];
    NSData                  *matrix;
    const OSG_VECTOR_t      (*p)[3];
    NSUInteger              col;
    
    colMajor = matrix_identity_float4x4;
    matrix = [matrixes objectAtIndex: tag];
    p = [matrix bytes];
              
    for( col = 0 ; col < 3 ; col++ )
    {
        colVector[col].x = p[0][col];
        colVector[col].y = p[1][col];
        colVector[col].z = p[2][col];
    }
    
    colMajor.columns[0].xyz = colVector[0];
    colMajor.columns[1].xyz = colVector[1];
    colMajor.columns[2].xyz = colVector[2];
    
    return colMajor;
}

// OpenGL and CubieModel use a right hand coordinate system
// with the positive Z axis pointing toward the viewer.
// For some brain-dead reason Metal uses a left hand
// coordinate system with the positive Z axis pointing
// away from the viewer.  If you have defined your geometry
// with metal's coordinate system, to use these right
// hand transforms they must be conjugated with the
// mirror plane that swaps the Z and the -Z axes.

-(matrix_float4x4)MetalMatrixForSymtag: (OSG_SYMTAG)tag
{
    NSString        *key = @" x, y,-z";  //Mirror though the XY plane
    OSG_SYMTAG      m;
    
    m = [keys indexOfObject: key];
    
    // conjugate for the left hand coordinate analog
    
    tag = [self productOfActionTag: tag stateTag: m];
    tag = [self productOfActionTag: m stateTag: tag];
    
    return [self GLMatrixForSymTag: tag ];
}

// Return the rotation for right hand coordinates with the angle in degrees

-(OSG_ROTATION)GLRotationForSymtag: (OSG_SYMTAG)tag
{
    OSG_ROTATION    r;
    if( tag >= 24 )
    {
        NSLog( @"OhSymmetryGroup: Not a rotation element");
        tag = 0;
    }
    r = rotation[tag];
    r.angle *= 360.0 / (2 * M_PI);
    
    return r;
}

// Return the rotation for left hand coordinates and the angle in radians

-(OSG_ROTATION)MetalRotationForSymtag: (OSG_SYMTAG)tag
{
    NSString        *key = @" x, y,-z";  //Mirror though the XY plane
    OSG_SYMTAG      m;
    
    m = [keys indexOfObject: key];
    
    // conjugate for the left hand coordinate analog
    
    tag = [self productOfActionTag: tag stateTag: m];
    tag = [self productOfActionTag: m stateTag: tag];
    
    if( tag >= 24 )
    {
        NSLog( @"OhSymmetryGroup: Not a rotation element");
        tag = 0;
    }
    
    return rotation[tag];
}

-(void)initTables
{
    OSG_SYMTAG          action, state, product;
    NSData              *aMatrix, *sMatrix;
    NSMutableData       *pMatrix;
    const OSG_VECTOR_t  (*a)[3], (*s)[3];
    OSG_VECTOR_t        (*p)[3];
    NSInteger           n,row,col;
    
    pMatrix = [NSMutableData dataWithLength: sizeof(OSG_VECTOR_t [3][3])];
    p = [pMatrix mutableBytes];
    
    for( action = 0 ; action < 48 ; action++ )
    {
        aMatrix = [matrixes objectAtIndex: action];
        a = [aMatrix bytes];
        for( state = 0 ; state < 48 ; state++ )
        {
            sMatrix = [matrixes objectAtIndex: state];
            s = [sMatrix bytes];
            
            for( row = 0; row < 3; row++ )
                for( col = 0; col < 3; col++ )
                {
                    p[row][col] = 0;
                    for( n = 0; n < 3; n++ )
                        p[row][col] += a[row][n] * s[n][col];
                }
            
            product = [matrixes indexOfObject: pMatrix];
            productTable[action][state] = product;
            
            if( product == 0 )
                inverseTable[action] = state;
        }
    }
}


-(OSG_SYMTAG)productOfActionTag: (OSG_SYMTAG)action
                       stateTag: (OSG_SYMTAG)state
{
    if((action >= 48) || (state >= 48))
        return UINT8_MAX;
    
    return productTable[action][state];
}

-(OSG_SYMTAG)inverseOfTag: (OSG_SYMTAG)state
{
    if( state >= 48 )
        return UINT8_MAX;
    
    return inverseTable[state];
}

-(NSData *)productOfTag: (OSG_SYMTAG)tag
                 vector: (NSData *)state
{
    OSG_VECTOR_t        product[3];
    const OSG_VECTOR_t  *s,
                        (*a)[3];
    NSData              *action;
    NSUInteger          row,col;
    
    if( [state length] != sizeof(OSG_VECTOR_t [3]) )
        return nil;
    
    s = [state bytes];
    
    action = [matrixes objectAtIndex: tag];
    a = [action bytes];
    
    for( row = 0 ; row < 3 ; row++ )
    {
        product[row] = 0;
        for(col = 0 ; col < 3 ; col++)
            product[row] += a[row][col] * s[col];
    }
    
    return [NSData dataWithBytes: product length: sizeof(OSG_VECTOR_t [3])];
}

// the output is an array of NSString objects in the form @"N" where N is a valid OSG_SYMTAG
// The argument is an NSArray of keys, ie @" x, z,-y", for the generator elements.

-(NSArray *)subgroupFromGenerators: (NSArray *)generators
{
    NSMutableSet    *group,
                    *new,
                    *products;
    id              item1, item2;
    OSG_SYMTAG      sym1, sym2, prod;
    
    group = [NSMutableSet set];
    for( item1 in generators )
    {
        sym1 = [self symtagForKey: item1];
        if( sym1 >= 48)
            return nil;
        
        [group addObject: [NSString stringWithFormat: @"%d", sym1 ]];
    }
    
    new = [NSMutableSet setWithSet: group];
    products = [NSMutableSet setWithSet: group];
    
    // Close the group
    
    while( [new count] > 0 )
    {
        for(item1 in new)
        {
            sym1 = [item1 intValue];
            for(item2 in group)
            {
                sym2 = [item2 intValue];
                prod = [self productOfActionTag: sym1 stateTag: sym2];
                [products addObject: [NSString stringWithFormat: @"%d", prod ]];
                
                prod = [self productOfActionTag: sym2 stateTag: sym1];
                [products addObject: [NSString stringWithFormat: @"%d", prod ]];
            }
        }
        
        [new setSet: products];
        [new minusSet: group];
        [group setSet: products];
    }
    return [[group allObjects] sortedArrayUsingComparator:
            ^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2)
            {
                int a,b;
                
                a = [obj1 intValue];
                b = [obj2 intValue];
                
                if( a == b )
                    return NSOrderedSame;
                if( a > b )
                    return NSOrderedDescending;
                else
                    return NSOrderedAscending;
            }];
}

// Some useful Oh group subgroups

-(NSArray *)subgroupNamed: (NSString *)name
{
    NSArray     *generators;
    
    if( [name isEqualToString: @"C4y"])
        return [self subgroupFromGenerators: [NSArray arrayWithObject: @"-z, y, x" ]];
    
//  C4vy
//  Symmetry of the cube subgroup with the Up face solved
//  8 elements
//  x, y, z  E,
//  z, y,-x  C4y,
// -z, y, x  C4y3,
// -x, y,-z  C2y,
//  z, y, x  Sig_d_xz,
// -z, y,-x  Sig_d_xz',
// -x, y, z  Sig_h_x,
//  x, y,-z  Sig_h_z
    
    if( [name isEqualToString: @"C4vy"] )
    {
        generators = [NSArray arrayWithObjects:
                                @"-z, y, x",        //C4y
                                @" z, y, x",        //Sig_d_xz
                                nil];
        return [self subgroupFromGenerators: generators];
    }
    
    // D4y
    // Rotation subgroup that maps the Y axis onto itself or -Y
    // 8 elements
    //    x, y, z  E,
    //    z, y,-x  C4y,
    //   -z, y, x  C4y3,
    //    x,-y,-z  C2x,
    //   -x, y,-z  C2y,
    //   -x,-y, z  C2z,
    //    z,-y, x  C2xz,
    //   -z,-y,-x  C2xz'
    
    if( [name isEqualToString: @"D4y"] )
    {
        generators = [NSArray arrayWithObjects:
                                @"-z, y, x",        //C4y
                                @" x,-y,-z",        //C2x
                                nil];
        return [self subgroupFromGenerators: generators];
    }
    
    // D4hy
    // Symmetry of the Kociemba cube subgroup: < U,D,R2,F2,L2,B2 >
    // 16 elements
    //  x, y, z  E,
    //  z, y,-x  C4y,
    // -z, y, x  C4y3,
    //  x,-y,-z  C2x,
    // -x, y,-z  C2y,
    // -x,-y, z  C2z,
    //  z,-y, x  C2xz,
    // -z,-y,-x  C2xz',
    //  z, y, x  Sig_d_xz,
    // -z, y,-x  Sig_d_xz',
    //  z,-y,-x  S4y,
    // -z,-y, x  S4y3,
    // -x,-y,-z  i,
    // -x, y, z  Sig_h_x,
    //  x,-y, z  Sig_h_y,
    //  x, y,-z  Sig_h_z
    
    if( [name isEqualToString: @"D4hy"] )
    {
        generators = [NSArray arrayWithObjects:
                                @"-z, y, x",        //C4y
                                @" x,-y,-z",        //C2x
                                @"-x,-y,-z",        //i
                                nil];
        return [self subgroupFromGenerators: generators];
    }
    
//  C3vxyz
//  Symmetry of the RUF cube group
//  6 elements
//      x, y, z  E,
//      z, x, y  C3xyz,
//      y, z, x  C3xyz2,
//      y, x, z  Sig_d_xy,
//      z, y, x  Sig_d_xz,
//      x, z, y  Sig_d_yz
    
    if( [name isEqualToString: @"C3vxyz"] )
    {
        generators = [NSArray arrayWithObjects:
                                @" z, x, y",        //C3xyz
                                @" y, x, z",        //Sig_d_xy
                                nil];
        return [self subgroupFromGenerators: generators];
    }
    
//     S6xyz
//     Symmetry which maps an axis onto all 6 x,y,z axes
//     6 elements
//        x, y, z  E,
//        z, x, y  C3xyz,
//        y, z, x  C3xyz2,
//       -x,-y,-z  i,
//       -y,-z,-x  S6xyz,
//       -z,-x,-y  S6xyz5
        
        if( [name isEqualToString: @"S6xyz"] )
        {
            generators = [NSArray arrayWithObjects:
                                    @" z, x, y",        //C3xyz
                                    @"-x,-y,-z",        //i
                                    nil];
            return [self subgroupFromGenerators: generators];
        }
    
//     T
//     The tetrahedral rotation subgroup
//     12 elements
//       x, y, z  E,
//       z, x, y  C3xyz,
//       y, z, x  C3xyz2
//      -z,-x, y  C3xy'z',
//      -y, z,-x  C3xy'z'2,
//       z,-x,-y  C3x'yz',
//      -y,-z, x  C3x'yz'2,
//      -z, x,-y  C3x'y'z,
//       y,-z,-x  C3x'y'z2,
//       x,-y,-z  C2x,
//      -x, y,-z  C2y,
//      -x,-y, z  C2z,
        
        if( [name isEqualToString: @"T"] )
        {
            generators = [NSArray arrayWithObjects:
                                    @" z, x, y",        //C3xyz
                                    @" x,-y,-z",        //C2x
                                    nil];
            return [self subgroupFromGenerators: generators];
        }
    
//     Td
//     The full tetrahedral subgroup
//     24 elements
        
        if( [name isEqualToString: @"Td"] )
        {
            generators = [NSArray arrayWithObjects:
                                    @" z, x, y",        //C3xyz
                                    @" x,-y,-z",        //C2x
                                    @" x, z, y",        //Sig_d_yz
                                    nil];
            return [self subgroupFromGenerators: generators];
        }
    
//     O
//     The octahedral(cubic) rotation subgroup
//     24 elements
        
        if( [name isEqualToString: @"O"] )
        {
            generators = [NSArray arrayWithObjects:
                                    @" x, z,-y",        //C4x
                                    @"-z, y, x",        //C4y
                                    nil];
            return [self subgroupFromGenerators: generators];
        }
    
//     Oh
//     The full octahedral(cubic) group
//     48 elements
        
        if( [name isEqualToString: @"Oh"] )
        {
            generators = [NSArray arrayWithObjects:
                                    @" x, z,-y",        //C4x
                                    @"-z, y, x",        //C4y
                                    @"-x,-y,-z",        //i
                                    nil];
            return [self subgroupFromGenerators: generators];
        }
    
    return nil;
}

-(NSString *)keyForSymtag: (OSG_SYMTAG)tag
{
    if( tag >= 48 )
    {
        NSLog( @"OhSymmetryGroup: Symtag out of bounds");
        return nil;
    }
    return [keys objectAtIndex: tag];
}


-(OSG_SYMTAG)symtagForKey: (NSString *)key
{
    NSUInteger      index;
    
    index = [keys indexOfObject: key];
    if(index == NSNotFound)
    {
        NSLog( @"OhSymmetryGroup: Invalid Key");
        return UINT8_MAX;
    }
    else
        return (OSG_SYMTAG)index;
}



-(NSAttributedString *)schoenfliesForSymtag: (OSG_SYMTAG)tag
{
    if( tag >= 48 )
    {
        NSLog( @"OhSymmetryGroup: Symtag out of bounds");
        return nil;
    }
    
    return schoenflies[tag];
}

@end
