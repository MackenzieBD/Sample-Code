//
//  OhSymmetryElement.m
//  Cube3x3x3
//
//  Created by Bruce D MacKenzie on 12/9/21.
//

#import "OhSymmetryElement.h"

@implementation OhSymmetryElement
{
    NSString                *axisPerm;
    NSAttributedString      *schoenflies;
    NSData                  *matrixRep;
    OSG_ROTATION            rotation;
}

-(void)dealloc
{
    [axisPerm release];
    [schoenflies release];
    [matrixRep release];
    
    [super dealloc];
}

-(instancetype)initWithDefinition: (OSG_DEF)def
{
    self = [super init];
    
    if( self != nil)
    {
        NSDictionary                *subDict, *supDict;
        NSMutableAttributedString   *symbol;
        NSAttributedString          *mod;
        
        
        matrixRep = [self matrixRepForAxisPerm: def.permutationString];
        
        [self initRotation: def];
        
        if( matrixRep == nil )
        {
            return nil;
        }
        
        [matrixRep retain];
        
        axisPerm = [[NSString alloc] initWithString: def.permutationString];
        
        subDict = [NSDictionary dictionaryWithObjectsAndKeys:
                   [NSNumber numberWithInt: -1],    NSSuperscriptAttributeName,
                   nil];
        
        supDict = [NSDictionary dictionaryWithObjectsAndKeys:
                   [NSNumber numberWithInt: 1],    NSSuperscriptAttributeName,
                   nil];
        
        symbol = [[NSMutableAttributedString alloc] initWithString: def.base];
        if( ![def.superScript isEqualToString: @""] )
        {
            mod = [[NSAttributedString alloc] initWithString: def.superScript attributes: supDict];
            [symbol appendAttributedString: mod];
            [mod release];
        }
        if( ![def.subScript isEqualToString: @""] )
        {
            mod = [[NSAttributedString alloc] initWithString: def.subScript attributes: subDict];
            [symbol appendAttributedString: mod];
            [mod release];
        }
        
        schoenflies = symbol;
    }
    
    return self;
}

-(void)initRotation: (OSG_DEF)def
{
    int         value,
                i,
                order;
    NSString    *axis;
    

    
    if( [def.base isEqualToString: @"C"])
    {
        rotation.axis = simd_make_float3( 0 , 0 , 0 );
        
        order = [def.subScript intValue];
        axis = [def.subScript substringFromIndex: 1];
        if( [def.superScript length] == 1)
            rotation.angle = 1.0;         //Positive rotations are CCW by the Right Hand Rule
        else                                //Schoenflies notation uses CW rotations
            rotation.angle = -1.0;
        
        
        axis = [axis stringByAppendingString: @" "];
            
        i = 0;
        while( [axis characterAtIndex: i] != ' ')
        {
           if( [axis characterAtIndex: i+1] == '\'' )
               value = -1.0;
            else
                value = 1.0;
            
            switch( [axis characterAtIndex: i] )
            {
                case 'x':
                    rotation.axis.x = value;
                    break;
                case 'y':
                    rotation.axis.y = value;
                    break;
                case 'z':
                    rotation.axis.z = value;
                    
                default:
                    break;
            }
            i++;
        }
            
        switch(order)
        {
            case 2:
                rotation.angle *= M_PI;
                break;
            case 3:
                rotation.angle *= 2.0 * M_PI / 3.0;
                break;
            case 4:
                rotation.angle *= M_PI_2;
                break;
        }
    }
    else
    {
        rotation.axis = simd_make_float3( 1.0 , 0.0 , 0.0 );
        rotation.angle = 0.0;
    }
    
    rotation.axis = simd_normalize( rotation.axis);
}

-(NSComparisonResult)compare: (id)otherObject
{
    if( [otherObject isMemberOfClass: [self class]] )
        return [axisPerm compare: [otherObject name] ];
    
    return NSOrderedSame;
}

-(NSArray *)dump
{
    NSArray             *result;
    NSString            *keyString,
                        *matrixString;
    const OSG_VECTOR_t  (*rep)[3];
    NSInteger           row;
    
    keyString = [NSString stringWithFormat: @"\nkey: @\"%@\"", [self key] ];
    matrixString = @"\nMatrix Representation T1u";
    
    rep = [[self matrixRep] bytes];
    for(row = 0 ; row < 3 ; row++)
        matrixString = [matrixString stringByAppendingFormat:
                        @"\n\t|%2ld,%2ld,%2ld|",rep[row][0],rep[row][1],rep[row][2]];
    
    result = [NSArray arrayWithObjects: schoenflies, keyString, matrixString, nil];
    
    return result;
}

-(BOOL)isEqual:(id)object
{
    if( [object isMemberOfClass: [self class]] )
    {
        return [axisPerm isEqualToString: [object key] ];
    }
    
    return NO;
}



-(NSData *)matrixRep
{
    return [NSData dataWithData: matrixRep];
}

// Return a 3x3 matrix mapping the coordinate axes onto each other
// as spectified by the permutation string

-(NSData *)matrixRepForAxisPerm: (NSString *)perm;
{
    OSG_VECTOR_t    vet,col,row,rep[3][3];
    
    for( row = 0 ; row < 3 ; row++)
        for( col = 0 ; col < 3 ; col++)
        {
            rep[row][col] = 0;
        }
    
    for(row = 0; row < 3 ; row++)
    {
        col = -1;
        if( [perm characterAtIndex: 1 + 3 * row] == 'x')
            col = 0;
        if( [perm characterAtIndex: 1 + 3 * row] == 'y')
            col = 1;
        if( [perm characterAtIndex: 1 + 3 * row] == 'z')
            col = 2;
        
        if( col == -1 )
            return nil;
        
        if( [perm characterAtIndex: 3 * row] == '-')
            rep[row][col] = -1;
        else
            rep[row][col] = 1;
    }
    
    // check for Oh group membership
    // each row and each column must
    // have one and only one ±1 value
    
    for( row = 0 ; row < 3 ; row++)
    {
        vet = 0;
        for( col = 0 ; col < 3 ; col++)
        {
           if(rep[row][col] != 0)
               vet++;
        }
        if( vet != 1 )
            return nil;
    }
    
    for( col = 0 ; col < 3 ; col++)
    {
        vet = 0;
        for( row = 0 ; row < 3 ; row++)
        {
           if(rep[row][col] != 0)
               vet++;
        }
        if( vet != 1 )
            return nil;
    }
    
    return [NSData dataWithBytes: rep length: sizeof(OSG_VECTOR_t [3][3])];
}

-(OSG_ROTATION)rotation
{
    return rotation;
}

-(NSString *)key
{
    return axisPerm;
}

-(NSAttributedString *)schoenflies
{
    return schoenflies;
}

@end
