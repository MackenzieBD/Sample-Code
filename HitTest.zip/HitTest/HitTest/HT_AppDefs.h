//
//  HT_AppDefs.h
//  HitTest
//
//  Created by Bruce D MacKenzie on 10/21/20.
//

#ifndef HT_AppDefs_h
#define HT_AppDefs_h

#define REPORT  @"Report to Strawboss"

#endif /* HT_AppDefs_h */
