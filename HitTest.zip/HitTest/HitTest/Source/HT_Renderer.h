//
//  HT_Renderer.h
//  HitTest
//
//  Created by Bruce D MacKenzie on 10/21/20.
//

#import <Cocoa/Cocoa.h>
@import MetalKit;

NS_ASSUME_NONNULL_BEGIN

@interface HT_Renderer : NSViewController <MTKViewDelegate>

@end

NS_ASSUME_NONNULL_END
