//
//  HT_Dodecahedron.h
//  HitTest
//
//  Created by Bruce D MacKenzie on 9/11/19.
//  Copyright © 2019 Bruce MacKenzie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HT_Figure.h"

NS_ASSUME_NONNULL_BEGIN

@interface HT_Dodecahedron : NSObject <HT_Figure>

@end

NS_ASSUME_NONNULL_END
