//
//  Strawboss.h
//  HitTest
//
//  Created by Bruce D MacKenzie on 10/21/20.
//

#import <Cocoa/Cocoa.h>

@interface Strawboss : NSObject <NSApplicationDelegate>


@end

