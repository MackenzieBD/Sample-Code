//
//  MT_AppDefs.h 
//
//  Created by Bruce D MacKenzie on 10/21/20.
//

#ifndef MT_AppDefs_h
#define MT_AppDefs_h

#define REPORT          @"Report to Strawboss"
#define LIGHTING        @"New Lighting"
#define REPORT_LIGHTING @"Lighting Report"

#define SHOW_HELP       NO

#endif /* MT_AppDefs_h */
