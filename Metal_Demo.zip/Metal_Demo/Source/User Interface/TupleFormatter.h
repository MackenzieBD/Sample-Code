//
//  TupleFormatter.h
//  
//
//  Created by Bruce D MacKenzie on 9/27/19.
//  Copyright © 2019 Bruce MacKenzie. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TupleFormatter : NSFormatter

@end

NS_ASSUME_NONNULL_END
