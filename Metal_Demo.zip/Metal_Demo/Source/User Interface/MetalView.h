//
//  MetalView.h
//
//
//  Created by Bruce D MacKenzie on 11/29/20.
//

#import <Cocoa/Cocoa.h>
#import <MetalKit/MetalKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MetalView : MTKView

@end

NS_ASSUME_NONNULL_END
