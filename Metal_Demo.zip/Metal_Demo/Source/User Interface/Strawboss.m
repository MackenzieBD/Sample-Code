//
//  AppDelegate.m
//  MetalDemo
//
//  Created by Bruce D MacKenzie on 12/6/20.
//
#import "MT_AppDefs.h"
#import "Strawboss.h"
#import "Lighting.h"

#import <MetalKit/MetalKit.h>

#define SB_LIGHTING @"SB Lighting"

@interface Strawboss ()

@property (strong)  IBOutlet NSWindow       *window;
@property (weak)    IBOutlet NSTextView     *logView;
@property (weak)    IBOutlet NSToolbar      *theToolbar;
@property (weak)    IBOutlet Lighting       *lightingPanel;
@end

@implementation Strawboss
{
    NSLock          *queueLock;
    NSMutableArray  *reportQueue;
    NSToolbarItem   *lightingToolbarItem;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Set up thread safe output to the log view
    
    queueLock = [[NSLock alloc] init];
    reportQueue = [[NSMutableArray alloc] init];
    
    
    [NSTimer scheduledTimerWithTimeInterval: 0.1
                                     target: self
                                   selector: @selector(honeyDo:)
                                   userInfo: nil
                                    repeats: YES ];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(processReport:)
                                                 name: REPORT
                                               object:  nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(lightingReport:)
                                                 name: REPORT_LIGHTING
                                               object:  nil];
    
}

-(void)awakeFromNib
{
    if( SHOW_HELP )
        [NSApp showHelp: self];
}

- (void)honeyDo: (NSTimer *)timer
{
    NSString            *comment;
    NSMutableString     *logViewText;
    
    // Output any outstanding comments to the log view
    
    while( (comment = [self nextComment]) != nil )
    {
        logViewText = [[[self logView] textStorage] mutableString];
        [logViewText appendString: comment ];
        
        if( [logViewText length] > 1 )
            [[self logView] scrollRangeToVisible: NSMakeRange( [logViewText length] - 1 , 1 ) ];
    }
}

-(void)lightingReport: (NSNotification *)note;
{
    [queueLock lock];
    [reportQueue addObject: [[self lightingPanel] description]];
    [queueLock unlock];
}

- (NSString *)nextComment
{
    NSString    *newComment = nil;
    
    [queueLock lock];
    if( [reportQueue count] > 0)
    {
        newComment = [reportQueue objectAtIndex: 0];
        [reportQueue removeObjectAtIndex: 0];
    }
    [queueLock unlock];
    
    return newComment;
}

// Queue text items for handling on the main thread

-(void)processReport: (NSNotification *)note
{
    NSString    *text;
    
    text = [[note userInfo] objectForKey: REPORT ];
    
    if( text != nil )
    {
        [queueLock lock];
        [reportQueue addObject: text];
        [queueLock unlock];
    }
}


-(IBAction)showLightingPanel:(id)sender
{
    [[self lightingPanel] showLightingPanel];
}

-(BOOL)splitView:(NSSplitView *)splitView canCollapseSubview:(NSView *)subview
{
    NSArray     *subviews;
    NSView      *item;
    BOOL        result = NO;
    
    subviews = [subview subviews];
    for( item in subviews )
    {
        // Allow the logview to be collapsed but not the metal view
        if( [item isKindOfClass: [NSScrollView class] ] )
            result = YES;
    }
    return result;
}

-(CGFloat)splitView:(NSSplitView *)splitView constrainMaxCoordinate:(CGFloat)proposedMax ofSubviewAt:(NSInteger)dividerIndex
{
    return proposedMax - 150;
}

-(CGFloat)splitView:(NSSplitView *)splitView constrainMinCoordinate:(CGFloat)proposedMin ofSubviewAt:(NSInteger)dividerIndex
{
    return 150;
}

- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar
     itemForItemIdentifier:(NSString *)itemIdentifier
 willBeInsertedIntoToolbar:(BOOL)flag
{
            
    if( [itemIdentifier isEqualToString: SB_LIGHTING] )
        return [self toolbarItemLighting];
    
    return nil;
}
- (NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar *)toolbar
{
    return [NSArray arrayWithObjects:
            SB_LIGHTING,
            nil];
}

- (NSToolbarItem *)toolbarItemLighting
{
    NSImage     *sun;
    NSString    *filename;
    
    if( lightingToolbarItem == nil)
    {
        filename = [[NSBundle mainBundle] pathForResource: @"sun" ofType: @"tif"];
        sun = [[NSImage alloc] initWithContentsOfFile: filename];
        
        lightingToolbarItem = [[NSToolbarItem alloc] initWithItemIdentifier: SB_LIGHTING];
        [lightingToolbarItem setLabel: @"Lighting"];
        [lightingToolbarItem setPaletteLabel: @"Lighting"];
        [lightingToolbarItem setToolTip: @"Show Lighting Panel"];
        [lightingToolbarItem setTarget: self];
        [lightingToolbarItem setAction: @selector( showLightingPanel: ) ];
        [lightingToolbarItem setImage: sun];
    }
    
    return [lightingToolbarItem copy];
}

-(id)toolbarViewForIdentifier: (NSString *)ident
{
    NSArray         *items;
    NSToolbarItem   *item;
    
    items = [[self theToolbar] visibleItems];
    
    for( item in items)
    {
        if( [[item itemIdentifier] isEqualToString: ident] )
        {
            return [item view];
        }
    }
    return nil;
}

- (NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar *)toolbar
{
    return [self toolbarAllowedItemIdentifiers: toolbar];
}
@end
