//
//  LightDefs.h
//  Play_Tonic
//
//  Created by Bruce D MacKenzie on 9/27/19.
//  Copyright © 2019 Bruce MacKenzie. All rights reserved.
//

#ifndef LightDefs_h
#define LightDefs_h

#define LT_AMBIENT      @"LT_AMBIENT"
#define LT_LAMP_COLOR   @"LT_LAMP_COLOR"
#define LT_POSITION     @"LT_POSITION"
#define LT_DISTANCE     @"LT_DISTANCE"
#define LT_ATTEN0       @"LT_ATTEN0"
#define LT_ATTEN1       @"LT_ATTEN1"
#define LT_ATTEN2       @"LT_ATTEN2"
#define LT_SHININESS    @"LT_SHININESS"
#define LT_STRENGTH     @"LT_STRENGTH"


// Default Parameters

#define DEF_AMBIENT         @"0.200, 0.200, 0.200"
#define DEF_LAMP_COLOR      @".7,.7,.7"
#define DEF_POSITION        @"-0.204, -0.204, 0.958"
#define DEF_DISTANCE        @"10.0"
#define DEF_ATTEN0          @"0"
#define DEF_ATTEN1          @"2.0"
#define DEF_ATTEN2          @"0"
#define DEF_SHININESS       @"2.0"
#define DEF_STRENGTH        @"3.0"

#endif /* LightDefs_h */
