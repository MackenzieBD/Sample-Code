//
//  MetalRenderer.h
//
//
//  Created by Bruce D MacKenzie on 11/29/20.
//

#import <Cocoa/Cocoa.h>
@import MetalKit;

NS_ASSUME_NONNULL_BEGIN

@interface MetalRenderer : NSViewController <MTKViewDelegate>

- (BOOL)performKeyEquivalent:(NSEvent *)event;

@end

NS_ASSUME_NONNULL_END
