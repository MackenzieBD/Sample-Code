//
//  Frustum.h
//
//
//  Created by Bruce D MacKenzie on 11/29/20.
//

#ifndef Frustum_h
#define Frustum_h

#define FRUSTUM_NEAR    0.6064
#define FRUSTUM_FAR     1.0
#define FRUSTUM_FOV     (2.0 * 0.245)
#define FRUSTUM_CENTER  ((FRUSTUM_NEAR + FRUSTUM_FAR)/2.0)
#define FRUSTUM_RADIUS  (FRUSTUM_CENTER - FRUSTUM_NEAR)
#define FRUSTUM_SCALE   (FRUSTUM_RADIUS * 0.98)

#endif /* Frustum_h */
