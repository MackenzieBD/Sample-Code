//
//  MetalRenderer.m
//
//
//  Created by Bruce D MacKenzie on 11/29/20.
//

#import "AAPLMathUtilities.h" 
#import "MetalRenderer.h"
#import "MT_AppDefs.h"
#import "HT_Types.h"
#import "HT_Textures.h"
#import "LightDefs.h"

#import "Frustum.h"
#import "HT_Dodecahedron.h"
#import "HT_Tetrahedron.h"
#import "HT_Octahedron.h"
#import "HT_Cube.h"
#import "HT_Icosahedron.h"
#import "HT_Hemisphere.h"

#define ORBIT_PERIOD            15.0
#define ROOT2                   0.7071
#define ROOT3                   0.5773
#define PICK_TEXTURE_SIZE        128
#define SHADOW_TEXTURE_SIZE     1024

typedef struct
{
    matrix_float4x4     nodeRotation,
                        nodeScale,
                        nodeTranslation;
}OBJ_TRANSFORMS;

@interface MetalRenderer ()

@end

@implementation MetalRenderer
{
    NSLock                      *lock;
    
    MTKView                     *metalView;
    id<MTLDevice>               device;
    id<MTLLibrary>              defaultLibrary;
    id <MTLSamplerState>        sampler;
    id<MTLDepthStencilState>    depthState;
    id<MTLRenderPipelineState>  pipelineState;
    id<MTLCommandQueue>         commandQueue;
    
    id<MTLTexture>              shadowTexture;
    id<MTLDepthStencilState>    shadowDepthState;
    MTLRenderPassDescriptor     *shadowRenderPassDescriptor;
    id<MTLRenderPipelineState>  shadowPipelineState;

    vector_float3               lightDirection;
    float                       lightDistance;

    id<MTLTexture>              pickTexture;
    MTLRenderPassDescriptor     *pickRenderPassDescriptor;
    id<MTLRenderPipelineState>  pickPipelineState;
    matrix_float4x4             pickScale;
    matrix_float4x4             pickPerspective;
    float                       pickScaleFactor;
    
    matrix_float4x4             sceneTranslation;
    matrix_float4x4             scenePerspective;
    
    id<HT_Figure>               node[OBJ_MAX];
    OBJ_TRANSFORMS              nodeTransform[OBJ_MAX];
    id<MTLBuffer>               vertexBuffer[OBJ_MAX];
    NSUInteger                  vertexCount[6];

    id<MTLBuffer>               uniformBuffer;
    
    HT_Textures                 *theTextures;
    HT_Uniform                  *uniform;
    
    CGSize                      viewportSize;
    
    vector_float3               axis[26];
    NSUInteger                  animAxis[5];
    FILE                        *randomDevice;
    NSUInteger                  selection;
}

- (void)viewDidLoad
{
    NSData          *item;
    NSUInteger      n;
    
    [super viewDidLoad];
    
   [[NSNotificationCenter defaultCenter] addObserver: self
                                            selector: @selector( setLightingFromNote: )
                                                name: LIGHTING
                                              object: nil];
    
    lock = [[NSLock alloc] init];
    
    [self initMTKView];
    
    selection = 1;
    theTextures = [[HT_Textures alloc] initWithMTLDevice: device];
    
    uniformBuffer = [device newBufferWithLength: sizeof(HT_Uniform)
                                        options: MTLResourceStorageModeShared ];
    
    uniform = [uniformBuffer contents];
        
    [self defaultLightModel];
    
    sceneTranslation = matrix4x4_translation( 0.0 , 0.0 , FRUSTUM_CENTER );
    
    // Instanciate the five polyhedra and the backdrop
    
    node[OBJ_TETRAHEDRON] = [[HT_Tetrahedron alloc] initAsNode: OBJ_TETRAHEDRON];
    
    node[OBJ_OCTAHEDRON] = [[HT_Octahedron alloc] initAsNode: OBJ_OCTAHEDRON];
    
    node[OBJ_ICOSAHEDRON] = [[HT_Icosahedron alloc] initAsNode: OBJ_ICOSAHEDRON];
    
    node[OBJ_DODECAHEDRON] = [[HT_Dodecahedron alloc] initAsNode: OBJ_DODECAHEDRON];
    
    node[OBJ_CUBE] = [[HT_Cube alloc] initAsNode: OBJ_CUBE];
    
    node[OBJ_BACKDROP] = [[HT_Hemisphere alloc] initAsNode: OBJ_BACKDROP];
    
    // Initialize the object vertex buffers
    
    for(n = 0 ; n < OBJ_MAX ; n++)
    {
        item = [node[n] vertexData];
        vertexCount[n] = [item length] / sizeof(HT_Vertex);
        vertexBuffer[n] = [device newBufferWithBytes: [item bytes]
                                              length: [item length]
                                             options: MTLResourceStorageModeManaged];
        
        // Initialize Object Space to Model Space transforms
        switch(n)
        {
            case OBJ_TETRAHEDRON:
                nodeTransform[n].nodeTranslation =      matrix4x4_translation( -6.0 , 0.0 , 0.0 );
                nodeTransform[n].nodeScale =            matrix4x4_scale( 1.0 / 7.0 , 1.0 / 7.0 , 1.0 / 7.0);
                nodeTransform[n].nodeRotation =         matrix4x4_identity();
                break;
            case OBJ_OCTAHEDRON:
                nodeTransform[n].nodeTranslation =      matrix4x4_translation( -3.0 , 0.0 , 0.0 );
                nodeTransform[n].nodeScale =            matrix4x4_scale( 1.0 / 7.0 , 1.0 / 7.0 , 1.0 / 7.0);
                nodeTransform[n].nodeRotation =         matrix4x4_identity();
                break;
            case OBJ_ICOSAHEDRON:
                nodeTransform[n].nodeTranslation =      matrix4x4_translation(  0.0 , 0.0 , 0.0 );
                nodeTransform[n].nodeScale =            matrix4x4_scale( 1.0 / 7.0 , 1.0 / 7.0 , 1.0 / 7.0);
                nodeTransform[n].nodeRotation =         matrix4x4_identity();
                break;
            case OBJ_DODECAHEDRON:
                nodeTransform[n].nodeTranslation =      matrix4x4_translation( 3.0 , 0.0 , 0.0 );
                nodeTransform[n].nodeScale =            matrix4x4_scale( 1.0 / 7.0 , 1.0 / 7.0 , 1.0 / 7.0);
                nodeTransform[n].nodeRotation =         matrix4x4_identity();
                break;
            case OBJ_CUBE:
                nodeTransform[n].nodeTranslation =      matrix4x4_translation( 6.0 , 0.0 , 0.0 );
                nodeTransform[n].nodeScale =            matrix4x4_scale( 1.0 / 7.0 , 1.0 / 7.0 , 1.0 / 7.0);
                nodeTransform[n].nodeRotation =         matrix4x4_identity();
                break;
            case OBJ_BACKDROP:
                nodeTransform[n].nodeTranslation =      matrix4x4_identity();
                nodeTransform[n].nodeRotation =         matrix4x4_identity();
                nodeTransform[n].nodeScale =            matrix4x4_identity();
                break;
        }
    }
    
    [self mtkView: metalView drawableSizeWillChange: viewportSize ];
    
    [self initShadowBuffer];
    [self initHitTest];
    
    [self initAxes];
    srandomdev();
    randomDevice = fopen("/dev/random", "r");
}


// Move the objects around the view with rotations about the view center

-(void)animate
{
    static NSUInteger       animTrigger = 0;
    static NSDate           *startTime = nil;
    static matrix_float4x4  initial[5];
    NSTimeInterval          now;
    float                   angle;
    NSUInteger              n,
                            trigger;
    
    if( startTime == nil )
    {
        startTime = [NSDate date];
        animTrigger = 0;
    }
    
    now = -[startTime timeIntervalSinceNow];
    
    trigger = now / ORBIT_PERIOD;
    now  -= trigger * ORBIT_PERIOD;
    
    // If orbit complete--randomly pick rotation axes for next orbit
    if( trigger == animTrigger )
    {
        if(animTrigger == 0)
        {
            for(n = 0 ; n < 5 ; n++ )
                initial[n] = nodeTransform[n].nodeRotation;
        }
        else
        {
            for(n=0 ; n < 5 ; n++ )
            initial[n] = nodeTransform[n].nodeRotation = simd_mul( matrix4x4_rotation( 2.5 * M_PI , axis[animAxis[n]] ) , initial[n] );
        }
        animTrigger++;
        
        animAxis[OBJ_TETRAHEDRON] = animAxis[OBJ_CUBE] = [self random64] % 26;
        animAxis[OBJ_OCTAHEDRON] = animAxis[OBJ_DODECAHEDRON] = [self random64] % 26;
        animAxis[OBJ_ICOSAHEDRON] = [self random64] % 26;
    }
    
    angle = 2.5 * M_PI * now / ORBIT_PERIOD;
    
    for( n = 0 ; n < 5 ; n++ )
    {
        nodeTransform[n].nodeRotation = simd_mul( matrix4x4_rotation( angle , axis[ animAxis[n] ] ) , initial[n] );
    }
}

-(void)defaultLightModel
{
    NSArray                 *values;
    NSMutableDictionary     *param;
    
    param = [NSMutableDictionary dictionary];
    
    values = [DEF_AMBIENT componentsSeparatedByString: @","];
    [param setObject: values forKey: LT_AMBIENT];
    
    values = [DEF_LAMP_COLOR componentsSeparatedByString: @","];
    [param setObject: values forKey: LT_LAMP_COLOR];
    
    values = [DEF_POSITION componentsSeparatedByString: @","];
    [param setObject: values forKey: LT_POSITION];
    
    [param setObject: DEF_DISTANCE forKey: LT_DISTANCE];
    [param setObject: DEF_ATTEN0 forKey: LT_ATTEN0];
    [param setObject: DEF_ATTEN1 forKey: LT_ATTEN1];
    [param setObject: DEF_ATTEN2 forKey: LT_ATTEN2];
    [param setObject: DEF_SHININESS forKey: LT_SHININESS];
    [param setObject: DEF_STRENGTH forKey: LT_STRENGTH];
    
    uniform->eyeDirection = vector3( 0.0f , 0.0f , 1.0f );

    [self setLighting: param];
}

- (void)drawInMTKView:(nonnull MTKView *)view
{
    NSUInteger      n;
    
    @autoreleasepool
    {
        [lock lock];
        
        [self animate];
        
        id<MTLCommandBuffer> commandBuffer = [commandQueue commandBuffer];
        commandBuffer.label = @"ViewCommandBuffer";
        
        // First Render Pass
        // Render a shadow depth texture for use in the second pass
        // fragment shader
        
        [self shadowRenderPass: commandBuffer ];
        
        // Perform the second render pass
        
        MTLRenderPassDescriptor *renderPassDescriptor = view.currentRenderPassDescriptor;
        
        if( renderPassDescriptor != nil )
        {
            
            id<MTLRenderCommandEncoder> renderEncoder =
            [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            
            renderEncoder.label = @"ViewRenderEncoder";
            [renderEncoder setCullMode: MTLCullModeBack];
            
            [renderEncoder setViewport:(MTLViewport){0.0, 0.0, viewportSize.width, viewportSize.height, 0.0, 1.0 }];
            
            [renderEncoder setRenderPipelineState: pipelineState];
            
            [renderEncoder setFragmentSamplerState: sampler atIndex: HT_REG_Texture_Index];
            [renderEncoder setFragmentSamplerState: sampler atIndex: HT_HI_Texture_Index];
            [renderEncoder setFragmentSamplerState: sampler atIndex: HT_BD_Texture_Index];
            
            [renderEncoder setDepthStencilState: depthState];
            
            [renderEncoder setFragmentTexture: shadowTexture atIndex: HT_Shadow_Index];
            
            
            [renderEncoder setFragmentTexture: [theTextures textureNamed: @"Marble"]
                                      atIndex: HT_REG_Texture_Index];
            [renderEncoder setFragmentTexture: [theTextures textureNamed: @"Brass"]
                                      atIndex: HT_HI_Texture_Index];
            [renderEncoder setFragmentTexture: [theTextures textureNamed: @"Bowl"]
                                      atIndex: HT_BD_Texture_Index];
            
            // For each object
            // 1. Move it to its position along the x axis
            // 2. Rotate with the animation rotation
            
            for( n = 0 ; n < OBJ_MAX ; n++ )
            {
                uniform->normalsTransform[n] = nodeTransform[n].nodeRotation;
                
                uniform->toModelSpace[n] = simd_mul(nodeTransform[n].nodeScale , nodeTransform[n].nodeTranslation );
                uniform->toModelSpace[n] = simd_mul(nodeTransform[n].nodeRotation , uniform->toModelSpace[n] );
                
                if( n == selection )
                    uniform->texture[n] = TEX_HI;
                else
                {
                    if( n == OBJ_BACKDROP )
                        uniform->texture[n] = TEX_BD;
                    else
                        uniform->texture[n] = TEX_REG;
                    
                }
            }
            
            [renderEncoder setVertexBuffer: uniformBuffer
                                    offset: 0
                                   atIndex: HT_Uniform_Index];
            
            [renderEncoder setFragmentBuffer: uniformBuffer
                                      offset: 0
                                     atIndex: HT_Uniform_Index];
            
            for( n = 0 ; n < OBJ_MAX ; n++ )
            {
                
                [renderEncoder setVertexBuffer: vertexBuffer[n]
                                        offset: 0
                                       atIndex: HT_Vertex_Index];
                
                
                [renderEncoder drawPrimitives: MTLPrimitiveTypeTriangle
                                  vertexStart: 0
                                  vertexCount: vertexCount[n]];
                
            }
            
            [renderEncoder endEncoding];
            
            // Schedule a present once the framebuffer is complete using the current drawable
            [commandBuffer presentDrawable:view.currentDrawable];
            [commandBuffer commit];
            [commandBuffer waitUntilCompleted];
            [lock unlock];
        }
    }
}

//Symmetry axes of a cube

-(void)initAxes
{
    NSInteger   n;
    vector_float3   a[26] =
    {
        // C4 axes
        { 1.0, 0.0, 0.0},
        {-1.0, 0.0, 0.0},
        { 0.0, 1.0, 0.0},
        { 0.0,-1.0, 0.0},
        { 0.0, 0.0, 1.0},
        { 0.0, 0.0,-1.0},
        //C2d axes
        { ROOT2, ROOT2,   0.0},
        {-ROOT2,-ROOT2,   0.0},
        {-ROOT2, ROOT2,   0.0},
        { ROOT2,-ROOT2,   0.0},
        {   0.0, ROOT2,-ROOT2},
        {   0.0,-ROOT2, ROOT2},
        {   0.0, ROOT2, ROOT2},
        {   0.0,-ROOT2,-ROOT2},
        { ROOT2,   0.0, ROOT2},
        {-ROOT2,   0.0,-ROOT2},
        {-ROOT2,   0.0, ROOT2},
        { ROOT2,   0.0,-ROOT2},
        //C3 axes
        { ROOT3, ROOT3, ROOT3},
        {-ROOT3,-ROOT3,-ROOT3},
        { ROOT3, ROOT3,-ROOT3},
        {-ROOT3,-ROOT3, ROOT3},
        {-ROOT3, ROOT3, ROOT3},
        { ROOT3,-ROOT3,-ROOT3},
        {-ROOT3, ROOT3,-ROOT3},
        { ROOT3,-ROOT3, ROOT3}
    };
    
    for(n=0;n<26;n++)
        axis[n] = a[n];
}

-(void)initDepthAndStencilState
{
    metalView.depthStencilPixelFormat = MTLPixelFormatDepth32Float;
    
    MTLDepthStencilDescriptor *depthStencilDesc = [[MTLDepthStencilDescriptor alloc] init];
    depthStencilDesc.depthCompareFunction = MTLCompareFunctionLess;
    depthStencilDesc.depthWriteEnabled = YES;
    depthState = [device newDepthStencilStateWithDescriptor:depthStencilDesc];
}

-(void)initHitTest
{
    MTLTextureDescriptor        *texDescriptor;
    NSError                     *error;
    id<MTLTexture>              depthTexture;
    
    //Create the render target texture
    texDescriptor = [MTLTextureDescriptor new];
    
    texDescriptor.textureType   = MTLTextureType2D;
    texDescriptor.width         = PICK_TEXTURE_SIZE;
    texDescriptor.height        = PICK_TEXTURE_SIZE;
    texDescriptor.pixelFormat   = MTLPixelFormatRGBA8Unorm;  //i.e. (uint8 [4])
    texDescriptor.storageMode   = MTLStorageModeManaged;
    texDescriptor.usage         = MTLTextureUsageRenderTarget;
    
    pickTexture = [device newTextureWithDescriptor: texDescriptor];
    
    //Create the depth texture
    texDescriptor.textureType   = MTLTextureType2D;
    texDescriptor.width         = PICK_TEXTURE_SIZE;
    texDescriptor.height        = PICK_TEXTURE_SIZE;
    texDescriptor.pixelFormat   = MTLPixelFormatDepth32Float;
    texDescriptor.storageMode   = MTLStorageModePrivate;
    texDescriptor.usage         = MTLTextureUsageRenderTarget;
    
    depthTexture = [device newTextureWithDescriptor: texDescriptor];
    
    pickRenderPassDescriptor = [MTLRenderPassDescriptor new];
    
    pickRenderPassDescriptor.colorAttachments[0].texture        = pickTexture;
    pickRenderPassDescriptor.depthAttachment.texture            = depthTexture;
    pickRenderPassDescriptor.colorAttachments[0].loadAction     = MTLLoadActionClear;
    pickRenderPassDescriptor.colorAttachments[0].clearColor     = MTLClearColorMake( 1.0 , 1.0 , 1.0 , 1.0);
    pickRenderPassDescriptor.colorAttachments[0].storeAction    = MTLStoreActionStore;
    
    // Load the vertex function from the library
    id<MTLFunction> vertexFunction = [defaultLibrary newFunctionWithName:@"pickVertexShader"];
    
    // Load the fragment function from the library
    id<MTLFunction> fragmentFunction = [defaultLibrary newFunctionWithName:@"pickFragmentShader"];
    
    // Configure a pipeline descriptor that is used to create a pipeline state
    
    MTLRenderPipelineDescriptor *pipelineStateDescriptor    = [[MTLRenderPipelineDescriptor alloc] init];
    
    pipelineStateDescriptor.label                           = @"Pick Pipeline";
    pipelineStateDescriptor.vertexFunction                  = vertexFunction;
    pipelineStateDescriptor.fragmentFunction                = fragmentFunction;
    pipelineStateDescriptor.colorAttachments[0].pixelFormat = pickTexture.pixelFormat;
    pipelineStateDescriptor.depthAttachmentPixelFormat      = MTLPixelFormatDepth32Float;
    
    pickPipelineState = [device newRenderPipelineStateWithDescriptor: pipelineStateDescriptor
                                                               error: &error];
    if (!pickPipelineState)
    {
        NSLog(@"Failed to created pipeline state, error %@", error);
    }
}

-(void)initMTKView
{
    MTLClearColor   clearColor = {0.3 , 0.4 , 0.9 , 1.0};
    
    metalView = (MTKView *)[self view];
    metalView.delegate = self;
    
    viewportSize = [metalView drawableSize];

    
    metalView.device = MTLCreateSystemDefaultDevice();
    device = metalView.device;
    
    
    metalView.colorPixelFormat = MTLPixelFormatBGRA8Unorm_sRGB;
    metalView.clearColor = clearColor;
    
    // Load all the shader files with a .metal file extension in the project
    defaultLibrary = [device newDefaultLibrary];
    
    [self initSamplers];
    [self initDepthAndStencilState];
    [self initThePipelineState];
    
    commandQueue = [device newCommandQueue];
}

-(void)initSamplers
{
    // create MTLSamplerDescriptor

    MTLSamplerDescriptor *desc = [[MTLSamplerDescriptor alloc] init];

    desc.minFilter = MTLSamplerMinMagFilterLinear;

    desc.magFilter = MTLSamplerMinMagFilterLinear;

    desc.sAddressMode = MTLSamplerAddressModeMirrorRepeat;

    desc.tAddressMode = MTLSamplerAddressModeRepeat;

    //  all properties below have default values

    desc.mipFilter        = MTLSamplerMipFilterNotMipmapped;

    desc.maxAnisotropy    = 1U;

    desc.normalizedCoordinates = YES;

    desc.lodMinClamp      = 0.0f;

    desc.lodMaxClamp      = FLT_MAX;

    // create MTLSamplerState

    sampler = [device newSamplerStateWithDescriptor:desc];
}

-(void)initShadowBuffer
{
    MTLTextureDescriptor        *texDescriptor;
    NSError                     *error;
    
    //Create the render target texture
    texDescriptor = [MTLTextureDescriptor new];
    
    shadowTexture = [device newTextureWithDescriptor: texDescriptor];
    
    //Create the depth texture
    texDescriptor.textureType   = MTLTextureType2D;
    texDescriptor.width         = SHADOW_TEXTURE_SIZE;
    texDescriptor.height        = SHADOW_TEXTURE_SIZE;
    texDescriptor.pixelFormat   = MTLPixelFormatDepth32Float;
    texDescriptor.storageMode   = MTLStorageModePrivate;
    texDescriptor.usage         = MTLTextureUsageRenderTarget | MTLTextureUsageShaderRead;
    
    shadowTexture = [device newTextureWithDescriptor: texDescriptor];
    shadowTexture.label = @"Shadow Texture";
    
    MTLDepthStencilDescriptor *depthStateDesc = [MTLDepthStencilDescriptor new];
    
    depthStateDesc.label = @"Shadow Gen";
    depthStateDesc.depthCompareFunction = MTLCompareFunctionLessEqual;
    depthStateDesc.depthWriteEnabled = YES;
    shadowDepthState = [device newDepthStencilStateWithDescriptor:depthStateDesc];
    
    shadowRenderPassDescriptor = [MTLRenderPassDescriptor new];
    
    shadowRenderPassDescriptor.depthAttachment.texture      = shadowTexture;
    shadowRenderPassDescriptor.depthAttachment.storeAction  = MTLStoreActionStore;
    shadowRenderPassDescriptor.depthAttachment.loadAction   = MTLLoadActionClear;
    shadowRenderPassDescriptor.depthAttachment.clearDepth   = 1.0;
    
    // Load the vertex function from the library
    id<MTLFunction> vertexFunction = [defaultLibrary newFunctionWithName:@"shadowVertexShader"];
    
    // Configure a pipeline descriptor that is used to create a pipeline state
    
    MTLRenderPipelineDescriptor *pipelineStateDescriptor    = [[MTLRenderPipelineDescriptor alloc] init];
    
    pipelineStateDescriptor.label                           = @"Shadow Pipeline";
    pipelineStateDescriptor.vertexFunction                  = vertexFunction;
    pipelineStateDescriptor.fragmentFunction                = nil;
    pipelineStateDescriptor.depthAttachmentPixelFormat      = MTLPixelFormatDepth32Float;
    
    shadowPipelineState = [device newRenderPipelineStateWithDescriptor: pipelineStateDescriptor
                                                               error: &error];
    if (!shadowPipelineState)
    {
        NSLog(@"Failed to created pipeline state, error %@", error);
    }
    
}

-(void)initThePipelineState
{
    NSError     *error = NULL;
    
    
    // Load the vertex function from the library
    id<MTLFunction> vertexFunction = [defaultLibrary newFunctionWithName:@"vertexTexShader"];
    
    // Load the fragment function from the library
    id<MTLFunction> fragmentFunction = [defaultLibrary newFunctionWithName:@"fragmentTexShader"];
    
    // Configure a pipeline descriptor that is used to create a pipeline state
    MTLRenderPipelineDescriptor *pipelineStateDescriptor = [[MTLRenderPipelineDescriptor alloc] init];
    
    pipelineStateDescriptor.label                               = @"Textured Pipeline";
    pipelineStateDescriptor.vertexFunction                      = vertexFunction;
    pipelineStateDescriptor.fragmentFunction                    = fragmentFunction;
    pipelineStateDescriptor.colorAttachments[0].pixelFormat     = metalView.colorPixelFormat;
    pipelineStateDescriptor.depthAttachmentPixelFormat          = MTLPixelFormatDepth32Float;
    
    pipelineState = [device newRenderPipelineStateWithDescriptor:pipelineStateDescriptor
                                                                 error:&error];
    if (!pipelineState)
    {
        NSLog(@"Failed to created pipeline state, error %@", error);
    }
}

// Respond to a mouse down event in the MTKView

-(void)mouseDown:(NSEvent *)event
{
    NSString    *comment;
    NSPoint     hitPoint;
    NSRect      bounds;
    NSUInteger  n;
    uint8       hit[4];
    
    bounds = [[self view] bounds];
    hitPoint = event.locationInWindow;
    hitPoint = [[self view] convertPoint: hitPoint fromView: nil];
    hitPoint.y = bounds.size.height -  hitPoint.y;   //convert to top-left origin
    
    [self report: [NSString stringWithFormat: @"\nHit x: %d\ty: %d", (int)hitPoint.x , (int)hitPoint.y]];
    
    
    // Render the scene to the pick texture, encoding the object IDs in the "color"
    
    @autoreleasepool
    {
        id<MTLCommandBuffer> commandBuffer = [commandQueue commandBuffer];
        
        [commandBuffer enqueue];
        
        commandBuffer.label = @"pickCommandBuffer";
        
        if( pickRenderPassDescriptor != nil )
        {
            id<MTLRenderCommandEncoder> renderEncoder =
            [commandBuffer renderCommandEncoderWithDescriptor: pickRenderPassDescriptor];
            
            renderEncoder.label = @"pickRenderEncoder";
            [renderEncoder setCullMode: MTLCullModeBack];
            
            // Set the region of the drawable to which we'll draw.
            [renderEncoder setViewport:(MTLViewport){0.0, 0.0, PICK_TEXTURE_SIZE, PICK_TEXTURE_SIZE, 0.0, 1.0 }];
            
            [renderEncoder setRenderPipelineState: pickPipelineState];
            
            [renderEncoder setDepthStencilState: shadowDepthState];
            
            //Compose transform matrixes to position the scene within the viewing volume.            
            
            for( n = 0 ; n < OBJ_MAX ; n++ )
            {
                uniform->normalsTransform[n] = nodeTransform[n].nodeRotation;
                
                uniform->toModelSpace[n] = simd_mul(nodeTransform[n].nodeScale , nodeTransform[n].nodeTranslation );
                uniform->toModelSpace[n] = simd_mul(nodeTransform[n].nodeRotation , uniform->toModelSpace[n] );
            }
                        
            [renderEncoder setVertexBuffer: uniformBuffer
                                    offset: 0
                                   atIndex: HT_Uniform_Index];
            
            [renderEncoder setFragmentBuffer: uniformBuffer
                                      offset: 0
                                     atIndex: HT_Uniform_Index];
            
            
            // Draw the five solids
            
            for( n = 0 ; n < OBJ_MAX - 1 ; n++ )
            {
                
                [renderEncoder setVertexBuffer: vertexBuffer[n]
                                        offset: 0
                                       atIndex: HT_Vertex_Index];
                
                
                [renderEncoder drawPrimitives: MTLPrimitiveTypeTriangle
                                  vertexStart: 0
                                  vertexCount: vertexCount[n]];
            }
            
            [renderEncoder endEncoding];
            
            id<MTLBlitCommandEncoder> blitEncoder = [commandBuffer blitCommandEncoder];
            
            [blitEncoder synchronizeResource: pickTexture];
            
            [blitEncoder endEncoding];
            
            [commandBuffer commit];
            [commandBuffer waitUntilCompleted];
            
            // Convert screen coordinates to pickTexture coordinates
            
            // The pickTexture maps to the largest square that fits centered in the view
            // Adjust the origin to the top-left corner of that square
            
            if(bounds.size.width > bounds.size.height)
                hitPoint.x -= (bounds.size.width - bounds.size.height) / 2 ;
            else
                hitPoint.y -= (bounds.size.height - bounds.size.width) / 2;
            
            // Transpose from screen coordinates to texture coordinates
            hitPoint.x *= pickScaleFactor;
            hitPoint.y *= pickScaleFactor;
            
            // Clamp the hit coordinates to the size of the pick texture
            if( hitPoint.x >= PICK_TEXTURE_SIZE)
                hitPoint.x = PICK_TEXTURE_SIZE - 1;
            
            if( hitPoint.x <= 0)
                hitPoint.x = 1;
            
            if( hitPoint.y >= PICK_TEXTURE_SIZE)
                hitPoint.y = PICK_TEXTURE_SIZE - 1;
            
            if( hitPoint.y <= 0 )
                hitPoint.y = 1;
            
            [pickTexture getBytes: hit
                      bytesPerRow: PICK_TEXTURE_SIZE * sizeof(uint8 [4])
                       fromRegion: MTLRegionMake2D( hitPoint.x ,  hitPoint.y , 1, 1)
                      mipmapLevel: 0];
            
            if( hit[0] < OBJ_MAX - 1 )
            {
                selection = hit[0];
                comment = [NSString stringWithFormat: @"\nObject: %@\nFacet: %d\n", node[selection], hit[1]];
            }
            else
            {
                selection = -1;
                comment = @"\nObject: None\n\n";
            }
            
            [self report: comment];
        }
    }    
}

- (void)mtkView:(nonnull MTKView *)view drawableSizeWillChange:(CGSize)size
{
    float                       aspect;
    matrix_float4x4             sceneScale;
    NSRect                      bounds;
    
    bounds = [view bounds];
    if(uniformBuffer != nil)
    {
        viewportSize = size;
        
        aspect = size.width / size.height;
        
        pickScale = matrix4x4_scale( FRUSTUM_SCALE, FRUSTUM_SCALE, FRUSTUM_SCALE );
        
        //the perspective transform scales to the height.  For tall narrow drawables
        //the figure is scaled down so it's not clipped on the right and the left.
        
        if( aspect > 1.0 )
        {
            sceneScale = matrix4x4_scale( FRUSTUM_SCALE, FRUSTUM_SCALE, FRUSTUM_SCALE );
            pickScaleFactor = PICK_TEXTURE_SIZE / bounds.size.height;
        }
        else
        {
            sceneScale = matrix4x4_scale( FRUSTUM_SCALE * aspect, FRUSTUM_SCALE * aspect, FRUSTUM_SCALE * aspect );
            pickScaleFactor = PICK_TEXTURE_SIZE / bounds.size.width;
        }
        
        // Constructs a symmetric perspective Projection Matrix
        // from left-handed Eye Coordinates to left-handed Clip Coordinates,
        // with a vertical viewing angle of fovyRadians, the specified aspect ratio,
        // and the provided absolute near and far Z distances from the eye.
        //
        // matrix_float4x4 AAPL_SIMD_OVERLOAD matrix_perspective_left_hand(float fovyRadians, float aspect, float nearZ, float farZ);
        
        scenePerspective = matrix_perspective_left_hand( FRUSTUM_FOV , aspect , FRUSTUM_NEAR , FRUSTUM_FAR );
        
        pickPerspective = matrix_perspective_left_hand( FRUSTUM_FOV, 1.0 , FRUSTUM_NEAR , FRUSTUM_FAR );
        
        // Scale the model and center it in the frustum visable volume
        
        uniform->toEyeSpace = simd_mul(sceneTranslation , sceneScale );
        uniform->toClipSpace = simd_mul( scenePerspective , uniform->toEyeSpace);
        
        pickScale = matrix4x4_scale( FRUSTUM_SCALE, FRUSTUM_SCALE, FRUSTUM_SCALE );
        
        uniform->toPickSpace = simd_mul(sceneTranslation, pickScale);
        uniform->toPickSpace = simd_mul(pickPerspective , uniform->toPickSpace);
        
        [self setupShadowView];
    }
}

- (BOOL)performKeyEquivalent:(NSEvent *)event
{
    return NO;
}

-(void)keyUp: (NSEvent *)event
{
    
}


// Return a crytographically secure random number
-(uint64)random64
{
    uint64_t    value = 0;
    int         i;
    
   for (i = 0 ; i < sizeof(value); i++)
    {
        value <<= 8;
        value |= fgetc(randomDevice);
    }
    
    return value;
}


- (void)report: (nonnull NSString *)text
{
    NSDictionary    *userInfo;
    
    userInfo = [NSDictionary dictionaryWithObject: text
                                           forKey: REPORT ];
    
    [[NSNotificationCenter defaultCenter] postNotificationName: REPORT
                                                        object: self
                                                      userInfo: userInfo];
}

-(void)setLightingFromNote: (NSNotification *)note
{
    NSDictionary    *newParameters;
    
    newParameters = [[note userInfo] objectForKey: LIGHTING];
    [self setLighting: newParameters];
}

-(void)setLighting: (NSDictionary *)newParameters
{
    NSArray *tuple;
    

    tuple = [newParameters objectForKey: LT_AMBIENT];
    uniform->ambient.r = [[tuple objectAtIndex: 0] floatValue];
    uniform->ambient.g = [[tuple objectAtIndex: 1] floatValue];
    uniform->ambient.b = [[tuple objectAtIndex: 2] floatValue];
    
    tuple = [newParameters objectForKey: LT_POSITION];
    lightDirection.x = [[tuple objectAtIndex: 0] floatValue];
    lightDirection.y = [[tuple objectAtIndex: 1] floatValue];
    lightDirection.z = [[tuple objectAtIndex: 2] floatValue];
    
    tuple = [newParameters objectForKey: LT_LAMP_COLOR];
    uniform->lightColor.r = [[tuple objectAtIndex: 0] floatValue];
    uniform->lightColor.g = [[tuple objectAtIndex: 1] floatValue];
    uniform->lightColor.b = [[tuple objectAtIndex: 2] floatValue];
    
    uniform->constantAttenuation =  [[newParameters objectForKey: LT_ATTEN0] floatValue];
    uniform->linearAttenuation =    [[newParameters objectForKey: LT_ATTEN1] floatValue];
    uniform->quadradicAttenuation = [[newParameters objectForKey: LT_ATTEN2] floatValue];
    uniform->shininess =            [[newParameters objectForKey: LT_SHININESS] floatValue];
    uniform->strength =             [[newParameters objectForKey: LT_STRENGTH] floatValue];
    
    lightDistance = [[newParameters objectForKey: LT_DISTANCE] floatValue ];
    lightDistance *= FRUSTUM_CENTER;
    
    [self setupShadowView];
}

// Map a point in Model Space to a point from the light's
// point of view.

-(void)setupShadowView
{
    vector_float4       lightPosition;
    matrix_float4x4     rotate,
                        rotate2,
                        lightPerspective;
    float               angle,
                        angle2,
                        _theda,
                        _d, _r,
                        _scale,
                        _fov,
                        _near,
                        _far;
   
    // Compose the perpective matrix for the light source POV
    // See CLIP.png for the math ( _d + _r = lightDistance ).
    
    _theda = asinf( 1.0 / lightDistance );
    _fov = 2.0 * _theda;
    _d = (1.0 - sinf(_theda)) / (1.0 + sinf(_theda));
    _r = (1.0 - _d) / 2.0;
    _scale = _r * .98;          //fudge it a bit
    _near = _d;
    _far = 1.0;
    
    lightPerspective = matrix_perspective_left_hand(_fov, 1.0, _near, _far );
    
    // My version of a look_at routine
    lightPosition = simd_make_float4(lightDirection , 1);
    lightPosition.xyz *= -1.0;
    
    uniform->lightPosition = lightPosition.xyz;
        
    // rotate the light position about the z axis onto the x,z plane
    angle = atanf( lightPosition.y / lightPosition.x );
    rotate = matrix4x4_rotation(angle, 0.0 , 0.0 ,-1.0 );
    lightPosition = simd_mul(rotate , lightPosition );
    
    // Now rotate the light position about the y axis onto to the z axis
    angle2 = atanf( lightPosition.x / lightPosition.z);
    rotate2 = matrix4x4_rotation( angle2 , 0.0 ,-1.0 , 0.0);
    
    // Compose a transform to take model coordinates to the
    // spot light's POV
    
    uniform->toLampPOV = matrix4x4_scale( _scale , _scale , _scale );
    uniform->toLampPOV = simd_mul( rotate , uniform->toLampPOV);
    uniform->toLampPOV = simd_mul( rotate2 , uniform->toLampPOV);
    uniform->toLampPOV = simd_mul(matrix4x4_translation(0.0 , 0.0 , _near + _r ), uniform->toLampPOV);
    uniform->toLampPOV = simd_mul(lightPerspective , uniform->toLampPOV);
      
}

-(void)shadowRenderPass: (id <MTLCommandBuffer>)commandBuffer
{
    NSUInteger      n;
    
    if( shadowRenderPassDescriptor != nil )
    {
        
        id<MTLRenderCommandEncoder> renderEncoder =
        [commandBuffer renderCommandEncoderWithDescriptor: shadowRenderPassDescriptor];
        
        renderEncoder.label = @"shadowRenderEncoder";
        [renderEncoder setCullMode: MTLCullModeBack];
        
        // Default Settings
//        [renderEncoder setDepthBias:0.015 slopeScale:7 clamp:0.02];
        
        [renderEncoder setDepthBias: 0.015
                         slopeScale: 100
                              clamp:0.02];
        
        // Set the region of the drawable to which we'll draw.
        [renderEncoder setViewport:(MTLViewport){0.0, 0.0, SHADOW_TEXTURE_SIZE, SHADOW_TEXTURE_SIZE , 0.0, 1.0 }];
        
        [renderEncoder setRenderPipelineState: shadowPipelineState];
        
        [renderEncoder setDepthStencilState: depthState];
        
        //Compose transform matrixes to position the scene within the viewing volume.
        
        for( n = 0 ; n < OBJ_MAX ; n++ )
        {
            uniform->toModelSpace[n] = simd_mul(nodeTransform[n].nodeScale , nodeTransform[n].nodeTranslation );
            uniform->toModelSpace[n] = simd_mul(nodeTransform[n].nodeRotation , uniform->toModelSpace[n] );
        }
        
        [renderEncoder setVertexBuffer: uniformBuffer
                                offset: 0
                               atIndex: HT_Uniform_Index];
        
        
        // Draw the five solids
        
        for( n = 0 ; n < 6 ; n++ )
        {
            
            [renderEncoder setVertexBuffer: vertexBuffer[n]
                                    offset: 0
                                   atIndex: HT_Vertex_Index];
            
            
            [renderEncoder drawPrimitives: MTLPrimitiveTypeTriangle
                              vertexStart: 0
                              vertexCount: vertexCount[n]];
        }
        
        [renderEncoder endEncoding];
    }
}


@end
