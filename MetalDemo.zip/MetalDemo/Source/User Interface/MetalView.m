//
//  MetalView.m
//
//
//  Created by Bruce D MacKenzie on 11/29/20.
//


#import "MetalView.h"
#import "MetalRenderer.h"

@implementation MetalView

-(BOOL)acceptsFirstResponder
{
    return NO;
}

-(BOOL)canBecomeKeyView
{
    return YES;
}

- (BOOL)performKeyEquivalent:(NSEvent *)event
{
    return [(MetalRenderer *)[self delegate] performKeyEquivalent: event];
}
@end
