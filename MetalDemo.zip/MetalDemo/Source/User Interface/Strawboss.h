//
//  AppDelegate.h
//  MetalDemo
//
//  Created by Bruce D MacKenzie on 12/6/20.
//

#import <Cocoa/Cocoa.h>

@interface Strawboss : NSObject <NSApplicationDelegate , NSSplitViewDelegate>

-(CGFloat)splitView:(NSSplitView *)splitView constrainMaxCoordinate:(CGFloat)proposedMax
        ofSubviewAt:(NSInteger)dividerIndex;

-(CGFloat)splitView:(NSSplitView *)splitView constrainMinCoordinate:(CGFloat)proposedMin
        ofSubviewAt:(NSInteger)dividerIndex;


@end

