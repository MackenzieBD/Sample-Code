//
//  Lighting.h
//  
//
//  Created by Bruce D MacKenzie on 9/27/19.
//  Copyright © 2019 Bruce MacKenzie. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface Lighting : NSViewController

-(void)showLightingPanel;

- (BOOL)control:(NSControl *)control textShouldEndEditing:(NSText *)fieldEditor;

@end

NS_ASSUME_NONNULL_END
