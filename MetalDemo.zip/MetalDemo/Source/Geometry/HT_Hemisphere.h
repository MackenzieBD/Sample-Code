//
//  HT_Hemisphere.h 
//
//  Created by Bruce D MacKenzie on 11/17/20.
//

#import <Foundation/Foundation.h>
#import "HT_Figure.h"

NS_ASSUME_NONNULL_BEGIN

@interface HT_Hemisphere : NSObject < HT_Figure >

@end

NS_ASSUME_NONNULL_END
