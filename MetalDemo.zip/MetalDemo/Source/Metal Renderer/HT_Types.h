//
//  HT_Types.h 
//
//  Created by Bruce D MacKenzie on 9/11/19.
//  Copyright © 2019 Bruce MacKenzie. All rights reserved.
//

#ifndef HT_Types_h
#define HT_Types_h

#include <simd/simd.h>

typedef enum
{
    OBJ_TETRAHEDRON,
    OBJ_OCTAHEDRON,
    OBJ_CUBE,
    OBJ_DODECAHEDRON,
    OBJ_ICOSAHEDRON,
    OBJ_BACKDROP,
    OBJ_MAX
} SCENE_OBJECT;

enum {TEX_REG, TEX_HI , TEX_BD};

typedef enum HT_Buffer_Index
{
    HT_Vertex_Index = 0,
    HT_Uniform_Index = 1,
    HT_REG_Texture_Index = 2,
    HT_HI_Texture_Index = 3,
    HT_BD_Texture_Index = 4,
    HT_Shadow_Index = 5
}HT_Buffer_Index;


typedef struct
{
    vector_float3   position,
                    normal;
    vector_float2   textCoor;
    uint            pickID,
                    facet;
}HT_Vertex;

typedef struct
{
    matrix_float4x4 normalsTransform[6],
                    toModelSpace[6],
                    toEyeSpace,
                    toClipSpace,
                    toHitSpace,
                    toLampPOV;

    int             texture[6];

    vector_float3   ambient,
                    lightColor,
                    lightPosition,
                    eyeDirection;
    
    float           constantAttenuation,
                    linearAttenuation,
                    quadradicAttenuation,
                    shininess,
                    strength;

}HT_Uniform;
 

#endif /* HT_Types_h */
